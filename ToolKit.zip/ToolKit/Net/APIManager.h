//
//  APIManager.h
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/04.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, HTTPMethod) {
    OPTIONS     = 0,
    GET         = 1,
    HEAD        = 2,
    POST        = 3,
    PUT         = 4,
    PATCH       = 5,
    DELETE      = 6,
    TRACE       = 7,
    CONNECT     = 8
};

@interface APIManager : NSObject
+(NSURLSessionDataTask*)url:(NSString*)urlString
                     method:(HTTPMethod)httpMethod
               headerFields:(NSDictionary<NSString *, NSString *>*)header
                       body:(NSData*)body
          completionHandler:(void (^)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHandler;

+ (NSURLSessionDataTask*)url:(NSString*)urlString
           method:(HTTPMethod)httpMethod
     headerFields:(NSDictionary<NSString *, NSString *>*)header
              query:(nullable NSDictionary<NSString *, NSString *>*)query
           completionHandler:(void (^)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHandler;
@end

NS_ASSUME_NONNULL_END

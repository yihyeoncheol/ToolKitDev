//
//  APIManager.m
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/04.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "APIManager.h"
@interface NSURLRequest (DummyInterface)
+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString*)host;
+ (void)setAllowsAnyHTTPSCertificate:(BOOL)allow forHost:(NSString*)host;
@end



@implementation APIManager

+ (NSURLSessionDataTask*)url:(NSString*)urlString
                      method:(HTTPMethod)httpMethod
                headerFields:(NSDictionary<NSString *, NSString *>*)header
                         query:(nullable NSDictionary<NSString *, NSString *>*)query
           completionHandler:(void (^)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHandler {
    NSString *sHttpMethod = nil;
    
    NSURL *url = [NSURL URLWithString:urlString];
    
    switch (httpMethod) {
        case GET: {
            sHttpMethod = @"GET";
            if(query){
                NSString *sQuery = [query queryString];
                //    sQuery = [sQuery stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                NSString *sURL = [urlString stringByAppendingFormat:@"?%@",sQuery];
                url = [NSURL URLWithString:sURL];
            }
           
        }
            break;

        case POST: {
            sHttpMethod = @"POST";
            break;
        }
        default: return nil;
    }
    
    
    NSString *userAgent = [NSString stringWithFormat:@"%@/%@ (%@; iOS %@; Scale/%0.2f)", [[NSBundle mainBundle] infoDictionary][(__bridge NSString *)kCFBundleExecutableKey] ?: [[NSBundle mainBundle] infoDictionary][(__bridge NSString *)kCFBundleIdentifierKey], [[NSBundle mainBundle] infoDictionary][@"CFBundleShortVersionString"] ?: [[NSBundle mainBundle] infoDictionary][(__bridge NSString *)kCFBundleVersionKey], [[UIDevice currentDevice] model], [[UIDevice currentDevice] systemVersion], [[UIScreen mainScreen] scale]];
    NSTimeInterval timeoutInterval = 20;
    
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:timeoutInterval];
    
    if (httpMethod == POST){
        if (query){
            [urlRequest setHTTPBody:[[self convertDictToParamString:query] dataUsingEncoding:NSUTF8StringEncoding]];
        }
//        NSData *body = [query.queryString dataUsingEncoding:NSUTF8StringEncoding];
//        urlRequest.HTTPBody = body;
    }
//    urlRequest.allHTTPHeaderFields = header;
    urlRequest.HTTPMethod = sHttpMethod;
    [urlRequest setValue:userAgent forHTTPHeaderField:@"User-Agent"];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:urlRequest completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
           dispatch_async(dispatch_get_main_queue(), ^{
               completionHandler(data,response,error);
           });
        
    }];
    [dataTask resume];
    return dataTask;
}

+ (NSURLSessionDataTask*)url:(NSString*)urlString
                     method:(HTTPMethod)httpMethod
               headerFields:(NSDictionary<NSString *, NSString *>*)header
                       body:(NSData*)body
          completionHandler:(void (^)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHandler {
    NSString *sHttpMethod = nil;
    switch (httpMethod) {
        case OPTIONS:sHttpMethod    = @"OPTIONS";break;
        case GET:sHttpMethod        = @"GET";break;
        case HEAD:sHttpMethod       = @"HEAD";break;
        case POST:sHttpMethod       = @"POST";break;
        case PUT:sHttpMethod        = @"PUT";break;
        case PATCH:sHttpMethod      = @"PATCH";break;
        case DELETE:sHttpMethod     = @"DELETE";break;
        case TRACE:sHttpMethod      = @"TRACE";break;
        case CONNECT:sHttpMethod    = @"CONNECT";break;
    }
    
    NSLog("URL :::: ===>> %@", urlString);
    
    NSString *userAgent = [NSString stringWithFormat:@"%@/%@ (%@; iOS %@; Scale/%0.2f)", [[NSBundle mainBundle] infoDictionary][(__bridge NSString *)kCFBundleExecutableKey] ?: [[NSBundle mainBundle] infoDictionary][(__bridge NSString *)kCFBundleIdentifierKey], [[NSBundle mainBundle] infoDictionary][@"CFBundleShortVersionString"] ?: [[NSBundle mainBundle] infoDictionary][(__bridge NSString *)kCFBundleVersionKey], [[UIDevice currentDevice] model], [[UIDevice currentDevice] systemVersion], [[UIScreen mainScreen] scale]];
    NSTimeInterval timeoutInterval = 20;
    NSURL *url = [NSURL URLWithString:urlString];
    
    
    
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:timeoutInterval];
    urlRequest.allHTTPHeaderFields = header;
    urlRequest.HTTPMethod = sHttpMethod;
    [urlRequest setValue:userAgent forHTTPHeaderField:@"User-Agent"];
     urlRequest.HTTPBody = body;
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:urlRequest completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completionHandler(data,response,error);
        });
    }];
    [dataTask resume];
    return dataTask;
}

+(NSString*)convertDictToParamString:(NSDictionary*)dict {
    NSMutableString *urlWithQuerystring = [NSMutableString new];
    
    for (id key in dict) {
        NSString *keyString = [key description];
        NSString *valueString = [[dict objectForKey:key] description];
        
        if (urlWithQuerystring.length != 0) {
            [urlWithQuerystring appendString:@"&"];
        }
        //pmtMthdList
        NSString *key = [self urlEncoded:keyString];
        NSString *value = [self urlEncoded:valueString];
        
        
        if([keyString isEqualToString:@"pmtMthdList"]){
            
            NSLog(@"value %@", valueString);
            
            valueString = [valueString stringByReplacingOccurrencesOfString:@"["
                                                 withString:@""];
            valueString = [valueString stringByReplacingOccurrencesOfString:@"]"
                                                 withString:@""];
            
            NSLog(@"value %@", valueString);
            
            value = [self urlEncoded:valueString];
            [urlWithQuerystring appendFormat:@"%@=%@", key, value];
        } else {
            [urlWithQuerystring appendFormat:@"%@=%@", key, value];
        }
        
        
        
    }
    
    return urlWithQuerystring;
}

/**
 * method urlEncoded
 * brief URL Encoding을 하여 반환한다.
 * param src URL
 * return URL Encoding된 값
 */
+ (NSString *) urlEncoded:(NSString * )src {
    
    //NSString *value = @"<url>";
   // return  [src stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
    
    CFStringRef urlString = CFURLCreateStringByAddingPercentEscapes(
                                                                    NULL,
                                                                    (CFStringRef)src,
                                                                    NULL,
                                                                    (CFStringRef)@"!*'\"();:@&=+$,/?%#[]% ",
                                                                    kCFStringEncodingUTF8 );
    return (NSString *)CFBridgingRelease(urlString);
}


@end

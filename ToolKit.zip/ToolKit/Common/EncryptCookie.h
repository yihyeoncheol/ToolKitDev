//
//  EncryptCookie.h
//  GlobalWiBeeBank
//
//  Created by yihyeoncheol on 05/12/2019.
//  Copyright © 2019 yihyeoncheol. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface EncryptCookie : NSObject

- (void)setAttribute:(NSString*)name value:(NSString*)value;
- (NSString*)getAttribute:(NSString*)name;
- (BOOL)removeAttribute:(NSString*)name;
- (NSArray *)allAttribute;
- (void)removeAllAttribute;
@end

NS_ASSUME_NONNULL_END

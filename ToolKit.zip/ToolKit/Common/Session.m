//
//  Session.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "Session.h"



@implementation _Session
{
    NSMutableDictionary *_attribute;
}

+ (_Session *)shared {
    static _Session * obj = nil;
    if (obj == nil) {
        @synchronized(self) {
            if (obj == nil) {
                obj = [[self alloc] init];
            }
        }
    }
    return obj;
}


- (void)dealloc{
    _attribute = nil;
}

- (id)init {
    self = [super init];
    
    if (self){
        _attribute = [[NSMutableDictionary alloc]init];
    }
    return self;
}


- (void)invalidate {
    [_attribute removeAllObjects];
}

- (NSArray*)getAttributeNames {
    return [_attribute allKeys];
}

- (void)setAttribute:(NSString *)name value:(id)value {
    [_attribute setObject:value forKey:name];
}

- (void)setAttributes:(NSDictionary *)attributes {
    [_attribute setDictionary:attributes];
}

- (id)getAttribute:(NSString *)name {
    return [_attribute objectForKey:name];
}

-(void)removeAttribute:(NSString*)name {
    [_attribute removeObjectForKey:name];
}

-(void)removeAllAttribute {
    [_attribute removeAllObjects];
}

@end

//
//  Session.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <Foundation/Foundation.h>


#define Session [_Session shared]






NS_ASSUME_NONNULL_BEGIN

@interface _Session : NSObject
+ (_Session *)shared;
- (void)invalidate;
- (NSArray*)getAttributeNames;
- (void)setAttribute:(NSString *)name value:(id)value;
- (void)setAttributes:(NSDictionary *)attributes;
- (id)getAttribute:(NSString *)name;
- (void)removeAttribute:(NSString*)name;
- (void)removeAllAttribute;

@end

NS_ASSUME_NONNULL_END

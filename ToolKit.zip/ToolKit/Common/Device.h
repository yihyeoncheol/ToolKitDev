//
//  Device.h
//  LPoint
//
//  Created by MP02031 on 2020/10/05.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Device : NSObject
+ (BOOL)hasPushPermission;
+ (NSString*)iOSVerion;
+ (NSString*)appVersion;
+ (NSString*)deviceModel;
+ (NSString*)systemName;
+ (NSString*)deviceName;
+ (NSString*)lpaydeviceName;

@end

NS_ASSUME_NONNULL_END

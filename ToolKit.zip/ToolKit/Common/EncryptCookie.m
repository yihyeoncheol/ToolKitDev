//
//  EncryptCookie.m
//  GlobalWiBeeBank
//
//  Created by yihyeoncheol on 05/12/2019.
//  Copyright © 2019 yihyeoncheol. All rights reserved.
//

#import "EncryptCookie.h"


@implementation EncryptCookie
{
    NSString *_service;
}

- (id)init
{
    self = [super init];
    if (self){
        NSString *bundleIdentifier  = [[NSBundle mainBundle]bundleIdentifier];
        bundleIdentifier = [bundleIdentifier stringByAppendingString:@".cookie"];
        _service = [[NSString alloc]initWithString:bundleIdentifier];
    }
    return self;
}

- (void)setAttribute:(NSString*)name value:(NSString*)value
{
    NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
    
    [self removeAttribute:name];
    
    NSDictionary *query = @{
#if __has_feature(objc_arc)
        (__bridge id)kSecAttrAccount : name,
        (__bridge id)kSecValueData : data,
        (__bridge id)kSecClass : (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService:_service,
        (__bridge id)kSecAttrAccessible : (__bridge id)kSecAttrAccessibleWhenUnlockedThisDeviceOnly
#else
        (id)kSecAttrAccount : name,
        (id)kSecValueData : data,
        (id)kSecClass : (id)kSecClassGenericPassword,
        (id)kSecAttrService:_service,
        (id)kSecAttrAccessible : (id)kSecAttrAccessibleWhenUnlockedThisDeviceOnly
#endif
    };
    
#if __has_feature(objc_arc)
    OSStatus result = SecItemAdd((__bridge CFDictionaryRef)query, NULL);
#else
    OSStatus result = SecItemAdd((CFDictionaryRef)query, NULL);
#endif

    if(result != noErr){
        NSLog(@"Failed to add item to keychain");
        return;
    }
}


- (NSString*)getAttribute:(NSString*)name
{
    CFTypeRef result = NULL;

    NSDictionary *query = @{
#if __has_feature(objc_arc)
        (__bridge id)kSecAttrAccount : name,
//        (__bridge id)kSecValueData : anObject,
        (__bridge id)kSecClass : (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService:_service,
        (__bridge id)kSecReturnData:(__bridge id)kCFBooleanTrue,
        (__bridge id)kSecMatchLimit:(__bridge id)kSecMatchLimitOne,
#else
        (id)kSecAttrAccount : name,
        (id)kSecClass : (id)kSecClassGenericPassword,
        (id)kSecAttrService:_service,
                            
//          (id)kSecValueData : anObject,
        (id)kSecReturnData:(id)kCFBooleanTrue,
        (id)kSecMatchLimit:(id)kSecMatchLimitOne,
#endif
    };
    OSStatus status;
#if __has_feature(objc_arc)
    status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
#else
    status = SecItemCopyMatching((CFDictionaryRef)query, &result);
#endif
    
    if (status != noErr ) {
        return nil;
    }
    
#if __has_feature(objc_arc)
    NSData *retData = (__bridge_transfer NSData *)result;
    return [[NSString alloc] initWithData:retData encoding:NSUTF8StringEncoding];
#else
    return [[[NSString alloc] initWithData:[(NSData *)result autorelease] encoding:NSUTF8StringEncoding] autorelease];;
#endif
}


- (BOOL)removeAttribute:(NSString*)name;
{
    NSDictionary *query = @{
#if __has_feature(objc_arc)
        (__bridge id)kSecAttrAccount : name,
        (__bridge id)kSecClass : (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrAccessible : (__bridge id)kSecAttrAccessibleWhenUnlockedThisDeviceOnly
#else
        (id)kSecAttrAccount : aName,
        (id)kSecClass : (id)kSecClassGenericPassword,
        (id)kSecAttrAccessible : (id)kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
#endif
    };

    
#if __has_feature(objc_arc)
    OSStatus result = SecItemDelete((__bridge CFDictionaryRef)query);
#else
    OSStatus result = SecItemDelete((CFDictionaryRef)query);
#endif
    
    BOOL bRet = (result != noErr);
    
    return bRet;
}

- (NSArray *)allAttribute
{
    NSDictionary *query = @{
#if __has_feature(objc_arc)
        (__bridge id)kSecClass : (__bridge id)kSecClassGenericPassword,
//          (__bridge id)kSecAttrService:_service,
        (__bridge id)kSecReturnAttributes:(__bridge id)kCFBooleanTrue,
        (__bridge id)kSecMatchLimit:(__bridge id)kSecMatchLimitAll
#else
        (id)kSecClass : (id)kSecClassGenericPassword,
//          (id)kSecAttrService:_service,
        (id)kSecReturnAttributes:( id)kCFBooleanTrue,
        (id)kSecMatchLimit:( id)kSecMatchLimitAll
#endif
    };
    
    
    CFTypeRef result = NULL;
#if __has_feature(objc_arc)
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
#else
     OSStatus status = SecItemCopyMatching((CFDictionaryRef)query, &result);
#endif
    
    
    NSError *error;
    if (status != noErr) {
            error = [NSError errorWithDomain:@"" code:status userInfo:nil];
        return nil;
    }
    
#if __has_feature(objc_arc)
    return (__bridge_transfer NSArray *)result;
#else
    return [(NSArray *)result autorelease];
#endif
}

- (void)removeAllAttribute
{
    NSArray *allAttribute = [self allAttribute];
    for (NSDictionary *attribute in allAttribute) {
        
#if __has_feature(objc_arc)
        [self removeAttribute:[attribute objectForKey:(__bridge id)kSecAttrAccount]];
#else
        [self removeAttribute:[attribute objectForKey:(id)kSecAttrAccount]];
#endif
    }
}
@end

//
//  Util.h
//  LPoint
//
//  Created by MP02006 on 2020/11/04.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Util : NSObject

//NSString+Extension.h 이동
//+(NSString*) getPhoneNumbertoAsteriskPhoneNumber:(NSString*) tel;
//+(BOOL) SpecialCharactersCehck:(NSString*)text;

@end

NS_ASSUME_NONNULL_END

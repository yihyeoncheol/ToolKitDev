//
//  Define.m
//  LPoint
//
//  Created by MP02031 on 2020/09/11.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Define.h"

@implementation _Define

+ (_Define *)shared {
    static _Define * obj = nil;
    if (obj == nil) {
        @synchronized(self) {
            if (obj == nil) {
                obj = [[self alloc] init];
            }
        }
    }
    return obj;
}

- (void)dealloc{
    _host = nil;
    
}
- (instancetype)init{
    self = [super init];
    if (self) {
        _host = [[HOST alloc]init];
    }
    return self;
}
@end

@implementation HOST


@end

//
//  Push.h
//  LPoint
//
//  Created by MP02031 on 2020/09/11.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Push : NSObject

@property(nonatomic,strong)NSDictionary *aps;
@property(nonatomic,strong)NSString *alert;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *body;
@property(nonatomic,strong)NSString *sound;
@property(nonatomic)NSInteger badge;
@property(nonatomic)NSString *code;
@property(nonatomic)NSString *dc1;

@property(nonnull,nonatomic,strong)NSDictionary *userInfo;

- (instancetype)initWithUserInfo:(NSDictionary*)userInfo;
@end

NS_ASSUME_NONNULL_END

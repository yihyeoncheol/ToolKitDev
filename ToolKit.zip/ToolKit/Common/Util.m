//
//  Util.m
//  LPoint
//
//  Created by MP02006 on 2020/11/04.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Util.h"

@implementation Util
#if 0
//NSString+Extension.h 이동
+ (NSString*) getPhoneNumbertoAsteriskPhoneNumber:(NSString*) tel{
    NSMutableString *strPhoneNum = [NSMutableString stringWithString:tel];
    NSString *asteriskTel = @"";
    
    if(strPhoneNum.length == 11) {
        NSString *tel1 = [strPhoneNum substringToIndex:3];   // 010
    
        NSString *tel2 = [strPhoneNum substringFromIndex:3]; // 중간 자리
        NSString *tel3 = [tel2 substringFromIndex:4];        // 마지막 자리
    
        tel2 = [tel2 substringToIndex:2];
        tel2 = [NSString stringWithFormat:@"%@**",tel2];
    
        tel3 = [tel3 substringToIndex:2];        // 마지막 자리
        tel3 = [NSString stringWithFormat:@"%@**",tel3];
    
        asteriskTel = [NSString stringWithFormat:@"%@-%@-%@", tel1, tel2, tel3];
    }
    else {
        NSString *tel1 = [strPhoneNum substringToIndex:3];   // 010
    
        NSString *tel2 = [strPhoneNum substringFromIndex:3]; // 중간 자리
        NSString *tel3 = [tel2 substringFromIndex:3];        // 마지막 자리
    
        tel2 = [tel2 substringToIndex:1];
        tel2 = [NSString stringWithFormat:@"%@**",tel2];
    
        tel3 = [tel3 substringToIndex:2];        // 마지막 자리
        tel3 = [NSString stringWithFormat:@"%@**",tel3];
    
        asteriskTel = [NSString stringWithFormat:@"%@-%@-%@", tel1, tel2, tel3];
    }
    
    return asteriskTel;
}

+(BOOL) SpecialCharactersCehck:(NSString*)text {
    
    if([text length] == 0){
        return YES;
    }
    
    NSString * regex = nil;
    regex = @"^[ㄱ-힣0-9a-zA-Z]*$";
    NSRange r = [text rangeOfString:regex options:NSRegularExpressionSearch];

    if(r.length == 0) {
        return NO;

    }

    return YES;
}
#endif
@end

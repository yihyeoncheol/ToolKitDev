//
//  Message.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "Message.h"

@implementation Message

- (void)dealloc
{
    _name = nil;
    _object = nil;
}

+ (Message*)messageWithObject:(id)object
{
    Message *message = [[Message alloc]init];
    message->_name = nil;
    message->_object = object;
    return message;
}

+ (Message*)messageWithName:(NSString*)name object:(id)object
{
    Message *message = [[Message alloc]init];
    message->_name = name;
    message->_object = object;
    return message;
}

@end

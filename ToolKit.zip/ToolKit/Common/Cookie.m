//
//  Cookie.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "Cookie.h"

@implementation Cookie

- (void)dealloc{
    _userDefaults = nil;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _userDefaults = [NSUserDefaults standardUserDefaults];
    }
    return self;
}
- (void)setAttribute:(NSString*)name value:(NSString*)value {
    [_userDefaults setObject:value forKey:name];
    [self writeCookie];
}


- (NSString*)getAttribute:(NSString*)aName {
    NSString *cookie = [_userDefaults objectForKey:aName];
    return cookie;
}

- (void)removeAttribute:(NSString*)aName{
    [_userDefaults removeObjectForKey:aName];
    [self writeCookie];
}

- (void)removeAllAttribute{
    NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
    [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
    [self writeCookie];
}

- (BOOL)writeCookie {
    return [_userDefaults synchronize];
}

@end

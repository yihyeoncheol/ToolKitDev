//
//  LinkData.h
//  LPoint
//
//  Created by MP02031 on 2020/09/11.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSInteger, LinkDataType) {
    LinkDataTypeWeb         = 0,    //
    LinkDataTypeNative      = 1,    //
    LinkDataTypeOutside     = 2,
    LinkDataTypeNone        = 3     //
};

@interface LinkData : NSObject

@property(nonatomic)LinkDataType type;
@property(nullable,nonatomic,strong)NSString *screen;
@property(nullable,nonatomic,strong)NSString *url;
@property(nullable,nonatomic,strong)NSDictionary<NSString*,NSString*> *query;

@end

NS_ASSUME_NONNULL_END

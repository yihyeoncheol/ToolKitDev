//
//  Define.h
//  LPoint
//
//  Created by MP02031 on 2020/09/11.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define Define [_Define shared]
@class HOST;

@interface _Define : NSObject
+ (_Define *)shared;
@property(nonatomic,strong,readonly)HOST *host;
@end

@interface HOST : NSObject
//+ (NSString*)path:(NSString*)path;
@end


NS_ASSUME_NONNULL_END

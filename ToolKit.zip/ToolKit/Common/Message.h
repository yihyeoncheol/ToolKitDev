//
//  Message.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Message : NSObject
+ (Message*)messageWithObject:(nullable id)object;
+ (Message*)messageWithName:(NSString*)name object:(nullable id)object;
@property(nonatomic,readonly)NSString *name;
@property(nonatomic,readonly)id object;
@end

NS_ASSUME_NONNULL_END

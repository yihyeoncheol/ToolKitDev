//
//  Push.m
//  LPoint
//
//  Created by MP02031 on 2020/09/11.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Push.h"
#import "finger.h"

@implementation Push
    
- (void)dealloc {    
    _userInfo   = nil;
    _aps        = nil;
    _alert      = nil;
    _title      = nil;
    _title      = nil;
    _sound      = nil;
    
   _code = nil;
   _dc1 = nil;
}

- (instancetype)initWithUserInfo:(NSDictionary*)userInfo {
    self = [super init];
    
    if (self) {
        self.userInfo   = userInfo;
        self.aps        = _userInfo[@"aps"];
        
        if([[self.aps objectForKey:@"alert"] isKindOfClass:[NSString class]]){
            self.alert      = _aps[@"alert"];
        } else {
            NSDictionary* alert = [_aps objectForKey:@"alert"];
            self.title      = alert[@"title"];
            self.body      = alert[@"body"];
        }
        
        if(![_userInfo[@"dc1"] isEqual:[NSNull null]] ){
            self.dc1 = _userInfo[@"dc1"];
        }
        
        if(![_userInfo[@"code"] isEqual:[NSNull null]] ){
            self.code = _userInfo[@"code"];
        }
        
        self.badge      = [_userInfo[@"badge"] integerValue];
        self.sound      = _userInfo[@"sound"];
    }
    return self;
}

@end


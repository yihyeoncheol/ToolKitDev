//
//  ActionSheetContentView.m
//  LPoint
//
//  Created by MP02031 on 2020/10/22.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "ActionSheetContentView.h"

@interface ActionSheetContentView()
@end

@implementation ActionSheetContentView

- (IBAction)buttonTouchUpInside:(Button*)button {}
- (IBAction)componentValueChanged:(Component*)component {}
- (IBAction)componentTouchUpInside:(Component*)component {}

- (void)setData:(id)data {
    
}

- (void)dismiss{
    
}

@end

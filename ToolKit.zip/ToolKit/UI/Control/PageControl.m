//
//  PageControl.m
//  LPoint
//
//  Created by MP02031 on 2020/11/03.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "PageControl.h"


@interface PageControl()
@property(nonatomic,strong) NSMutableArray <ImageView*> *components;
@property(nonatomic,strong) ScrollView *contentView;

@property(nonatomic,strong) ImageView *specialIndicator;
@property(nonatomic) NSInteger specialIndicatorIndex;
@end

@implementation PageControl

- (void)dealloc {
    _indicatorTintColor = nil;
    _currentIndicatorTintColor = nil;
    _components = nil;
    _contentView = nil;
    _specialIndicator = nil;
}

- (void)initial {
    _currentPage = 0;
    
    _specialIndicatorIndex = -1;
    
    _indicatorTintColor = [UIColor rgbColorWithRed:216 green:216 blue:216 alpha:1];
    _currentIndicatorTintColor = [UIColor rgbColorWithRed:0 green:155 blue:250 alpha:1];;
    _indicatorSize = CGSizeMake(5, 5);
    _currentIndicatorSize = CGSizeMake(5, 5);
    _spacing = 6;
    _contentView = [[ScrollView alloc]initWithFrame:self.bounds];
    _contentView.showsVerticalScrollIndicator = NO;
    _contentView.showsHorizontalScrollIndicator = NO;
    [self addSubview:_contentView];
    _components = [[NSMutableArray alloc]init];
}

- (void)didLoad {
    
}
- (void)layoutSubviews {
    [super layoutSubviews];
    _contentView.frame = self.bounds;
    [self update];
}

- (void)setNumberOfPages:(NSInteger)numberOfPages {
    _numberOfPages = numberOfPages;
    [self paint];
    [self update];
}

- (void)setCurrentPage:(NSInteger)currentPage {
    _currentPage = currentPage;
    for(int i = 0 ; i< _components.count ; i ++ ) {
       ImageView *indicator = _components[i];
        indicator.highlighted = NO;
        if (i == _currentPage) {
            indicator.highlighted = YES;
        }
    }
    
    [self update];
}

- (void)setSpecialIndicator:(ImageView*)indicator index:(NSInteger)index {
    self.specialIndicator = indicator;
    _specialIndicatorIndex = index;
    ImageView *imageView = _components[index];
    [_components removeObject:imageView];
    [imageView removeFromSuperview];
    [_components insertObject:indicator atIndex:index];
    [_contentView addSubview:indicator];
    
    
    [self update];
}


- (void)setContentHorizontalAlignment:(UIControlContentHorizontalAlignment)contentHorizontalAlignment {
    super.contentHorizontalAlignment = contentHorizontalAlignment;
    [self update];
    
}
- (void)update {
    CGFloat allWidth = ((_numberOfPages - 1) * (_indicatorSize.width + _spacing)) + _currentIndicatorSize.width;
    
    if (_specialIndicatorIndex < 0) {
    }else {
        allWidth = ((_numberOfPages - 1) * (_indicatorSize.width + _spacing)) + _specialIndicator.frame.size.width;
    }
    
    
    
         
    CGFloat x = 0;//
    
    
    switch (self.contentHorizontalAlignment) {
        case UIControlContentHorizontalAlignmentCenter: {
            x = (_contentView.frame.size.width - allWidth)/ 2.0;
        }
            break;
        case UIControlContentHorizontalAlignmentLeft:
        {
        }
            break;
        case UIControlContentHorizontalAlignmentRight:
            break;
        default:
            break;
    }
    
    CGFloat start_point = x;
    CGFloat y = (_contentView.frame.size.height - _indicatorSize.height) / 2.0;
    
    for(int i = 0 ; i< _components.count ; i ++ ) {
        ImageView *indicator = _components[i];
//        CGFloat indicatorWidth = indicator.bounds.size.width;
//        CGFloat indicatorheight = indicator.bounds.size.height;
        indicator.contentMode = UIViewContentModeScaleToFill;
        
        
        if (i == _currentPage) {
            indicator.highlighted = YES;
            if (i == _specialIndicatorIndex) {
                CGFloat cy = (_contentView.frame.size.height - indicator.bounds.size.height) / 2.0;
                indicator.frame = CGRectMake(start_point, cy, indicator.bounds.size.width, indicator.bounds.size.height);
            }else{
                CGFloat cy = (_contentView.frame.size.height - _currentIndicatorSize.height) / 2.0;
                indicator.frame = CGRectMake(start_point, cy, _currentIndicatorSize.width, _currentIndicatorSize.height);
            }
        }else{
            indicator.highlighted = NO;
            if (i == _specialIndicatorIndex) {
                CGFloat cy = (_contentView.frame.size.height - indicator.bounds.size.height) / 2.0;
                indicator.frame = CGRectMake(start_point, cy, indicator.bounds.size.width, indicator.bounds.size.height);
            }else{
                indicator.frame = CGRectMake(start_point, y, _indicatorSize.width, _indicatorSize.height);
            }
        }
        
        [indicator roundWithRadius:indicator.bounds.size.height / 2.0 width:0 color:nil];
        start_point += indicator.bounds.size.width + _spacing;
    }
}

- (void)paint {
    
    CGFloat allWidth = ((_numberOfPages) * (_indicatorSize.width + _spacing)) ;
    
    if (_specialIndicatorIndex < 0) {
    }else {
        allWidth = ((_numberOfPages - 1) * (_indicatorSize.width + _spacing)) + _specialIndicator.frame.size.width;
    }
//    CGFloat height = _indicatorSize.height;
     
    CGFloat x = 0;//
    
    
    switch (self.contentHorizontalAlignment) {
        case UIControlContentHorizontalAlignmentCenter:
        {
            x = (_contentView.frame.size.width - allWidth);
        }
            break;
        case UIControlContentHorizontalAlignmentLeft:
        {
        }
            break;
        case UIControlContentHorizontalAlignmentRight:
            break;
        default:
            break;
    }
    
    CGFloat start_point = 0;
    
    for (UIView *view in _components){
        [view removeFromSuperview];
    }
    
    [_components removeAllObjects];
    
    for(int i = 0 ; i< _numberOfPages ; i ++ ) {
        ImageView *indicator = [[ImageView alloc]init];
        CGFloat indicatorWidth = _indicatorSize.width;
        CGFloat indicatorheight = _indicatorSize.height;
        indicator.contentMode = UIViewContentModeScaleToFill;
        
//        if (i == 0){
//            indicator.image = [UIImage imageNamed:@"icoIndicatiorPlus"];
//            indicator.highlightedImage = [UIImage imageNamed:@"icoIndicatiorPlusBlue"];
//            indicatorWidth = 14;
//            indicatorheight = 14;
//        }else{
            indicator.image = [UIImage imageWithColor:_indicatorTintColor size:_indicatorSize];
            indicator.highlightedImage = [UIImage imageWithColor:_currentIndicatorTintColor size:_indicatorSize];
//        }
        CGFloat y = (_contentView.frame.size.height - indicatorheight) / 2.0;
        indicator.frame = CGRectMake(start_point, y, indicatorWidth, indicatorheight);

        if (i == _currentPage) {
            indicator.highlighted = YES;
        }
        
        [indicator roundWithRadius:indicatorheight / 2.0 width:0 color:nil];

     
        [_contentView addSubview:indicator];
        [_components addObject:indicator];
        start_point += indicatorWidth + _spacing;
    }
    
    if (_specialIndicatorIndex < 0) {
    }else {
        
        ImageView *imageView = _components[_specialIndicatorIndex];
        [_components removeObject:imageView];
        [imageView removeFromSuperview];
        
        
        
        [_components insertObject:_specialIndicator atIndex:_specialIndicatorIndex];
        [_contentView addSubview:_specialIndicator];
        
        
    }
    
    [self setNeedsStyle];
    
}
#if 0
CGFloat TruncatingReminder(CGFloat x, CGFloat dividingBy) {
    return x - dividingBy * floor(x / dividingBy);
}

- (void)didScroll:(UIScrollView*)scrollView {
        
    CGFloat currentOffset = scrollView.contentOffset.x;
    CGFloat index = currentOffset / scrollView.bounds.size.width;
             
    currentOffset = scrollView.contentOffset.x / scrollView.bounds.size.width * 10;
    index = currentOffset / 10;

        
    CGFloat offsetX = scrollView.contentOffset.x;
    
    offsetX = TruncatingReminder(offsetX,scrollView.bounds.size.width);
    
    if(offsetX == 0){
    }
        
    ImageView *currentPageIndicator = _components[_currentPage];

        if (_currentPage > index) {
            
            ImageView *nextPageIndicator = _components[_currentPage - 1];

            CGFloat width = 0.0;
           
            if(offsetX == 0){
                width = 12;
            }else{
                width = 12 - ((offsetX / scrollView.bounds.size.width) * 8);
            }
            
            
            nextPageIndicator.frame = CGRectMake(nextPageIndicator.frame.origin.x,
                                                 nextPageIndicator.frame.origin.y,
                                                 width,
                                                 nextPageIndicator.frame.size.height);
            
            
            width = 0.0;
            if(offsetX == 0){
                width = 4;
            }else{
                width = 4 + ((offsetX / scrollView.bounds.size.width) * 8);
            }
            
            currentPageIndicator.frame  = CGRectMake(3,
                                                     currentPageIndicator.frame.origin.y,
                                                     width,
                                                     currentPageIndicator.frame.size.height);
            
            currentPageIndicator.backgroundColor = _indicatorTintColor;
            nextPageIndicator.backgroundColor = _currentIndicatorTintColor;
            
        }else if (_currentPage < index) {
            
            
            if (_currentPage + 1 >= _numberOfPages){
                return;
            }
            
            
            CGFloat width   = 0.0;
            if(offsetX == 0){
                width = 4.0;
            }else{
                width = 12 - ((offsetX / scrollView.bounds.size.width) * 8);
            }
            
            currentPageIndicator.frame  = CGRectMake(currentPageIndicator.frame.origin.x,
                                                     currentPageIndicator.frame.origin.y,
                                                     width,
                                                     currentPageIndicator.frame.size.height);
            
            
            
            ImageView *nextPageIndicator = _components[_currentPage + 1];
//            nextPageIndicatorIndex = currentPage + 1
            width = 0.0;
            if(offsetX == 0){
                width = 12.0;
            }else{
                width = 4 + ((offsetX / scrollView.bounds.size.width) * 8);
            }
            
            nextPageIndicator.frame  = CGRectMake(CGRectGetMaxX(currentPageIndicator.frame) + 6,
                                                  nextPageIndicator.frame.origin.y,
                                                  width,
                                                  nextPageIndicator.frame.size.height);
            
            
            
            currentPageIndicator.backgroundColor = _indicatorTintColor;
            nextPageIndicator.backgroundColor = _currentIndicatorTintColor;

        }
        
    currentOffset = scrollView.contentOffset.x;
    index = currentOffset / scrollView.bounds.size.width;
        
//        //페이징 스크롤이 완전히 끝나야 페이지 인덱스가 바뀜
    
    
    
    
//        if (TruncatingReminder(currentOffset, scrollView.bounds.size.width) == 0) {
//            _currentPage = index
//            if (_currentPage != currentPage) {
//                currentPage = _currentPage;
//            }
//            for (ImageView *indicator in _components){
//                indicator.backgroundColor = pageIndicatorTintColor;
//            }
//
//            let current = indicators[currentPage]
//            current.backgroundColor = currentPageIndicatorTintColor
//        }
    }
#endif
@end

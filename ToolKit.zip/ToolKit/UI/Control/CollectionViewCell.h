//
//  CollectionViewCell.h
//  LPoint
//
//  Created by MP02031 on 2020/10/21.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol CollectionViewCellDelegate;
@interface CollectionViewCell : UICollectionViewCell
@property(nonatomic,weak)id <CollectionViewCellDelegate> delegate;
- (void)initial;
- (void)didLoad;
- (void)setData:(nullable id)data ;
- (IBAction)buttonTouchUpInside:(Button *)button;


@end

@protocol CollectionViewCellDelegate <NSObject>
- (void)collectionViewCell:(CollectionViewCell*)cell  message:(Message*) message;

@end


NS_ASSUME_NONNULL_END


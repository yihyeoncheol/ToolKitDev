//
//  TextField.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController;
NS_ASSUME_NONNULL_BEGIN

@interface TextField : UITextField

@property(nullable,nonatomic,strong)IBInspectable NSString *name;
@property(nullable,nonatomic,strong)IBInspectable NSString *style;
@property(nullable,nonatomic,strong)IBInspectable NSString *fontStyle;


@property(nonatomic,strong)IBInspectable UIColor *underLineColor;
@property(nonatomic,strong)IBInspectable UIColor *underLineSelectedColor;
@property(nonatomic,strong)IBInspectable UIColor *placeholderColor;
@property(nonatomic,strong)IBInspectable UIImage *clearImage;

@property(nonatomic)IBInspectable BOOL blankTouch;

@property(nonatomic)UIEdgeInsets contentEdgeInsets;
@property(nonatomic)UIEdgeInsets borderEdgeInsets;
@property(nonatomic)UIEdgeInsets textEdgeInsets;
@property(nonatomic)UIEdgeInsets placeholderEdgeInsets;
//@property(nonatomic)UIEdgeInsets editingEdgeInsets;
@property(nonatomic)UIEdgeInsets clearButtonEdgeInsets;
@property(nonatomic)UIEdgeInsets leftViewEdgeInsets;
@property(nonatomic)UIEdgeInsets rightViewEdgeInsets;

@property(nonatomic,weak) ViewController *vc;
- (void)clearButton;
    


@end

NS_ASSUME_NONNULL_END

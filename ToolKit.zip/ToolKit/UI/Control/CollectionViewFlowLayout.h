//
//  CollectionViewFlowLayout.h
//  LPoint
//
//  Created by MP02031 on 2020/11/12.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol CollectionViewFlowLayoutDelegate;
@interface CollectionViewFlowLayout : UICollectionViewFlowLayout
@property(nonatomic) CGFloat previousOffset;
@property(nonatomic) CGFloat currentPage;
@property(nonatomic,weak)id<CollectionViewFlowLayoutDelegate> delegate;
@end


@protocol CollectionViewFlowLayoutDelegate<NSObject>
- (void)collectionViewLayout:(UICollectionViewLayout*)layout currentPage:(NSInteger)page;
@end


NS_ASSUME_NONNULL_END

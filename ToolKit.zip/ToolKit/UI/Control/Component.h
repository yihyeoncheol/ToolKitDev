//
//  Component.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
IB_DESIGNABLE
@interface Component : UIControl
@property(nullable,nonatomic,strong)IBInspectable NSString *style;
@property(nullable,nonatomic,strong)IBInspectable NSString *name;
@property(nullable,nonatomic,strong) void (^layoutChanged) (id self);
- (void)didLoad;
- (void)initial;
- (void)setNeedsStyle;
- (void)paint;
- (void)update;
@end




NS_ASSUME_NONNULL_END

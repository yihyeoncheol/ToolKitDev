//
//  ComponentLayerView.h
//  LPoint
//
//  Created by MP02031 on 2020/10/22.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "LayerView.h"

NS_ASSUME_NONNULL_BEGIN

@interface ComponentLayerView : View

@end

NS_ASSUME_NONNULL_END

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "View.h"
@interface Toast : View

+ (void)toastwithText:(NSString *)text;
+ (void)toastInView:(UIView *)parentView withText:(NSString *)text;

@end

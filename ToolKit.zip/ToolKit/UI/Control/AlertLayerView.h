//
//  AlertPanel.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/09/01.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "View.h"

NS_ASSUME_NONNULL_BEGIN

@interface AlertLayerView : View

@end

NS_ASSUME_NONNULL_END

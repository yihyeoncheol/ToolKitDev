//
//  Label.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "Label.h"

@implementation Label

- (void)dealloc {
    NSArray *keys = @[@"fontStyle"];
    for (NSString *key in keys) {
        [self removeObserver:self forKeyPath:key];
    }
    _fontStyle = nil;
}

- (id)init{
    self = [super init];
    if(self){

    }
    return self;
}

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initial];
    }
    return self;
}

- (void)initial {
    
#if (TARGET_IPHONE_SIMULATOR)
    [self roundWithRadius:0.f width:.5f color:[UIColor blackColor]];
#endif
    
    NSArray *keys = @[@"fontStyle"];
    for (NSString *key in keys) {
        [self addObserver:self forKeyPath:key options:NSKeyValueObservingOptionNew context:nil];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    
    if ([keyPath isEqualToString:@"fontStyle"]) {
        SEL selector = NSSelectorFromString(_fontStyle.lowercaseString);
        if([self respondsToSelector:selector]){
            IMP imp = [self methodForSelector:selector];
            void (*func)(id, SEL) = (void *)imp;
            func(self, selector);
        }
    }else{
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

@end

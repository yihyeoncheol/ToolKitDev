//
//  WhiteboardView.m
//  Tin-Can-Whiteboard
//
//  Created by Paula Jacobs on 6/1/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//
#import "WhiteboardView.h"
#import <QuartzCore/QuartzCore.h>
#import <math.h>

@implementation WhiteboardView

@synthesize strokes;
@synthesize currentStrokeColor;


#pragma mark - Initialize

- (id)initWithFrame:(CGRect)frame delegate:(id<WhiteboardViewDelegate>)del {
    if ((self = [super initWithFrame:frame]))
	{
        self.delegate = del;
        rectView = frame;
        
        startOfStroke = CGPointMake(0.0, 0.0);
		location = CGPointMake(0.0, 0.0);
		strokes = [NSMutableArray array] ;
		activeStrokes = CFDictionaryCreateMutable(NULL,0,NULL,NULL);
		
		currentStrokeColor = [UIColor blackColor];
		currentStrokeWidth = 2.0;
        
        [self setBackgroundColor:[UIColor clearColor]];
        
        _isTouch = NO;
        
    //    colorArray = [[NSMutableArray alloc] init];
    }
    
    return self;
}

#pragma mark - and so on...

- (void)drawRect:(CGRect)rect
{
    
    
    // Drawing code
	CGContextRef ctx = UIGraphicsGetCurrentContext();
	//if we have a context
	if(ctx != nil)
    {
		CGContextSetRGBFillColor(ctx, 0, 0, 0, 0);
		CGContextFillRect(ctx, rectView);
    }
	if ([strokes count] > 0)  //under the condition that there is something in our Array
    {
		for (int c=0; c< [strokes count]; c++) //as long as we don't go past the number of available objects
        {
			NSArray *storedInfo=[strokes objectAtIndex:c];//lets name the array at that index 
			NSArray *storedPoints=[storedInfo objectAtIndex:2];
            
			if ([[storedInfo objectAtIndex:0]isEqual:[UIColor blackColor]])
            {
				CGContextSetRGBStrokeColor(ctx, 0, 0, 0, 1);
				CGContextSetLineWidth(ctx, [[storedInfo objectAtIndex:1]floatValue] );
            }
			else
            {
				//NSLog(@"Color %@:", currentStrokeColor);
				UIColor *strokeColor =[storedInfo objectAtIndex:0];
				CGContextSetStrokeColorWithColor(ctx, strokeColor.CGColor);
				//CGContextSetRGBStrokeColor(ctx, 1, 0, 0, 1);
				CGContextSetLineWidth(ctx, [[storedInfo objectAtIndex:1]floatValue]);
				//NSLog(@" StrokeSize %@:", [storedInfo objectAtIndex:1]);
                
                CGContextSetShouldAntialias(UIGraphicsGetCurrentContext(), YES);
                CGContextSetLineCap(ctx, kCGLineCapRound);
			}
			if ([storedPoints count] > 2 )  //if we have at least one full x,y pair
            {
                float befoX=[[storedPoints objectAtIndex:0] floatValue];
				float befoY=[[storedPoints objectAtIndex:1] floatValue];
                CGContextBeginPath(ctx);//Lets start a path
				//CGContextMoveToPoint(ctx, storedX, storedY);// and start where we first touched
                
                
				//for (int i =2; i < [storedPoints count]; i+=2)  // as long as there are xy pairs left in our array
                for (int i =2; i < [storedPoints count]; i+=2)  // as long as there are xy pairs left in our array
                {
                    CGContextMoveToPoint(ctx, befoX, befoY);
                    
					//store them as a float in a variable so we can use them
					float storedX=[[storedPoints objectAtIndex:i] floatValue];
					float storedY=[[storedPoints objectAtIndex:i+1] floatValue];
                    //lets create a line between them, then move to the end of that line
					CGContextAddLineToPoint (ctx, storedX, storedY);
                    
                    befoX = storedX;
                    befoY = storedY;
				}
                
				CGContextStrokePath(ctx);        
            }
        }
    }
	
    // 브러시 크기 표시..
	CGContextSetStrokeColorWithColor(ctx, currentStrokeColor.CGColor);
	CGContextSetFillColorWithColor(ctx, currentStrokeColor.CGColor);
	//CGContextAddEllipseInRect(ctx, CGRectMake(	400, 60, currentStrokeWidth, currentStrokeWidth));
	CGContextAddArc(ctx, 118, 735, currentStrokeWidth/2.0, 0, 2* M_PI, 0);
	CGContextFillPath(ctx);	
	CGContextStrokePath(ctx);	
}

-(NSMutableArray *)makeNewStrokeWithColor:(UIColor *)color withWidth:(NSInteger)width
{
	NSMutableArray *newStroke = [[NSMutableArray alloc] initWithCapacity:3];
	
	[newStroke addObject: color];
	[newStroke addObject: [NSNumber numberWithInteger:width]];
	[newStroke addObject: [NSMutableArray array]];
    
	return newStroke;
}

-(void)eraseAll
{
    [strokes removeAllObjects];
    [self.delegate drawEnd];
	[self setNeedsDisplay];
}

-(void)notErasingAnymore
{
	//eraserButton.isErasing=false;
	[self setNeedsDisplay];
}	

-(void)changeColorWithColor:(UIColor *)color
{
	currentStrokeColor = color;
	
    //NSLog(@" setting color to	%@:", currentStrokeColor);
    
	[self setNeedsDisplay];
}	

-(void)changeButtonLocatorLocationWithFrame:(CGRect)frame
{
	[self setNeedsDisplay];
}

-(void)changeStrokeWidthWithDirection:(NSString *) directionOfChange
{
	if (( [directionOfChange isEqualToString:@"+"] ) & (currentStrokeWidth<60))
    {
		currentStrokeWidth = currentStrokeWidth + 2; 
		//NSLog(@" changing size up to %d:", currentStrokeWidth);
	}
	else if (( [directionOfChange isEqualToString:@"-"] ) & (currentStrokeWidth>1))
    {
		currentStrokeWidth = currentStrokeWidth - 2; 
		//NSLog(@" changing size down to %d:", currentStrokeWidth);
	}
	
	[self setNeedsDisplay];
}	

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self.dele drawStart];
	if ([[event allTouches] count] > 0)
    {
		for (UITouch *touch in [event allTouches])
        {
            startOfStroke = [touch locationInView:self];
            rRectView = CGRectMake(0, 0, rectView.size.width,rectView.size.height);
            if (rRectView.size.height > 81){
                rRectView = rectView;
            }
            if (CGRectContainsPoint(rRectView, startOfStroke)) {

                if (!_isTouch) {
                    NSLog(@"point in rect");
                    NSLog(@"pos %.2f        %.2f", startOfStroke.x, startOfStroke.y);
                    _isTouch = true;
                    [self.delegate drawStart];
                }
            }
			//Make a new Stroke
			NSMutableArray *newStroke = [self makeNewStrokeWithColor:currentStrokeColor withWidth:currentStrokeWidth];
                
			[[newStroke lastObject] addObject:[NSNumber numberWithFloat: startOfStroke.x]];
            [[newStroke lastObject] addObject:[NSNumber numberWithFloat: startOfStroke.y]];
           
            CFDictionarySetValue(activeStrokes, (void *)touch, (void *)newStroke);
			[strokes addObject: newStroke];
		}
	}	
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	for (int i =0; i < [[event allTouches] count]; i++)
    {
		UITouch *currentTouch = [[[event allTouches] allObjects] objectAtIndex:i];
		location = [currentTouch locationInView:self];
		NSMutableArray *stroke= (NSMutableArray *)CFDictionaryGetValue (activeStrokes, (void *)currentTouch);
		if (stroke == NULL)
        {
			NSMutableArray *newStroke = [self makeNewStrokeWithColor:currentStrokeColor withWidth:currentStrokeWidth];
			[[newStroke lastObject] addObject:[NSNumber numberWithFloat: location.x]];
			[[newStroke lastObject] addObject:[NSNumber numberWithFloat: location.y]];
				
			CFDictionarySetValue(activeStrokes, (void *)currentTouch, (void *)&newStroke);
			[strokes addObject: newStroke];
		}
		else if (![[event allTouches] containsObject:currentTouch])
        {
			CFDictionaryRemoveValue (activeStrokes, (void *)currentTouch);
		}
		else
        {
			NSUInteger index= [strokes indexOfObject:stroke];
			[[stroke lastObject] addObject:[NSNumber numberWithFloat: location.x]];
			[[stroke lastObject] addObject:[NSNumber numberWithFloat: location.y]];
            if (stroke != nil) //YYM 15.12.28 그림을 마구 그릴때 나는 앱종료현상때문에 추가
			[strokes replaceObjectAtIndex:index withObject:stroke];
			CFDictionaryReplaceValue (activeStrokes, (void *)currentTouch, (void *)stroke);
		}
	}
	
	[self setNeedsDisplay];
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
//    [self.dele drawEnd];
    
	for (int i =0; i < [[event allTouches] count]; i++)
    {
        UITouch *currentTouch = [[[event allTouches] allObjects] objectAtIndex:i];
		location = [currentTouch locationInView:self];
		NSMutableArray *stroke= (NSMutableArray *)CFDictionaryGetValue (activeStrokes, (void *)currentTouch);
		NSUInteger index= [strokes indexOfObject:stroke];
        [[stroke lastObject] addObject:[NSNumber numberWithFloat: location.x]];
		[[stroke lastObject] addObject:[NSNumber numberWithFloat: location.y]];
        if (stroke != nil) //YYM 15.12.28 그림을 마구 그릴때 나는 앱종료현상때문에 추가
		[strokes replaceObjectAtIndex:index withObject:stroke];
		CFDictionaryRemoveValue (activeStrokes, (void *)currentTouch);
	}
    
    if ([[event allTouches] count] == 1) {
        if (_isTouch) {
            NSLog(@"board draw end");
            _isTouch = NO;
            [self.delegate drawEnd];
        }
    }

	[self setNeedsDisplay]; 
}

- (void)dealloc
{
    [strokes removeAllObjects];
  	//[strokes release];
    
    [colorArray removeAllObjects];
   // [colorArray release];
    
   // [super dealloc];
}


@end

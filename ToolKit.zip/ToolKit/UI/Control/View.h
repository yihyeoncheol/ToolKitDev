//
//  View.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EdgeLine.h"
@class Message;


NS_ASSUME_NONNULL_BEGIN

@interface View : UIView
@property(nullable,nonatomic,copy)IBInspectable NSString *name;
@property(nullable,nonatomic,copy)IBInspectable NSString *style;

@property(nullable,nonatomic,strong) void (^layoutChanged) (id self);
@property(nullable,nonatomic,strong,setter=event:) void (^event) (Message *message);
@property(nullable,nonatomic,strong) NSArray<EdgeLine*> *edgeLines;
- (void)didLoad;
- (void)initial;
- (void)setData:(id)data;

@end

NS_ASSUME_NONNULL_END

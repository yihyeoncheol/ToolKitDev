//
//  ShadowView.m
//  LPoint
//
//  Created by MP02031 on 2020/12/04.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "ShadowView.h"

@implementation ShadowView

- (void)dealloc {
    NSArray *keys = @[
        @"color",
        @"offset",
        @"opacity",
        @"radius"
    ];

    for (NSString *key in keys) {
        [self removeObserver:self forKeyPath:key];
    }
}
- (void)initial {
    
    self.backgroundColor = [UIColor clearColor];
    _color = [UIColor rgbColorWithRed:0 green:0 blue:0 alpha:0.15f];
    _offset = CGSizeMake(0, 10);
    _opacity = 1.f;
    _radius = 10;
    
    
    
    NSArray *keys = @[
        @"color",
        @"offset",
        @"opacity",
        @"radius"
    ];
    
    for (NSString *key in keys) {
        [self addObserver:self forKeyPath:key options:NSKeyValueObservingOptionNew context:nil];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    
    if ([keyPath isEqualToString:@"color"]||
        [keyPath isEqualToString:@"offset"]||
        [keyPath isEqualToString:@"opacity"]||
        [keyPath isEqualToString:@"radius"]) {
        [self shadowWithColor:_color offset:_offset opacity:_opacity radius:_radius];
        
    }else{
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self shadowWithColor:_color offset:_offset opacity:_opacity radius:_radius];
}
@end

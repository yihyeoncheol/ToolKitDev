//
//  CollectionViewCell.m
//  LPoint
//
//  Created by MP02031 on 2020/10/21.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

- (void)dealloc {
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self didLoad];
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self){
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self){
        [self initial];
    }
    return self;
}



- (UICollectionViewLayoutAttributes *)preferredLayoutAttributesFittingAttributes:(UICollectionViewLayoutAttributes *)layoutAttributes {
    return [super preferredLayoutAttributesFittingAttributes:layoutAttributes];
}

- (void)initial {}

- (void)didLoad {}

- (void)setData:(id)data{}

- (IBAction)buttonTouchUpInside:(Button *)button{}

@end

//
//  ActionSheetContentView.h
//  LPoint
//
//  Created by MP02031 on 2020/10/22.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "View.h"
#import "ActionSheet.h"

NS_ASSUME_NONNULL_BEGIN
//@class ActionSheet;
@protocol ActionSheetContentViewDelegate;


@interface ActionSheetContentView : View
@property(nonatomic,strong) ActionSheet *actionSheet;
@property(nonatomic,weak)id <ActionSheetContentViewDelegate> delegate;
@property(nonatomic,weak)IBOutlet UIView *contentView;
- (IBAction)buttonTouchUpInside:(Button*)button;
- (IBAction)componentValueChanged:(Component*)component;
- (IBAction)componentTouchUpInside:(Component*)component;
- (void)setData:(id)data;
- (void)dismiss;
@end


@protocol ActionSheetContentViewDelegate <NSObject>
- (void)actionSheetContentView:(ActionSheetContentView*)contentView message:(Message*) message;
@end

//@protocol ActionSheetEventDelegate <NSObject>
//- (void)actionSheetContentView:(ActionSheetContentView*)contentView message:(Message*) message;
//@end


NS_ASSUME_NONNULL_END

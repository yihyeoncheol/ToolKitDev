//
//  NavigationBar.h
//  LPoint
//
//  Created by MP02031 on 2020/09/15.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "View.h"
#import "ScrollView.h"

NS_ASSUME_NONNULL_BEGIN

@interface NavigationBar : View

@property(nonatomic)UIEdgeInsets titleEdgeInsets;
@property(nonatomic,strong, readonly)Label *titleLabel;
@property(nonatomic,strong)NSString *title;
@property(nonatomic)CGFloat statusBarTopOffset;
@property(nonatomic,weak) IBOutlet NSLayoutConstraint *viewTopContraint;
@property(nonatomic,weak) IBOutlet UIScrollView *scrollView;

- (void)didScroll:(UIScrollView*)scrollView;
@end

NS_ASSUME_NONNULL_END

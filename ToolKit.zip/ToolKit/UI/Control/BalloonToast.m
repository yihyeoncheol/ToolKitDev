//
//  BalloonToast.m
//  LPoint
//
//  Created by MP02031 on 2020/12/14.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "BalloonToast.h"
@interface BalloonToast()
@property(nonatomic)CAShapeLayer *roundLayer;
@property(nonatomic)CGPoint point;
@property(nonatomic)UIRectEdge edge;
@end

@implementation BalloonToast

+ (BalloonToast*)toastWithText:(NSString*)text {
    BalloonToast *toast = [BalloonToast new];
    toast.text = text;
    return toast;
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)initial {
    
    _contentEdgeInsets = UIEdgeInsetsZero;
    _textEdgeInsets = UIEdgeInsetsMake(10, 10, 10, 10);
    
    _point = CGPointZero;
    
    _height = 25;
    _edge = UIRectEdgeBottom;
    _textColor = [UIColor rgbColorWithRed:34 green:34 blue:34 alpha:1];
//    _backgroundColor  = [UIColor rgbColorWithRed:237 green:237 blue:237 alpha:1];;
    
    
    _roundLayer = [[CAShapeLayer alloc]init];
    
    _roundLayer.frame = self.bounds;
    
    [self.layer addSublayer:_roundLayer];
    
    self.backgroundColor = [UIColor rgbColorWithRed:237 green:237 blue:237 alpha:1];
    _edge = UIRectEdgeBottom;
    
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(touchEventNotification:)
                                               name:RootControllerTouchEventNotification
                                             object:nil];
    
}


- (void)showInView:(UIView*)inView {
  
    _roundLayer.fillColor = self.backgroundColor.CGColor;
    
    CGRect convertTagetFarme = [_taget convertRect:_taget.bounds toView:inView];
    CGRect rect = inView.bounds;
 
    rect = UIEdgeInsetsInsetRect(rect, _contentEdgeInsets);
    rect = UIEdgeInsetsInsetRect(rect, _textEdgeInsets);
    
    
    Label *textLabel = [[Label alloc]initWithFrame:rect];
    textLabel.text = _text;
    textLabel.textColor = _textColor;
    textLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightLight];
    textLabel.fontStyle = @"NotoSansCJKkr";
    textLabel.textAlignment = NSTextAlignmentLeft;
    textLabel.numberOfLines = 0;
    [textLabel sizeToFit];
    [self addSubview:textLabel];
    
    CGRect textRect = textLabel.frame;
    CGFloat h = MAX(textRect.size.height, _height);
    CGFloat y = convertTagetFarme.origin.y;
    
    if (_edge == UIRectEdgeBottom) {
        y += convertTagetFarme.size.height;
        y += 16;
    }else if (_edge == UIRectEdgeTop) {
        y -= convertTagetFarme.size.height;
        y -= h;
        y -= 16;
    }

    CGFloat width = textLabel.bounds.size.width  + (_contentEdgeInsets.left + _contentEdgeInsets.right + _textEdgeInsets.left + _textEdgeInsets.right);
    CGFloat x = (inView.frame.size.width - width) / 2;
    CGRect frame = CGRectMake(x,
                              y,
                              width,
                              h + (_contentEdgeInsets.top + _contentEdgeInsets.bottom + _textEdgeInsets.top + _textEdgeInsets.bottom));
    
    self.frame = UIEdgeInsetsInsetRect(frame, _contentEdgeInsets);
    
    
    textLabel.frame = UIEdgeInsetsInsetRect(self.bounds, _textEdgeInsets);
    [inView addSubview:self];
    
    CGRect convertFarme = [self convertRect:_taget.bounds fromView:_taget];
    
    self.point = CGPointMake(CGRectGetMidX(convertFarme), CGRectGetMidY(convertFarme));
    _roundLayer.path = [self path].CGPath;
    
}

- (UIBezierPath*)path {
    UIBezierPath *path = [UIBezierPath new];
 
    CGFloat radius = 8;
    
    [path addArcWithCenter:CGPointMake(0,0)
                    radius:radius
                startAngle:M_PI
                  endAngle:3*M_PI/2
                 clockwise:YES];
    
    
    CGFloat width = 20;
    CGFloat height = 10;
    CGFloat x = MAX(_point.x - (width / 2), 0);
          

    
    if (_edge == UIRectEdgeBottom) {
        
        [path addLineToPoint:CGPointMake(x ,  -(radius))];
        [path addLineToPoint:CGPointMake(x + (width / 2) , -(radius + height))];
        [path addLineToPoint:CGPointMake(x + width, -(radius))];
        [path addLineToPoint:CGPointMake(self.bounds.size.width - radius , -(radius))];
    }
    
    [path addArcWithCenter:CGPointMake(self.bounds.size.width,0)
                    radius:radius
                startAngle:3*M_PI/2
                  endAngle:2*M_PI
                 clockwise:YES];
    
    [path addArcWithCenter:CGPointMake(self.bounds.size.width,self.bounds.size.height)
                    radius:radius
                startAngle:0
                  endAngle:M_PI/2
                 clockwise:YES];
    
    if (_edge == UIRectEdgeTop) {
        
        [path addLineToPoint:CGPointMake(x ,  self.bounds.size.height + radius)];
        [path addLineToPoint:CGPointMake(x + (width / 2) , self.bounds.size.height + (radius + height))];
        [path addLineToPoint:CGPointMake(x + width, self.bounds.size.height + radius)];
        [path addLineToPoint:CGPointMake(0 , self.bounds.size.height + radius)];
    }
    
    
    [path addArcWithCenter:CGPointMake(0,self.bounds.size.height)
                       radius:radius
                   startAngle:2*M_PI/3
                     endAngle:M_PI
                    clockwise:YES];
    
    [path closePath];
    
    
    return path;
}

//- (void)layoutSubviews {
//
//}

- (void)dismiss{
    [self removeFromSuperview];
}

- (void)touchEventNotification:(NSNotification*)notification {
    UITouch *touch = (UITouch*)notification.object;
    UIView *keyWindow = UIApplication.sharedApplication.keyWindow.rootViewController.view;
    CGPoint point = [touch locationInView:keyWindow];
    
    
//    CGRect convertFarme =  [self convertRect:self.bounds toView:keyWindow];
    CGRect convertFarme = [self.taget convertRect:self.taget.bounds toView:keyWindow];
    BOOL contains = CGRectContainsPoint(convertFarme, point);
               
    if (contains) {
        return;
    }
    [self dismiss];
}
    
@end

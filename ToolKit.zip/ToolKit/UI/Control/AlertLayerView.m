//
//  AlertLayerView.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/09/01.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "AlertLayerView.h"
#import "Alert.h"
#import "UIColor+Extension.h"

@interface AlertLayerView()
@property (nonatomic,strong)UIView *backgroundView;
@end

@implementation AlertLayerView

- (void)dealloc {
}

- (void)initial {
    self.hidden = YES;
    self.backgroundColor = [UIColor clearColor];
    self.backgroundView = [UIView new];
    self.backgroundView.backgroundColor = [UIColor rgbColorWithRed:0 green:0 blue:0 alpha:.7f];
    [self addSubview:self.backgroundView];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.backgroundView.frame = self.bounds;
}


- (void)didAddSubview:(UIView *)subview {
    [super didAddSubview:subview];
    if(self.subviews.count == 2){
        self.hidden = NO;
        self.backgroundView.alpha = 0.5;
        [UIView animateWithDuration:0.3f animations:^{
            self.backgroundView.alpha = 1.0;
        } completion:^(BOOL finished) {
        }];
    }
}
   
- (void)addSubview:(UIView *)view {
    if (self.subviews.count > 1){
        UIView *lastView = self.subviews.lastObject;
        lastView.hidden = NO;
        view.hidden = YES;
        
        [self insertSubview:view atIndex:1];
    }else{
        [super addSubview:view];
    }
}

- (void)willRemoveSubview:(UIView *)subview {
    [super willRemoveSubview:subview];
    NSInteger count = self.subviews.count;
    if(count == 2){
        [UIView animateWithDuration:0.3f animations:^{
            self.backgroundView.alpha = 0.0;
        } completion:^(BOOL finished) {
            self.hidden = YES;
        }];
    }else if(count > 2){
        UIView *view = [self.subviews objectAtIndex:count - 2];
        Alert *alert = (Alert*)view;
        alert.hidden = NO;
        alert.alpha = 0;
        SEL selector = NSSelectorFromString(@"showAnimation");
        if([view respondsToSelector:selector]){
            IMP imp = [view methodForSelector:selector];
            void (*func)(id, SEL) = (void*)imp;
            func(view, selector);
        }
    }
}

@end

//
//  ShadowView.h
//  LPoint
//
//  Created by MP02031 on 2020/12/04.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "View.h"

NS_ASSUME_NONNULL_BEGIN

@interface ShadowView : View
@property(nullable,nonatomic,strong)IBInspectable UIColor *color;
@property(nonatomic)IBInspectable CGSize offset;
@property(nonatomic)IBInspectable CGFloat opacity;
@property(nonatomic)IBInspectable CGFloat radius;

@end

NS_ASSUME_NONNULL_END

//
//  ImageView.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "ImageView.h"

@implementation ImageView

- (void)dealloc {
        NSArray *keys = @[@"cornerRadius",
                      @"borderWidth",
                      @"borderColor"];

    for (NSString *key in keys) {
        [self removeObserver:self forKeyPath:key];
    }

    
    _borderColor = nil;
}

- (instancetype)initWithImage:(UIImage *)image highlightedImage:(UIImage *)highlightedImage {
    self = [super initWithImage:image highlightedImage:highlightedImage];
    if (self){
        [self initial];
    }
    return self;
}

- (instancetype)initWithImage:(UIImage *)image {
    self = [super initWithImage:image];
    if (self){
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self){
        [self initial];
    }
    return self;
}

- (id)init{
    self = [super init];
    if (self){
        [self initial];
    }
    return self;
}

- (void)initial {
    
#if (TARGET_IPHONE_SIMULATOR)
//    [self roundWithRadius:0.f width:.5f color:[UIColor blackColor]];
#endif
    
    _cornerRadius = 0;
    _borderWidth = 0;
    
    NSArray *keys = @[@"cornerRadius",
                      @"borderWidth",
                      @"borderColor"];
    
    for (NSString *key in keys) {
        [self addObserver:self forKeyPath:key options:NSKeyValueObservingOptionNew context:nil];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"cornerRadius"]||
        [keyPath isEqualToString:@"borderWidth"]||
        [keyPath isEqualToString:@"borderColor"]) {
        [self roundWithRadius];
    }else{
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)roundWithRadius {
    [self.layer setCornerRadius:_cornerRadius];
    [self.layer setBorderWidth:_borderWidth];
    [self.layer setMasksToBounds:YES];
    if (_borderColor) {
        [self.layer setBorderColor: _borderColor.CGColor];
    }
}


@end

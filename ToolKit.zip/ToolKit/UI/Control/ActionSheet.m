//
//  ActionSheet.m
//  LPoint
//
//  Created by MP02031 on 2020/09/17.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "ActionSheet.h"
#import "Label.h"
#import "ComponentLayerView.h"

@interface ActionSheet()

@property(nonnull,nonatomic,strong)UIView *titleView;
@property(nonatomic)BOOL isShowInView;
@end

@implementation ActionSheet

- (void)dealloc {
     _title = nil;
    _contentView = nil;
    _titleView = nil;
}

- (void)initial {
    
    _titleHeight = 40.0f;
    _contentHeight = 20.0f;
    
    self.backgroundColor = [UIColor whiteColor];
//    _contentView = [ActionSheetContentView new];
    
    _reverse = NO;
}


- (UIView*)titleView:(CGRect)frame {
    
    View *container = [[View alloc]initWithFrame:frame];
    container.backgroundColor = [UIColor whiteColor];
    
    CGRect slice;
    CGRect remainder;
    
    CGRectDivide(UIEdgeInsetsInsetRect(container.bounds, UIEdgeInsetsMake(0, 10, 0, 10)),
                 &slice, &remainder,
                 frame.size.height,
                 CGRectMaxXEdge);
    
    
    Label *label = [[Label alloc]initWithFrame:remainder];
    label.text = self.title;
    label.numberOfLines = 1;
    label.textAlignment = NSTextAlignmentLeft;
    label.font = [UIFont systemFontOfSize:13];
    label.textColor = [UIColor darkTextColor];
    [container addSubview:label];
    
    Button *button = [Button buttonWithType:UIButtonTypeCustom];
    
    
    button.style = _reverse ? @"actionSheetReverseCloseButton" : @"actionSheetCloseButton";
    [button addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    button.frame = slice;

    
    [container addSubview:button];
    
    return container;
}


- (void)show {
    UIViewController *rvc = UIApplication.sharedApplication.keyWindow.rootViewController;
    UIView *view = [rvc valueForKey:@"componentLayerView"];
    [self _showInView:view];
}

- (void)setContentView:(ActionSheetContentView *)contentView {
    contentView.actionSheet = self;
    _contentView = contentView;
}
- (void)showInView:(UIView*)view {
    
    self.isShowInView = YES;
    UIView *componentLayerView = [[ComponentLayerView alloc]initWithFrame:view.bounds];
    [view addSubview:componentLayerView];
    [self _showInView:componentLayerView];
}

- (void)_showInView:(UIView*)view {
    
    UIViewController *rvc = UIApplication.sharedApplication.keyWindow.rootViewController;
    
    
    if (_reverse) {
        
        UIEdgeInsets edgeInsets = [rvc safeAreaInsets];
        CGFloat safeArea = edgeInsets.top;
        
        CGRect frame = view.bounds;
        CGFloat height = _titleHeight + _contentHeight;
        height += safeArea;
        
        CGRect slice;
        CGRect remainder;
        
        CGRectDivide(frame, &slice, &remainder, height, CGRectMinYEdge);
        
        self.frame = slice;
        
        remainder = UIEdgeInsetsInsetRect(slice, UIEdgeInsetsMake(safeArea, 0, 0, 0));
        
        
        CGRectDivide(remainder, &slice, &remainder, _titleHeight, CGRectMinYEdge);
        
        self.titleView = [self titleView:slice];
        
        [self addSubview:_titleView];
        
        
        CGRectDivide(remainder, &slice, &remainder, _contentHeight, CGRectMinYEdge);
        
        _contentView.frame = slice;
        [self addSubview:_contentView];
        
        
        [view addSubview:self];
        
        [self roundingCorners:UIRectCornerBottomLeft|UIRectCornerBottomRight
                       radius:CGSizeMake(25.0f, 25.f)];
        
    }else {

        UIEdgeInsets edgeInsets = [rvc safeAreaInsets];
        CGFloat safeArea = edgeInsets.bottom;
        
        CGRect frame = view.bounds;
        CGFloat height = self.titleHeight + self.contentHeight;
        height += safeArea;
        
        
        CGRect slice;
        CGRect remainder;
        
        CGRectDivide(frame, &slice, &remainder, height, CGRectMaxYEdge);
        
        self.frame = slice;
        
        CGRectDivide(self.bounds, &slice, &remainder, self.titleHeight, CGRectMinYEdge);
        self.titleView = [self titleView:slice];
        
        [self addSubview:_titleView];
        
        
        CGRectDivide(remainder, &slice, &remainder, self.contentHeight, CGRectMinYEdge);
        
        _contentView.frame = slice;
        [self addSubview:_contentView];
        
        
        [view addSubview:self];
        
        [self roundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight
                       radius:CGSizeMake(25.0f, 25.f)];
        
    }
    
    
    [self showAnimation];
}

- (void)changeContentHeight:(CGFloat) contentHeight {
    
    _contentHeight = contentHeight;
    
    UIViewController *rvc = UIApplication.sharedApplication.keyWindow.rootViewController;
    UIView *view = [rvc valueForKey:@"componentLayerView"];
    
    if (_reverse) {
           
       UIEdgeInsets edgeInsets = [rvc safeAreaInsets];
       CGFloat safeArea = edgeInsets.top;
       
       CGRect frame = view.bounds;
       CGFloat height = _titleHeight + _contentHeight;
       height += safeArea;
       
       CGRect slice;
       CGRect remainder;
       
       CGRectDivide(frame, &slice, &remainder, height, CGRectMinYEdge);
       
       self.frame = slice;
       
       remainder = UIEdgeInsetsInsetRect(slice, UIEdgeInsetsMake(safeArea, 0, 0, 0));
       
       
       CGRectDivide(remainder, &slice, &remainder, _titleHeight, CGRectMinYEdge);
       
        _titleView.frame = slice;
       
       CGRectDivide(remainder, &slice, &remainder, _contentHeight, CGRectMinYEdge);
       
       _contentView.frame = slice;
        
        [self roundingCorners:UIRectCornerBottomLeft|UIRectCornerBottomRight
                       radius:CGSizeMake(25.0f, 25.f)];
        
    }else {

        UIEdgeInsets edgeInsets = [rvc safeAreaInsets];
        CGFloat safeArea = edgeInsets.bottom;
           
       CGRect frame = view.bounds;
       CGFloat height = self.titleHeight + self.contentHeight;
       height += safeArea;
       
       
       CGRect slice;
       CGRect remainder;
       
       CGRectDivide(frame, &slice, &remainder, height, CGRectMaxYEdge);
       
       self.frame = slice;
       
       CGRectDivide(self.bounds, &slice, &remainder, self.titleHeight, CGRectMinYEdge);
        _titleView.frame  = slice;
           
        CGRectDivide(remainder, &slice, &remainder, self.contentHeight, CGRectMinYEdge);
           
        _contentView.frame = slice;
        
        [self roundingCorners:UIRectCornerTopLeft|UIRectCornerTopRight
                              radius:CGSizeMake(25.0f, 25.f)];
    }
}


- (void)dismiss {
    
//    if ([_contentView.delegate respondsToSelector:@selector(actionSheetContentView: message:)]){
//        [_contentView.delegate actionSheetContentView:_contentView message:[Message messageWithName:@"dismiss" object:_contentView.]];
//    }

//    delegate?.actionSheet?(self, clickedButtonAt: selectedIndex)
    [_contentView dismiss];
    BOOL ani = [self dismissAnimation];
    if (ani) {
    }else{
        [self removeFromSuperview];
        if(self.isShowInView){
            [self.superview removeFromSuperview];
        }
    }
    
    
}

- (BOOL)showAnimation {
    
    DECLARE_WEAK_SELF(weakself);
    
    CGFloat ty = self.bounds.size.height;
    if (_reverse) {
        ty *= -1;
        UIViewController *rvc = UIApplication.sharedApplication.keyWindow.rootViewController;
        [((RootController*)rvc) setStatusBarHidden:YES animated:YES];
    }
    CATransform3D transform = CATransform3DTranslate(CATransform3DIdentity,
                                                     0,
                                                     ty,
                                                     0);
    self.layer.transform = transform;
    
    
    [UIView animateWithDuration:0.3f
                          delay:0
         usingSpringWithDamping:1
          initialSpringVelocity:0.5f
                        options:UIViewAnimationOptionCurveEaseInOut animations:^{
        weakself.layer.transform = CATransform3DIdentity;
    } completion:^(BOOL finished) {
        
    }];
    
    return YES;
}

- (BOOL)dismissAnimation {
    
    DECLARE_WEAK_SELF(weakself);
    
    CATransform3D transform = CATransform3DIdentity;
    self.layer.transform = transform;
    
    CGFloat ty = self.bounds.size.height;
    if (_reverse) {
        ty *= -1;
        
        UIViewController *rvc = UIApplication.sharedApplication.keyWindow.rootViewController;
        [((RootController*)rvc) setStatusBarHidden:NO animated:YES];
    }
    
    [UIView animateWithDuration:0.3f
                          delay:0.3f
         usingSpringWithDamping:1
          initialSpringVelocity:0.5f
                        options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        weakself.layer.transform = CATransform3DTranslate(CATransform3DIdentity,
                                                          0,
                                                          ty,
                                                          0);
        
    } completion:^(BOOL finished) {
        [weakself removeFromSuperview];
        
        if(weakself.isShowInView){
            [weakself.superview removeFromSuperview];
        }
    }];
    return YES;
}

//open override func showAnimation() -> Bool {
//    self.backgroundView.alpha = 0.5
//    UIView.animate(withDuration: 0.3) {
//        self.backgroundView.alpha = 1
//    }
//
//    let transform = CATransform3DTranslate(CATransform3DIdentity,
//                                           0,
//                                           self.contentView.bounds.size.height,
//                                           0)
//
//    self.contentView.layer.transform = transform
//    UIView.animate(withDuration: 0.3,
//                   delay: 0.1,
//                   usingSpringWithDamping: 1,
//                   initialSpringVelocity: 0,
//                   options: .curveEaseOut,
//                   animations: {
//                    self.contentView.layer.transform = CATransform3DIdentity
//    },completion: nil)
//    return true
//}
//
//
//@discardableResult
//open override func dismissAnimation() -> Bool{
//
//    UIView.animate(withDuration: 0.3) {
//        self.backgroundView.alpha = 0.0
//    }
//
//    let transform = CATransform3DIdentity
//    self.layer.transform = transform
//    UIView.animate(withDuration: 0.3,
//                   delay: 0.1,
//                   usingSpringWithDamping: 1,
//                   initialSpringVelocity: 0,
//                   options: .curveEaseOut,
//                   animations: {
//                    self.contentView.layer.transform = CATransform3DTranslate(CATransform3DIdentity,
//                                                                              0,
//                                                                              self.contentView.frame.size.height,
//                                                                              0)
//    },completion: { finished in
//        self.removeFromSuperview()
//    })
//    return true
//}



@end

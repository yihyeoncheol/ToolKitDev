//
//  Button.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "Button.h"

@implementation Button {
//    NSString *_style;
}

- (void)dealloc {
    NSArray *keys = @[
        @"style",
        @"fontStyle",
        @"cornerRadius",
        @"borderWidth",
        @"borderColor"
    ];

    for (NSString *key in keys) {
        [self removeObserver:self forKeyPath:key];
    }
    _action = nil;
    _layoutChanged = nil;
    _name = nil;
    _style = nil;
    _fontStyle = nil;

    _titleColor = nil;
    _title = nil;
    _titleFont = nil;
    
    _borderColor = nil;
    
    _enabledChanged = nil;
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self){
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self){
        [self initial];
    }
    return self;
}

- (void)initial {
    
#if (TARGET_IPHONE_SIMULATOR)
//    [self roundWithRadius:0.f width:.5f color:[UIColor blackColor]];
#endif
    
    _cornerRadius = 0;
    _borderWidth = 0;
    
    NSArray *keys = @[
        @"style",
        @"fontStyle",
        @"cornerRadius",
        @"borderWidth",
        @"borderColor"
    ];
    
    for (NSString *key in keys) {
        [self addObserver:self forKeyPath:key options:NSKeyValueObservingOptionNew context:nil];
    }

    [self addTarget:self action:@selector(eventTouchUpInside) forControlEvents:UIControlEventTouchUpInside];
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    
    if ([keyPath isEqualToString:@"style"]) {
        SEL selector = NSSelectorFromString(_style);
        if([self respondsToSelector:selector]){
            IMP imp = [self methodForSelector:selector];
            void (*func)(id, SEL) = (void *)imp;
            func(self, selector);
        }
    }else if ([keyPath isEqualToString:@"fontStyle"]) {
        SEL selector = NSSelectorFromString(_fontStyle.lowercaseString);
        if([self respondsToSelector:selector]){
            IMP imp = [self methodForSelector:selector];
            void (*func)(id, SEL) = (void *)imp;
            func(self, selector);
        }
    }else if ([keyPath isEqualToString:@"cornerRadius"]||
              [keyPath isEqualToString:@"borderWidth"]||
              [keyPath isEqualToString:@"borderColor"]) {
        [self roundWithRadius];
    }else{
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (_layoutChanged) {
        _layoutChanged(self);
    }
}


- (void)setEnabled:(BOOL)enabled {
    [super setEnabled:enabled];
    if (_enabledChanged) {
        _enabledChanged(enabled);
    }
}

#if 0
- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];

    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, self.backgroundColor.CGColor);
    CGContextFillRect(context, rect);
    if (_edgeLines){
        [self drawEdgeLines:_edgeLines rect:rect context:context];
    }
}
#endif
- (void)roundWithRadius {
//    [self roundWithRadius:_cornerRadius width:_borderWidth color:_borderColor];
    
    [self.layer setCornerRadius:_cornerRadius];
    [self.layer setBorderWidth:_borderWidth];
    [self.layer setMasksToBounds:YES];
    if (_borderColor) {
        [self.layer setBorderColor: _borderColor.CGColor];
    }
}

- (void)setTitleFont:(UIFont *)titleFont {
    _titleFont = titleFont;
    [self.titleLabel setFont:titleFont];
}

- (void)setImage:(nullable UIImage *)image {
    [self setImage:image forState:UIControlStateNormal];
    [self setImage:image forState:UIControlStateHighlighted];
    [self setImage:image forState:UIControlStateSelected];
}

- (void)setTitleColor:(UIColor *)titleColor {
    [self setTitleColor:titleColor forState:UIControlStateNormal];
    [self setTitleColor:titleColor forState:UIControlStateHighlighted];
    [self setTitleColor:titleColor forState:UIControlStateSelected];
    _titleColor = titleColor;
}

- (void)setTitle:(NSString *)title {
    [self setTitle:title forState:UIControlStateNormal];
    [self setTitle:title forState:UIControlStateHighlighted];
    [self setTitle:title forState:UIControlStateSelected];
    _title = title;
}

- (void)eventTouchUpInside {
    if (_action) {
        _action();
    }
}
@end

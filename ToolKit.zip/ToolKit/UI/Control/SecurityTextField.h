//
//  SecurityTextField.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "View.h"
NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString *const SecurityTextFieldDidChangeNotification;
UIKIT_EXTERN NSString *const SecurityKeyboardWillShowNotification;
UIKIT_EXTERN NSString *const SecurityKeyboardWillHideNotification;

typedef NS_ENUM(NSInteger, KeyPadType) {
    KeyPadTypeText    = 0,    // default
    KeyPadTypeNumber  = 1,    //
};


@protocol SecurityTextFieldDelegate;
@interface SecurityTextField : Component

@property(nonatomic,strong)IBInspectable NSString *placeholder;
@property(nonatomic,strong)IBInspectable UIColor *placeholderColor;
@property(nonatomic,strong)IBInspectable UIColor *textColor;
@property(nonatomic)IBInspectable BOOL blankTouch;
@property(nonatomic)IBInspectable NSInteger minLength;
@property(nonatomic)IBInspectable NSInteger maxLength;
@property(nonatomic)IBInspectable BOOL secureTextEntry;

@property(nonatomic,strong)IBInspectable UIImage *clearImage;
@property(nullable,nonatomic,weak)id<SecurityTextFieldDelegate> delegate;
@property(nullable,nonatomic,strong)ViewController *vc;
@property(nonatomic)BOOL edit;
@property(nonatomic,strong)IBInspectable UIFont *font;
@property(nonatomic)CGFloat keypadHeight;
@property(nonatomic)KeyPadType type;

@property(nonatomic,strong )NSString *plainText;
@property(nonatomic,strong )NSString *dummyText;
@property(nonatomic,strong )NSString *encText;

@property(nonatomic)NSTextAlignment textAlignment;
- (void)showKeypad;
- (void)dismissKeypad;
- (void)clear;
@end

@protocol SecurityTextFieldDelegate <NSObject>
@optional
- (void)securityTextFieldDidChange:(SecurityTextField*)textField;
- (void)securityTextFieldShouldBeginEditing:(SecurityTextField*)textField;
- (void)securityTextFieldDidBeginEditing:(SecurityTextField*)textField;
- (void)securityTextFieldShouldEndEditing:(SecurityTextField*)textField;
- (void)securityTextFieldDidEndEditing:(SecurityTextField*)textField;
- (void)securityTextFieldShouldClear:(SecurityTextField*)textField;
- (void)securityTextFieldShouldReturn:(SecurityTextField*)textField;

@end



NS_ASSUME_NONNULL_END

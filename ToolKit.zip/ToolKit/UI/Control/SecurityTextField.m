//
//  SecurityTextField.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "SecurityTextField.h"

NSString *const SecurityTextFieldDidChangeNotification = @"SecurityTextFieldDidChangeNotification";
NSString *const SecurityKeyboardWillShowNotification = @"SecurityKeyboardWillShowNotification";
NSString *const SecurityKeyboardWillHideNotification = @"SecurityKeyboardWillHideNotification";

@implementation SecurityTextField
    
- (void)dealloc {
    NSArray *keys = @[@"type"];
    for (NSString *key in keys) {
        [self removeObserver:self forKeyPath:key];
    }
    
    self.vc = nil;
    self.delegate = nil;
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)initial {
    _secureTextEntry = YES;
    
//    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(keyboardWillShow:)
//                                               name:UIKeyboardWillShowNotification
//                                             object:nil];
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(textDidBeginEditing:)
                                               name:UITextFieldTextDidBeginEditingNotification
                                             object:nil];
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(touchEventNotification:)
                                               name:RootControllerTouchEventNotification
                                             object:nil];
    
//    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(transkeyWillShow:)
//                                               name:UIKeyboardWillShowNotification
//                                             object:nil];
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(transkeyChange:)
                                               name:SecurityTextFieldDidChangeNotification
                                             object:nil];
    
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(securityKeyboardWill:)
                                               name:SecurityKeyboardWillShowNotification
                                             object:nil];
    
    
    NSArray *keys = @[@"type"];
    for (NSString *key in keys) {
        [self addObserver:self forKeyPath:key options:NSKeyValueObservingOptionNew context:nil];
    }
}
 
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    
    if ([keyPath isEqualToString:@"type"]) {
        [self update];
    }else{
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}


- (void)update {
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
}
- (NSString*)dummy {
    return nil;
}
    
- (void)clearButton {
}

- (void)clearText {
}

- (void)clear {
}

- (void)showKeypad {
    [[NSNotificationCenter defaultCenter] postNotificationName:SecurityKeyboardWillShowNotification
                                                        object:self];
}

- (void)dismissKeypad {
    [[NSNotificationCenter defaultCenter] postNotificationName:SecurityKeyboardWillHideNotification
                                                        object:self];
//
}

- (void)adjustPosition {
    
    UIView *view = [self.vc.view findFirstResponder];
    if (view != nil) {
        [view resignFirstResponder];
    }
    [self.vc.view layoutIfNeeded];
    
    CGRect selfRect = [self convertRect:self.bounds toView:UIApplication.sharedApplication.keyWindow];
    
    CGFloat keyboardHeight = _keypadHeight + 10;
    
    keyboardHeight += _vc.safeAreaInsets.bottom;
            
            
    CGFloat y = selfRect.origin.y + selfRect.size.height;

    CGFloat height = UIScreen.mainScreen.bounds.size.height;

    CGFloat KeyboardY = height - keyboardHeight;

    CGFloat my = KeyboardY - y;
            

    if (my < 0)  {
        _vc.offset = my;
        
        [UIView animateWithDuration:0.3f
                              delay:.0f
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
            self.vc.view.frame = CGRectOffset(self.vc.view.frame, 0, my);
        } completion:^(BOOL finished) {
            
        }];
    }
}
    
    
- (void)revertPosition {
  
    if (_vc == nil) {
        return;
    }
    
    if (_edit) {
        if(_vc.offset < 0) {
            [self.vc.view setNeedsLayout];
            [UIView animateWithDuration:0.3f
                                  delay:.0f
                                options:UIViewAnimationOptionCurveEaseInOut
                             animations:^{
                self.vc.view.frame = CGRectOffset(self.vc.view.frame, 0, self.vc.offset * -1);

                if (@available(iOS 11.0, *)) {
                    [self.vc.view layoutIfNeeded];
                }
            } completion:^(BOOL finished) {
                self.vc.offset = 0;
                [self.vc.view layoutIfNeeded];
            }];
            _edit = NO;
        }
    }
}
    
#pragma mark - notification
- (void)transkeyChange:(NSNotification*)notification {
}

- (void)transkeyWillShow:(NSNotification*)notification {

    if (![notification.object isEqual:self]) {
        if (_edit) {
            [self dismissKeypad];
        }
    }
}

- (void)touchEventNotification:(NSNotification*)notification {
    
    if (_edit == NO) {
        return;
    }
            
    if (_blankTouch == NO) {
        return;
    }
            
    UITouch *touch = (UITouch*)notification.object;
    
    UIView *keyWindow = UIApplication.sharedApplication.keyWindow.rootViewController.view;
    CGPoint point = [touch locationInView:keyWindow];
    
            
            
    CGRect convertFarme =  [self convertRect:self.bounds toView:keyWindow];
    BOOL contains = CGRectContainsPoint(convertFarme, point);
            
    if (contains) {
        return;
    }
    
    UIEdgeInsets edgeInsets = UIApplication.sharedApplication.keyWindow.rootViewController.safeAreaInsets;
                  
    CGFloat safeAreaBottom  = edgeInsets.bottom;
    CGRect slice;
    CGRect remainder;
    CGRectDivide(keyWindow.frame, &slice, &remainder, _keypadHeight + safeAreaBottom + 30, CGRectMaxYEdge);
    
    BOOL ret =  CGRectContainsPoint(slice, point);
    
    if (!ret){
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(300 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self dismissKeypad];
        });
        
    }

}
    // MARK: - notification
    
   
- (void)securityKeyboardWill:(NSNotification*)notification {
    if (![notification.object isEqual:self]){
        if (_edit) {
            [self dismissKeypad];
            
        }
    }
}

- (void)keyboardWillShow:(NSNotification*)notification {
    if (_edit) {
        [self dismissKeypad];
    }
}
    

- (void)textDidBeginEditing:(NSNotification*)notification {
    if (_edit) {
        [self dismissKeypad];
    }
}

@end

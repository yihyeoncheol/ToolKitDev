//
//  Radio.h
//  LPoint
//
//  Created by MP02031 on 2020/11/10.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Component.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, RadioContentAlignment) {
    RadioContentAlignmentVertical  = 0,
    RadioContentAlignmentHorizontal = 1, // 수평
};

@interface Radio : Component
@property(nonatomic) UIEdgeInsets contentEdgeInsets;
@property(nonatomic,strong)NSArray<NSString*> *items;
@property(nonatomic) NSInteger selectedIndex;
@property(nonatomic)IBInspectable CGFloat spacing;
@property(nonatomic,strong,readonly)NSMutableArray<Button*> *components;
@end


NS_ASSUME_NONNULL_END

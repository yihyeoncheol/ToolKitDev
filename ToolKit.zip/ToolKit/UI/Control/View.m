//
//  View.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "View.h"


@interface View (){
    NSString *_style;
}
@end

@implementation View

@synthesize style = _style;

- (void)dealloc {
    _name = nil;
    _layoutChanged = nil;
    _edgeLines = nil;
    _style = nil;
    _event = nil;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self didLoad];
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self){
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self){
        [self initial];
    }
    return self;
}

- (void)initial {
#if (TARGET_IPHONE_SIMULATOR)
//    [self roundWithRadius:0.f width:.5f color:[UIColor blackColor]];
#endif
//    self.backgroundColor = [UIColor whiteColor];
}

- (void)viewWillRotate:(id<UIViewControllerTransitionCoordinatorContext>) context
{
#if 0
    NSTimeInterval animationDuration = [context transitionDuration];
    UIViewAnimationCurve animationCurve = [context completionCurve];
    //
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    [UIView setAnimationBeginsFromCurrentState:YES];
     // run
    [UIView commitAnimations];
    
#endif
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (_layoutChanged) {
        _layoutChanged(self);
    }
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];

    CGContextRef context = UIGraphicsGetCurrentContext();
//    CGContextSetFillColorWithColor(context, self.backgroundColor.CGColor);
//    CGContextFillRect(context, rect);
    if (_edgeLines){
        [self drawEdgeLines:_edgeLines rect:rect context:context];
    }
}


- (void)didLoad { }
- (void)setData:(id)data {}
//@discardableResult
//open func showAnimation() -> Bool {
//    return false
//}
//@discardableResult
//open func dismissAnimation() -> Bool {
//    return false
//}



@end

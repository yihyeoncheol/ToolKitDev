//
//  ComboBox.h
//  LPoint
//
//  Created by MP02031 on 2020/11/11.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Component.h"
#import "ActionSheetContentView.h"
NS_ASSUME_NONNULL_BEGIN
@protocol ComboBoxViewDelegate;

@interface ComboBox : Component

@property(nonatomic,strong)Label *textLabel;
@property(nonatomic,strong)ImageView *imageView;
@property(nonatomic,weak)id <ComboBoxViewDelegate> delegate;

@property(nonatomic)NSInteger selectedIndex;
@property(nonatomic)UIEdgeInsets contentEdgeInsets;
@property(nonatomic)UIEdgeInsets textEdgeInsets;
@property(nonatomic)UIEdgeInsets imageEdgeInsets;
@property(nonatomic,strong) NSArray<NSString*> *items;
@property(nonatomic) NSTextAlignment textAlignment;
- (NSString*)text;
- (void)setText:(NSString*)text;
- (void)setAttributedTitle:(NSString*)text;
@end

@interface ComboBoxContentView :ActionSheetContentView

@property(nonatomic)CGFloat height;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSArray *items;
- (void)registerNib:(nullable UINib *)nib;
- (void)registerClass:(nullable Class)cellClass;
@end

@interface ComboBoxCell :TableViewCell
@property(nonatomic) UIEdgeInsets  contentEdgeInsets;
@end


@protocol ComboBoxViewDelegate <NSObject>
- (void)comboContentView:(NSInteger) selectedIndex;
@end

NS_ASSUME_NONNULL_END

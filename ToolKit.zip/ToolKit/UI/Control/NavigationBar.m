//
//  NavigationBar.m
//  LPoint
//
//  Created by MP02031 on 2020/09/15.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "NavigationBar.h"
typedef NS_ENUM(NSInteger, NavigationBarState) {
    NavigationBarStateNone,
    NavigationBarStateScrollingDown,
    NavigationBarStateScrollingUp
};

@interface NavigationBar()

//@property(nonatomic,weak) IBOutlet NSLayoutConstraint *heightLayoutConstraint;

@property(nonatomic)NavigationBarState scrollState;
//@property(nonatomic,strong)UIPanGestureRecognizer *panGestureRecognizer;
@property(nonatomic)CGFloat lastContentOffsetY;
@end

@implementation NavigationBar

- (void)dealloc {
    
}

- (void)initial {
    _statusBarTopOffset = [UIApplication sharedApplication].rootController.safeAreaInsets.top;
    _titleEdgeInsets = UIEdgeInsetsMake(0, 56, 0, 56);;
    
    _titleLabel = [[Label alloc]initWithFrame:UIEdgeInsetsInsetRect(self.bounds, _titleEdgeInsets)];
    _titleLabel.textAlignment = NSTextAlignmentLeft;
    _titleLabel.font = [UIFont systemFontOfSize:18];
    _titleLabel.textColor = [UIColor rgbColorWithRed:34 green:34 blue:34 alpha:1];
    _titleLabel.numberOfLines = 2;
    _titleLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightMedium];
    _titleLabel.fontStyle = @"NotoSans";
    
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_titleLabel];
    


}

- (void)didLoad {

}

- (void)setTitle:(NSString *)title {
    _title = title;
    _titleLabel.text = title ;
}

- (void)setScrollView:(ScrollView *)scrollView {
    _scrollView = scrollView;
    [_scrollView.panGestureRecognizer addTarget:self action:@selector(handlePan:)];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _titleLabel.frame = UIEdgeInsetsInsetRect(self.bounds, _titleEdgeInsets);
}



- (void)didScroll:(UIScrollView*)scrollView {
//    if (scrollView.panGestureRecognizer.state == UIGestureRecognizerStateEnded){
//        CGFloat contentOffsetY = scrollView.contentOffset.y;
//        CGFloat height = self.bounds.size.height;
//
//        CGFloat y = MIN(contentOffsetY, height);
//
//        _viewTopContraint.constant = y *-1;
//
//        [self.superview updateConstraints];
////    }
}

#pragma mark - panGesture handler

- (void)handlePan:(UIPanGestureRecognizer*)panGestureRecognizer {

    CGFloat contentOffsetY = _scrollView.contentOffset.y;

//    CGFloat height = self.bounds.size.height;

    CGFloat yVelocity = [_scrollView.panGestureRecognizer velocityInView:_scrollView].y;
    
    if(panGestureRecognizer.state == UIGestureRecognizerStateBegan){
        self.lastContentOffsetY = contentOffsetY;
    }else if(panGestureRecognizer.state == UIGestureRecognizerStateChanged||
             panGestureRecognizer.state == UIGestureRecognizerStateEnded){
        if (yVelocity < 0) {
            if (_viewTopContraint.constant == -50){
            }else{
                CGFloat y =_lastContentOffsetY- contentOffsetY ;
                y = fabs(y);
                y = MAX(-y, -50);
                _viewTopContraint.constant = y;
            }
        }else if (yVelocity > 0) {
//            if (contentOffsetY < 150) {
//                CGFloat y = contentOffsetY - 150;
//                _viewTopContraint.constant = MAX(y, -height);
//            }else{
                CGFloat y = _lastContentOffsetY - contentOffsetY;
                y = fabs(y);
                _viewTopContraint.constant = MAX(-y, 0);
//            }
        }
    }
}

@end

//
//  Camera.m
//  LPoint
//
//  Created by MP02031 on 2020/10/14.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Camera.h"

#import <AVFoundation/AVFoundation.h>
#import <CoreImage/CoreImage.h>


//https://www.infragistics.com/community/blogs/b/torrey-betts/posts/scanning-barcodes-with-ios-7-objective-c

#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_10_0
#else
API_AVAILABLE(ios(10.0))
#endif
@interface Camera()<AVCaptureMetadataOutputObjectsDelegate,AVCaptureVideoDataOutputSampleBufferDelegate
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_10_0
>
#else
,AVCapturePhotoCaptureDelegate>
#endif

@property(nonatomic,strong)AVCaptureVideoDataOutput *videoDataOutput;
@property(nonatomic,strong)AVCaptureVideoPreviewLayer *previewLayer;
@property(nonatomic,strong)AVCaptureSession *session;
@property(nonatomic,strong)AVCaptureMetadataOutput *metadataOutput;

@property (nonatomic, strong) dispatch_queue_t videoDataOutputQueue;

#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_10_0
@property (nonatomic, strong) AVCaptureStillImageOutput *photoOutput;
#else
@property (nonatomic, strong) AVCapturePhotoOutput *photoOutput;
#endif

@end

@implementation Camera

- (void)dealloc {
    _videoDataOutput = nil;
    _previewLayer = nil;
    _session = nil;
    _metadataOutput = nil;
    _photoOutput = nil;
}

- (void)initial {
    
    self.backgroundColor = [UIColor blackColor];
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    
    switch (status) {
        case AVAuthorizationStatusNotDetermined: {
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
                dispatch_async( dispatch_get_main_queue(), ^{
                    [self captureSession];
                });
            }];
        }
            break;
        case AVAuthorizationStatusRestricted:
            break;
        case AVAuthorizationStatusDenied:
            break;
        case AVAuthorizationStatusAuthorized: {
            [self captureSession];
        }
            break;
    }
}

- (void)captureSession {

    _videoOrientation = AVCaptureVideoOrientationPortrait;
    
    _session = [[AVCaptureSession alloc] init];
    
    if ([_session canSetSessionPreset:AVCaptureSessionPreset1920x1080]){
        [_session setSessionPreset:AVCaptureSessionPreset1920x1080];
        _size = CGSizeMake (1920.0, 1080.0);
    } else if ([_session canSetSessionPreset:AVCaptureSessionPreset640x480]) {
        [_session setSessionPreset:AVCaptureSessionPreset640x480];
        _size = CGSizeMake (640.0, 480.0);
    } else if ([_session canSetSessionPreset:AVCaptureSessionPreset352x288]) {
        [_session setSessionPreset:AVCaptureSessionPreset352x288];
        _size = CGSizeMake (352.0, 288.0);
    } else {
        NSLog(@"failed  setSessionPreset");
        return;
    }
    
    
    
    
    NSArray<AVCaptureDevice *> *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    if (devices.count > 0) {
        AVCaptureDevice *captureDevice = devices.firstObject;
        
       
        UIInterfaceOrientation statusBarOrientation = [UIApplication sharedApplication].statusBarOrientation;
        AVCaptureVideoOrientation initialVideoOrientation = AVCaptureVideoOrientationLandscapeLeft;
        if ( statusBarOrientation != UIInterfaceOrientationUnknown ) {
            initialVideoOrientation = (AVCaptureVideoOrientation)statusBarOrientation;
        }
        _previewLayer.connection.videoOrientation = initialVideoOrientation;
        
        _previewLayer = [[AVCaptureVideoPreviewLayer alloc]initWithSession:_session];
        _previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
        
        
//        _previewLayer.frame = CenterInRect(self.bounds, CGRectMake(0, 0, resolution.width, resolution.height));
        
        CGSize screenSize = [[UIScreen mainScreen] bounds].size;
        
        if (screenSize.width / _size.height > screenSize.height / _size.width) {
            CGFloat height = _size.width * screenSize.width / _size.height;
            CGRect frameRect = CGRectMake (0, (screenSize.height - height) / 2, screenSize.width, height);
            [self.previewLayer setFrame:frameRect];
        } else {
            CGFloat width = _size.height * screenSize.height / _size.width;
            CGRect frameRect = CGRectMake ((screenSize.width - width) / 2, 0, width, screenSize.height);
            [self.previewLayer setFrame:frameRect];
        }
        
        
        [self.layer addSublayer:_previewLayer];
        
        
//        AVCaptureDevicePosition position = captureDevice.position;
        
//        AVCaptureFigVideoDevice
        NSError *error = nil;
        AVCaptureDeviceInput *deviceInput = [AVCaptureDeviceInput deviceInputWithDevice:captureDevice error:&error];
     
        if ([_session canAddInput:deviceInput]) {
            [_session addInput:deviceInput];
        }
        
        _metadataOutput = [[AVCaptureMetadataOutput alloc]init];
        if ([_session canAddOutput:_metadataOutput]) {
            [_session addOutput:_metadataOutput];
            [_metadataOutput setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
            [_metadataOutput setMetadataObjectTypes:@[AVMetadataObjectTypeQRCode, AVMetadataObjectTypeEAN13Code]];
//            [_metadataOutput setMetadataObjectTypes:@[AVMetadataObjectTypeQRCode,
//                                                      AVMetadataObjectTypeUPCECode,
//                                                      AVMetadataObjectTypeCode39Code,
//                                                      AVMetadataObjectTypeCode39Mod43Code,
//                                                      AVMetadataObjectTypeEAN13Code,
//                                                      AVMetadataObjectTypeEAN8Code,
//                                                      AVMetadataObjectTypeCode93Code,
//                                                      AVMetadataObjectTypeCode128Code,
//                                                      AVMetadataObjectTypePDF417Code,
//                                                      AVMetadataObjectTypeAztecCode]];
            
        }
        
        
        _videoDataOutput = [[AVCaptureVideoDataOutput alloc] init];
        
        // we want YUV, both CoreGraphics and OpenGL work well with 'YUV'
        NSDictionary *rgbOutputSettings = [NSDictionary dictionaryWithObject:
                                           [NSNumber numberWithInt:kCVPixelFormatType_420YpCbCr8BiPlanarFullRange] forKey:(id)kCVPixelBufferPixelFormatTypeKey];
        [_videoDataOutput setVideoSettings:rgbOutputSettings];
        [_videoDataOutput setAlwaysDiscardsLateVideoFrames:YES];
        [[_videoDataOutput connectionWithMediaType:AVMediaTypeVideo] setEnabled:YES];
//        self.videoDataOutputQueue = dispatch_queue_create("VideoDataOutputQueue", DISPATCH_QUEUE_SERIAL);

        
        
        _videoDataOutputQueue = dispatch_queue_create("com.lottecard.LotteMembers.capturesession.videodata", DISPATCH_QUEUE_SERIAL);
        dispatch_set_target_queue(_videoDataOutputQueue, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0));
        //오디오 큐 생성
//        self.audioDataOutputQueue = dispatch_queue_create("com.lottecard.LotteMembers.capturesession.audiodata", DISPATCH_QUEUE_SERIAL);

        [_videoDataOutput setSampleBufferDelegate:self queue:dispatch_get_main_queue()];
        
        if ([_session canAddOutput:_videoDataOutput]) {
            [_session addOutput:_videoDataOutput];
        }
        
        #if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_10_0
        _photoOutput = [[AVCaptureStillImageOutput alloc]init];
        NSDictionary *settings = [[NSDictionary alloc] initWithObjectsAndKeys:AVVideoCodecJPEG, AVVideoCodecKey, nil];
        [_photoOutput setOutputSettings:settings];
        #else
        if (@available(iOS 10.0, *)) {
            _photoOutput = [[AVCapturePhotoOutput alloc] init];
        } else {
            // Fallback on earlier versions
        }
        #endif
        

        if ([_session canAddOutput:_photoOutput]) {
            [_session addOutput:_photoOutput];
        }
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _previewLayer.frame = self.bounds;
}

- (void)on {
    if (_session) {
        if (!_session.isRunning) {
            [_session startRunning];
        }
    }
}

- (void)off {
    if (_session) {
        [_session stopRunning];
    }
}

- (void)shutter {
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_10_0
        
    AVCaptureStillImageOutput *captureStillImageOutput = (AVCaptureStillImageOutput*)_photoOutput;
    
    AVCaptureConnection *videoConnection = nil;
    for (AVCaptureConnection *connection in captureStillImageOutput.connections){
        for (AVCaptureInputPort *port in [connection inputPorts]){
            if ([[port mediaType] isEqual:AVMediaTypeVideo]){
                videoConnection = connection;
                break;
            }
        }
        if (videoConnection) {
            break;
        }
    }
    
    if(videoConnection){
        [captureStillImageOutput captureStillImageAsynchronouslyFromConnection:videoConnection completionHandler: ^(CMSampleBufferRef imageSampleBuffer, NSError *error){
            
            if (error) {
            }else{
                NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageSampleBuffer];
                if (imageData){
                    UIImage *resultingImage = [UIImage imageWithData:imageData];
                    resultingImage = [UIImage imageWithCGImage:[resultingImage CGImage] scale:[resultingImage scale] orientation:UIImageOrientationUp];

                    if ([self.delegate respondsToSelector:@selector(camera:didFinishProcessingPhoto:)]){
                        [self.delegate camera:self didFinishProcessingPhoto:resultingImage];
                    }
                }
            }
        }];
    }
#else
    if (@available(iOS 10.0, *)) {
        AVCapturePhotoSettings *settings = [AVCapturePhotoSettings photoSettings];
        //    settings.flashMode = flashMode
        AVCaptureConnection *connection = [_photoOutput connectionWithMediaType:AVMediaTypeVideo];
//        connection.videoOrientation = videoOrientation
        [_photoOutput capturePhotoWithSettings:settings delegate:self];
    } else {
        // Fallback on earlier versions
    }
#endif
}

#if 0
- (void)setFlashMode:(CameraFlashMode)flashMode
{
    _flashMode = flashMode;
    AVCaptureDevice
    // check if flashlight available
    Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
    if (captureDeviceClass != nil) {
        
        AVCaptureDevice *device = nil;

        NSArray* allDevices = [AVCaptureDevice devices];
        for (AVCaptureDevice* currentDevice in allDevices) {
            if (currentDevice.position == AVCaptureDevicePositionBack) {
                device = currentDevice;
            }
        }
        
        if ([device hasTorch] && [device hasFlash]){

            [device lockForConfiguration:nil];
            switch (_flashMode) {
                case CameraFlashModeOff:
                   [device setFlashMode:AVCaptureFlashModeOff];
                    break;
                case CameraFlashModeOn:
                    [device setFlashMode:AVCaptureFlashModeOn];
                    break;
                case CameraFlashModeAuto:
                    [device setFlashMode:AVCaptureFlashModeAuto];
                    break;
                default:
                    break;
            }
            [device unlockForConfiguration];
        }
    }
}
#endif

#pragma mark - AVCapturePhotoCaptureDelegate
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_10_0
#else

- (void)captureOutput:(AVCapturePhotoOutput *)output didFinishProcessingPhoto:(AVCapturePhoto *)photo error:(nullable NSError *)error API_AVAILABLE(ios(11.0)) {
    
    NSData *data = photo.fileDataRepresentation;
    UIImage *resultingImage =  [UIImage imageWithData:data];

    if ([self.delegate respondsToSelector:@selector(camera:didFinishProcessingPhoto:)]){
        [self.delegate camera:self didFinishProcessingPhoto:resultingImage];
    }
}

- (void)captureOutput:(AVCapturePhotoOutput *)output didFinishProcessingPhotoSampleBuffer:(nullable CMSampleBufferRef)photoSampleBuffer previewPhotoSampleBuffer:(nullable CMSampleBufferRef)previewPhotoSampleBuffer resolvedSettings:(AVCaptureResolvedPhotoSettings *)resolvedSettings bracketSettings:(nullable AVCaptureBracketedStillImageSettings *)bracketSettings error:(nullable NSError *)error  API_AVAILABLE(ios(10.0)){
 
   NSData *data = [AVCapturePhotoOutput JPEGPhotoDataRepresentationForJPEGSampleBuffer:photoSampleBuffer previewPhotoSampleBuffer:previewPhotoSampleBuffer];
   UIImage *resultingImage=  [UIImage imageWithData:data];
    
    if ([self.delegate respondsToSelector:@selector(camera:didFinishProcessingPhoto:)]){
        [self.delegate camera:self didFinishProcessingPhoto:resultingImage];
    }
}
#endif

#pragma mark - AVCaptureMetadataOutputObjectsDelegate
- (void)captureOutput:(AVCaptureOutput *)output didOutputMetadataObjects:(NSArray<__kindof AVMetadataObject *> *)metadataObjects
       fromConnection:(AVCaptureConnection *)connection {
    AVMetadataObject* metadataObject = metadataObjects.firstObject;
    if ([metadataObject isMemberOfClass:[AVMetadataMachineReadableCodeObject class]]){
        AVMetadataMachineReadableCodeObject *readableCodeObject = (AVMetadataMachineReadableCodeObject*)metadataObject;
        if([_delegate respondsToSelector:@selector(camera:metatype:data:)]){
            [_delegate camera:self metatype:readableCodeObject.type data:readableCodeObject.stringValue];
        }
    }
}

#pragma mark - AVCaptureVideoDataOutputSampleBufferDelegate
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer
       fromConnection:(AVCaptureConnection *)connection {
    if([_delegate respondsToSelector:@selector(camera:captureOutput:didOutputSampleBuffer:fromConnection:)]){
        [_delegate camera:self captureOutput:captureOutput didOutputSampleBuffer:sampleBuffer fromConnection:connection];
    }
}
@end

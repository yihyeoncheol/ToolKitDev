//
//  LayerView.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "LayerView.h"

@implementation LayerView

- (void)initial {
    
#if (TARGET_IPHONE_SIMULATOR)
//    [self roundWithRadius:0.f width:.5f color:[UIColor blackColor]];
#endif
    self.backgroundColor = [UIColor clearColor];
    self.hidden = YES;
}

- (void)didAddSubview:(UIView *)subview {
    [super didAddSubview:subview];
    if (self.subviews.count > 0){
        self.hidden = NO;
    }
}

- (void)willRemoveSubview:(UIView *)subview {
    if (self.subviews.count > 0) {
        self.hidden = YES;
    }
    [super willRemoveSubview:subview];
}

@end

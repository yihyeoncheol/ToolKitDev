//
//  SegmentedControl.m
//  LPoint
//
//  Created by MP02031 on 2020/11/03.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "SegmentedControl.h"


@interface SegmentedControl ()
@property(nonatomic,strong)UIStackView *stackView;

@end
@implementation SegmentedControl


- (void)dealloc {
    _stackView = nil;
    _components = nil;
    _items = nil;
}

- (void)initial {
    _contentEdgeInsets = UIEdgeInsetsMake(5, 5, 5, 5);
    _stackView = [[UIStackView alloc]init];
    _stackView.axis = UILayoutConstraintAxisHorizontal;
    _stackView.alignment = UIStackViewAlignmentFill;
    _stackView.distribution = UIStackViewDistributionFillEqually;
    [self addSubview:_stackView];
    
    _components = [[NSMutableArray alloc]init];
}
    
- (void)layoutSubviews {
    [super layoutSubviews];
    _stackView.frame = UIEdgeInsetsInsetRect(self.bounds, _contentEdgeInsets);
}
    

-(void)setItems:(NSArray<NSString *> *)items {
    _items = items;
    [self paint];
    [self setNeedsStyle];
}

- (void)update {
    
}

- (void)paint {
 
    for (UIView *component in _components) {
        [_stackView removeArrangedSubview:component];
    }
    
    [_components removeAllObjects];
    
    
    NSInteger index = 0;
    
    for (NSString *item in _items) {
        
        Button *button = [Button buttonWithType:UIButtonTypeCustom];
        button.title = item;
        [button addTarget:self action:@selector(componentAction:) forControlEvents:UIControlEventTouchUpInside];
        [_stackView addArrangedSubview:button];
        [_components addObject:button];
//        button.style = @"segmentedControlItemButton";
        button.tag = index;
        index++;
    }
    
    
    [self setIndex:_selectedIndex];
    
}
    

- (void)componentAction:(Button*)button {
    [self setIndex:button.tag];
}

-(void)setIndex:(NSInteger)index  {
    for (Button *button in _components) {
        button.selected = NO;
    }
    
    Button *button = _components[index];
    button.selected = YES;
    
    if (_selectedIndex != index){
        _selectedIndex = index;
        [self sendActionsForControlEvents:UIControlEventValueChanged];
        if ([self.delegate respondsToSelector:@selector(segmentedContentView:)]){
           [self.delegate segmentedContentView:_selectedIndex];
        }
    }
}

@end

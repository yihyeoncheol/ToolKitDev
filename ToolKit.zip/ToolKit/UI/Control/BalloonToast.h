//
//  BalloonToast.h
//  LPoint
//
//  Created by MP02031 on 2020/12/14.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Component.h"

NS_ASSUME_NONNULL_BEGIN

@interface BalloonToast : Component
@property(nonatomic)UIView *taget;
@property(nonatomic)NSString *text;
@property(nonatomic)UIEdgeInsets contentEdgeInsets;
@property(nonatomic)UIEdgeInsets textEdgeInsets;
@property(nonatomic)UIColor *textColor;
//@property(nonatomic)UIColor *backgroundColor;
@property(nonatomic)CGFloat height;


+ (BalloonToast*)toastWithText:(NSString*)text;
- (void)showInView:(UIView*)inView ;

@end

NS_ASSUME_NONNULL_END

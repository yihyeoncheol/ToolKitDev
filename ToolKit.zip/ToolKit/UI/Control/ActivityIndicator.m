//
//  ActivityIndicator.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "ActivityIndicator.h"


#import <Lottie/Lottie.h>




static ActivityIndicator *indicatorView;
static int indicatorCount = 0;
NSString *const ActivityIndicatorToucheNotification = @"ActivityIndicatorToucheNotification";
@interface ActivityIndicator()

@property(nonatomic,strong)LOTAnimationView *indicator;
@end


@implementation ActivityIndicator


+ (void)start {
    
    indicatorCount ++;
    
    if (indicatorCount == 1){
        if (indicatorView) {
            [indicatorView.layer removeAllAnimations];
            [indicatorView.indicator stop];
            [indicatorView removeFromSuperview];
            indicatorView = nil;
        }
        
        UIApplication.sharedApplication.networkActivityIndicatorVisible = YES;
        UIView *topLayerView = [[UIApplication sharedApplication].keyWindow.rootViewController valueForKey:@"topLayerView"];
        
        indicatorView = [[ActivityIndicator alloc] initWithFrame:topLayerView.bounds];
        indicatorView.alpha = 0.0f;
        [topLayerView addSubview:indicatorView];
        [indicatorView.indicator play];
        [UIView animateWithDuration:0.3f
                              delay:0.0f
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^(void) {
                                indicatorView.alpha = 1.0f;
                            }
                         completion:^(BOOL completed) {
            
                         }];
    }
    
}


+ (void)stop {
    
    if (indicatorCount == 1) {
//        indicatorCount = 0;
//        [indicatorView.layer removeAllAnimations];
        UIApplication.sharedApplication.networkActivityIndicatorVisible = NO;
        [UIView animateWithDuration:0.3f
                              delay:0.3f
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^(void) {
                                    indicatorView.alpha = 0.0;
                        }completion:^(BOOL completed) {
                                [indicatorView.indicator stop];
                                [indicatorView removeFromSuperview];
                                indicatorView = nil;
                            indicatorCount --;
                            indicatorCount = MAX(indicatorCount, 0);
                            if (indicatorCount > 0){
                                 indicatorCount --;
                                [ActivityIndicator start];
                            }
                        }];
    }else{
        indicatorCount --;
        
        indicatorCount = MAX(indicatorCount, 0);
        
    }
}

+ (void)dismiss{
//    _indicator = nil;
    indicatorCount = 1;
    [self stop];
}


- (void)dealloc{
    [_indicator stop];
}

- (void)initial{
//    self.autoresizingMask = UIViewAutoresizingFlexibleTopMargin |
//    UIViewAutoresizingFlexibleBottomMargin|
//    UIViewAutoresizingFlexibleLeftMargin|
//    UIViewAutoresizingFlexibleRightMargin|
//    UIViewAutoresizingFlexibleWidth|
//    UIViewAutoresizingFlexibleHeight ;
//
    self.backgroundColor = [UIColor rgbColorWithRed:255 green:255 blue:255 alpha:0.5f];
    
    _indicator = [[LOTAnimationView alloc] initWithFrame:CenterInRect( CGRectMake(0, 0, 80, 80), self.bounds)];
    [_indicator setAnimationNamed:@"loading.json"];
    _indicator.loopAnimation = YES;
//    [_indicator sizeToFit];
//    _indicator.backgroundColor = [UIColor rgbColorWithRed:255 green:255 blue:255 alpha:0.5f];
//    _indicator.frame =
    [self addSubview:_indicator];
   
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _indicator.frame = CenterInRect( _indicator.bounds, self.bounds);
}

- (BOOL)isAnimating{
    return [_indicator isAnimationPlaying];
}


- (void)startAnimating{
    UIApplication.sharedApplication.networkActivityIndicatorVisible = YES;
    self.alpha = 0.0f;
    [_indicator play];
    [UIView animateWithDuration:0.25f
                          delay:0.0f
                        options:UIViewAnimationOptionCurveEaseIn animations:^(void) {
                            self.alpha = 1.0f;
                        }
                     completion:^(BOOL completed) {
                         
                     }];
}

- (void)stopAnimating {
    DECLARE_WEAK_SELF(weakself);
    UIApplication.sharedApplication.networkActivityIndicatorVisible = NO;
    [UIView animateWithDuration:0.25f
                          delay:0.1f
                        options:UIViewAnimationOptionCurveEaseIn animations:^(void) {
                            self.alpha = 0.0f;
                        }
                     completion:^(BOOL completed) {
                        [weakself.indicator stop];
                     }];
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    CGPoint currentPos  = [[touches anyObject] locationInView:self];
//    CGRect rect         = _indicator.frame;
//    rect                = CGRectInset(rect, -15, -15);
//
//    if( CGRectContainsPoint(rect,currentPos) ){
//        [[NSNotificationCenter defaultCenter]postNotificationName:ActivityIndicatorToucheNotification object:self userInfo:nil];
//    }
}


#if 0
- (void)drawRect:(CGRect)rect
{
    CGContextRef context        = UIGraphicsGetCurrentContext();
    size_t gradLocationsNum     = 2;
    CGFloat gradLocations[2]    = {0.0f, 1.0f};
    CGFloat gradColors[8]       = {0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.0f,0.45f};
    CGColorSpaceRef colorSpace  = CGColorSpaceCreateDeviceRGB();
    CGGradientRef gradient      = CGGradientCreateWithColorComponents(colorSpace, gradColors, gradLocations, gradLocationsNum);
    CGColorSpaceRelease(colorSpace);
    
    CGPoint gradCenter          = CGPointMake(self.bounds.size.width/2, self.bounds.size.height/2);
    float gradRadius            = MIN(self.bounds.size.width , self.bounds.size.height) ;
    
    CGContextDrawRadialGradient (context, gradient, gradCenter,0, gradCenter, gradRadius,kCGGradientDrawsAfterEndLocation);
    CGGradientRelease(gradient);
}
#endif


@end


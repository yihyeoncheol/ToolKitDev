//
//  ActionSheet.h
//  LPoint
//
//  Created by MP02031 on 2020/09/17.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Component.h"

NS_ASSUME_NONNULL_BEGIN
@class ActionSheetContentView;
@interface ActionSheet : Component

@property(nonatomic,strong) NSString *title;
@property(nonnull,nonatomic,strong)ActionSheetContentView *contentView;
@property(nonatomic)UIEdgeInsets *contentEdgeInsets;
@property(nonatomic)UIEdgeInsets *titleEdgeInsets;

@property(nonatomic)CGFloat titleHeight;
@property(nonatomic)CGFloat contentHeight;
@property(nonatomic)BOOL reverse;


- (void)changeContentHeight:(CGFloat) contentHeight;

- (void)show;
- (void)dismiss;
- (void)showInView:(UIView*)view;
//var titleView: UIView!
@end

NS_ASSUME_NONNULL_END

//
//  SwitchButton.h
//  LPoint
//
//  Created by MP02006 on 2020/10/14.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SwitchButton : UIButton

@end

NS_ASSUME_NONNULL_END

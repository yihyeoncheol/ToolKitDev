//
//  TextField.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "TextField.h"
#import "SecurityTextField.h"
#import "UIColor+Extension.h"

@implementation TextField
- (void)dealloc{
    
    NSArray *keys = @[@"style",
                      @"fontStyle"];

    _style = nil;
    _fontStyle = nil;
    
    for (NSString *key in keys) {
        [self removeObserver:self forKeyPath:key];
    }
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    _underLineColor = nil;
    _underLineSelectedColor = nil;
    _placeholderColor = nil;
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self){
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self){
        [self initial];
    }
    return self;
}
- (BOOL)resignFirstResponder {
    return [super resignFirstResponder];
}
- (void)initial {
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidShow:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didEndEditing:)
                                                 name:UITextFieldTextDidEndEditingNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didBeginEditing:)
                                                 name:UITextFieldTextDidBeginEditingNotification
                                               object:nil];
        
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didChange:)
                                                 name:UITextFieldTextDidChangeNotification
                                               object:nil];
        
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(touchEventNotification:)
                                                name:RootControllerTouchEventNotification
                                              object:nil];
    
    [NSNotificationCenter.defaultCenter addObserver:self
                                           selector:@selector(securityKeyboardWill:)
                                               name:SecurityKeyboardWillShowNotification
                                             object:nil];
    
    
#if (TARGET_IPHONE_SIMULATOR)
//    [self roundWithRadius:0.f width:.5f color:[UIColor blackColor]];
#endif
    
    _contentEdgeInsets      = UIEdgeInsetsZero;
    _borderEdgeInsets       = UIEdgeInsetsZero;
    _textEdgeInsets         = UIEdgeInsetsZero;
    _placeholderEdgeInsets  = UIEdgeInsetsZero;
//    _editingEdgeInsets      = UIEdgeInsetsZero;
    _clearButtonEdgeInsets  = UIEdgeInsetsZero;
    _leftViewEdgeInsets     = UIEdgeInsetsZero;
    _rightViewEdgeInsets    = UIEdgeInsetsZero;
    
    [self setTintColor:[UIColor hex:0x009BFA]];
    
    _underLineColor = [UIColor clearColor];
    _underLineSelectedColor = [UIColor clearColor];
    _blankTouch = YES;
    self.placeholderColor = self.textColor;
    
    
    NSArray *keys = @[@"style",
                      @"fontStyle"];

    for (NSString *key in keys) {
        [self addObserver:self forKeyPath:key options:NSKeyValueObservingOptionNew context:nil];
    }
}
- (void)setClearImage:(UIImage *)clearImage {
    _clearImage = clearImage;
    [self clearButton];
}

- (void)clearButton {
    Button *clearButton = [Button buttonWithType:UIButtonTypeCustom];
    [clearButton setImage:_clearImage];
    self.rightView = clearButton;
    self.rightViewMode = UITextFieldViewModeWhileEditing;
//    self.leftViewEdgeInsets = UIEdgeInsetsMake(5, 5, 5, 5);
    [clearButton addTarget:self action:@selector(clearText) forControlEvents:UIControlEventTouchUpInside];
}

- (void)clearText {
    self.text = @"";
    [[NSNotificationCenter defaultCenter] postNotificationName:UITextFieldTextDidChangeNotification
                                                        object:self
                                                      userInfo:nil];
    
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    
    if ([keyPath isEqualToString:@"style"]) {
        SEL selector = NSSelectorFromString(_style);
        if([self respondsToSelector:selector]){
            IMP imp = [self methodForSelector:selector];
            void (*func)(id, SEL) = (void *)imp;
            func(self, selector);
        }
    }else if ([keyPath isEqualToString:@"fontStyle"]) {
        SEL selector = NSSelectorFromString(_fontStyle.lowercaseString);
        if([self respondsToSelector:selector]){
            IMP imp = [self methodForSelector:selector];
            void (*func)(id, SEL) = (void *)imp;
            func(self, selector);
        }
    }else{
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    [self drawBorder:rect context:context];
}

- (void)drawBorder:(CGRect)rect context:(CGContextRef)context {
  
    CGFloat y = rect.origin.y;
    CGFloat x = rect.origin.x;
    CGFloat height = rect.size.height;
    CGFloat width = rect.size.width;
      
    CGColorRef borderColor = self.isEditing ? _underLineSelectedColor.CGColor : _underLineColor.CGColor;
    
    CGContextSetStrokeColorWithColor(context, borderColor);
    CGContextSetLineWidth(context, 1.0f);
    
    CGContextMoveToPoint(context, x + _contentEdgeInsets.left, height + y);
    CGContextAddLineToPoint(context, (width + x) - _contentEdgeInsets.right, height + y);
    CGContextStrokePath(context);
}

- (void)setPlaceholderColor:(UIColor *)placeholderColor {
    if(placeholderColor) {
        if (self.placeholder) {
            self.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.placeholder
            attributes:@{NSForegroundColorAttributeName:placeholderColor,
                         NSFontAttributeName:self.font}];
        }
    }
    _placeholderColor = placeholderColor;
}

#pragma mark - Keyboard Notification
- (void)keyboardDidShow:(NSNotification *)notification {
}

- (void)keyboardWillShow:(NSNotification *)notification {
    
    NSLog(@"keyboardWillShow");
    
    
    if (self.isEditing){
         NSLog(@"if (self.isEditing){");
        if (_vc == nil){
            return;
        }
        
        NSDictionary *userInfo  = notification.userInfo;
        CGRect keyboardFrame = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];

        
        CGRect selfRect     = [self convertRect:self.bounds toView:[UIApplication sharedApplication].keyWindow];
        int keyboardHeight  = keyboardFrame.size.height + 20;
        NSTimeInterval duration = [userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
        NSInteger animationCurve = [userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];
        
        
        CGFloat y = selfRect.origin.y + selfRect.size.height ;//+ accessoryHeight;
        CGFloat height = [UIScreen mainScreen].bounds.size.height;
        CGFloat KeyboardY = ( height - keyboardHeight);
        CGFloat my =  KeyboardY - y ;
        
        if (my < 0)  {
            _vc.offset = my;
            NSLog(@"_vc.offset = %f",_vc.offset);
            
            [UIView animateWithDuration:duration
                                  delay:0
                                options:animationCurve
                             animations:^{
                self.vc.view.transform = CGAffineTransformMakeTranslation(0, my);
                
//                                self.vc.view.frame = CGRectOffset(self.vc.view.frame, 0, my);

                             }
                             completion:^(BOOL finished) {

                             }];
        }
    }
}

- (void)keyboardWillHide:(NSNotification *)notification {
    NSLog(@"keyboardWillHide");
    
   
    if (_vc == nil){
        return;
    }
    
    if (self.isEditing) {
        if (_vc.offset < 0) {
            
            NSLog(@"_vc.offset = %f",_vc.offset);
            
            NSDictionary *userInfo  = notification.userInfo;
            NSTimeInterval duration = [userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
            NSInteger animationCurve = [userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];
                
            [UIView animateWithDuration:duration
                                  delay:0
                                options:animationCurve
                             animations:^{
//                                self.vc.view.frame = CGRectOffset(self.vc.view.frame, 0, self.vc.offset * -1);
//                                    self.vc.view.frame = CGRectMake(0, 0, self.vc.view.bounds.size.width, self.vc.view.bounds.size.height);
                                    self.vc.view.transform = CGAffineTransformMakeTranslation(0, 0);
                            }completion:^(BOOL finished) {
                                self.vc.offset = 0;
                                
                             }];
        }
    }
}

#pragma mark - TextField Notification

- (void)didEndEditing:(NSNotification *)notification {
    if (!self.isEditing) {
        [self setNeedsDisplay];
    }
}

- (void)didBeginEditing:(NSNotification *)notification {
    if(self.isEditing){
        [self setNeedsDisplay];
    }
}

- (void)didChange:(NSNotification *)notification {
    if(self.isEditing){
//        dataDelegate?.textFieldDidChange?(self)
    }
}

#pragma mark - RootController TouchEventNotification
- (void)touchEventNotification:(NSNotification *)notification {
    if (self.isEditing) {
        if (_blankTouch == NO) {
            return;
        }
        
        UITouch *touch  = notification.object;
        UIView *touchView = touch.view ;
        
        UIView *keyWindow =  UIApplication.sharedApplication.keyWindow;
        CGPoint point = [touch locationInView:keyWindow];
        
        CGRect convertFarme = [self convertRect:self.bounds toView:keyWindow];
        BOOL contains = CGRectContainsPoint(convertFarme, point);
        
        if (contains) {
            return;
        }
        
        if([touchView isKindOfClass:[TextField class]] == NO){
            [self endEditing:YES];
        }
    }
}

#pragma mark - SecurityTextField Notification
- (void)securityKeyboardWill:(NSNotification *)notification {
    if (self.isEditing) {
        [self becomeFirstResponder];
    }
}

// MARK: - drawing and positioning overrides


- (CGRect)borderRectForBounds:(CGRect)bounds {
    CGRect borderRect = [super borderRectForBounds:bounds];
    return UIEdgeInsetsInsetRect(borderRect, _borderEdgeInsets);
}

- (CGRect)textRectForBounds:(CGRect)bounds {
    CGRect textRect = [super textRectForBounds:bounds];
    return UIEdgeInsetsInsetRect(textRect, _textEdgeInsets);
}

- (CGRect)placeholderRectForBounds:(CGRect)bounds {
    CGRect placeholderRect = bounds;//[super placeholderRectForBounds:bounds];
    return UIEdgeInsetsInsetRect(placeholderRect, _placeholderEdgeInsets);
}

- (CGRect)editingRectForBounds:(CGRect)bounds {
    CGRect editingRect = [super editingRectForBounds:bounds];
    return UIEdgeInsetsInsetRect(editingRect, _textEdgeInsets);
}

- (CGRect)clearButtonRectForBounds:(CGRect)bounds {
    CGRect clearButtonRect = [super clearButtonRectForBounds:bounds];
    return UIEdgeInsetsInsetRect(clearButtonRect, _clearButtonEdgeInsets);
}

- (CGRect)leftViewRectForBounds:(CGRect)bounds {
    CGRect leftViewRect = [super leftViewRectForBounds:bounds];
    return UIEdgeInsetsInsetRect(leftViewRect, _leftViewEdgeInsets);
}

- (CGRect)rightViewRectForBounds:(CGRect)bounds {

    CGRect slice;
    CGRect remainder;
    CGRectDivide(self.bounds, &slice, &remainder, self.bounds.size.height, CGRectMaxXEdge);
    CGRect rightViewRect = slice;
    return UIEdgeInsetsInsetRect(rightViewRect, _rightViewEdgeInsets);
}
@end

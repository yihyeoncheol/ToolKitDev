//
//  TableViewCell.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol TableViewCellDelegate;

@interface TableViewCell : UITableViewCell
@property(nonatomic,weak)id <TableViewCellDelegate> delegate;
- (void)initial;
- (void)didLoad;
- (void)setData:(nullable id)data ;
- (IBAction)buttonTouchUpInside:(Button *)button;
@end

@protocol TableViewCellDelegate <NSObject>
- (void)tableViewCell:(TableViewCell*)cell message:(Message*) message;

@end


NS_ASSUME_NONNULL_END

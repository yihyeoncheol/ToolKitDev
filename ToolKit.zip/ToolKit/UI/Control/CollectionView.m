//
//  CollectionView.m
//  LPoint
//
//  Created by MP02031 on 2020/10/21.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "CollectionView.h"

@implementation CollectionView

- (void)dealloc {
    _name = nil;
    _style = nil;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self didLoad];
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self){
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self){
        [self initial];
    }
    return self;
}

- (void)initial {
#if (TARGET_IPHONE_SIMULATOR)
//    [self roundWithRadius:0.f width:.5f color:[UIColor blackColor]];
#endif
//    self.backgroundColor = [UIColor clearColor];
}

- (void)viewWillRotate:(id<UIViewControllerTransitionCoordinatorContext>) context
{
#if 0
    NSTimeInterval animationDuration = [context transitionDuration];
    UIViewAnimationCurve animationCurve = [context completionCurve];
    //
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    [UIView setAnimationBeginsFromCurrentState:YES];
     // run
    [UIView commitAnimations];
    
#endif
}

- (void)didLoad { }



@end

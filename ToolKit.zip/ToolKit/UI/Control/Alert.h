//
//  Alert.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, AlertType){
    AlertTypeCaution  = 0,
    AlertTypeDefault = 1
};

@interface Alert : UIView
+ (Alert*) alertWithTitle:(nullable NSString *)title
                  message:(NSString *)message
                     type:(AlertType)type
        cancelButtonTitle:(nullable NSString *)cancelButtonTitle
         otherButtonTitle:(nullable NSString *)otherButtonTitle
                  handler:(nullable void(^)(NSInteger buttonIndex))handler;

+ (void)dismiss;
@end

NS_ASSUME_NONNULL_END

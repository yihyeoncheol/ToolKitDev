//
//  ScrollView.m
//  LPoint
//
//  Created by MP02031 on 2020/10/23.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "ScrollView.h"

@implementation ScrollView

- (void)dealloc {

}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self didLoad];
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self){
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self){
        [self initial];
    }
    return self;
}

- (void)initial {
#if (TARGET_IPHONE_SIMULATOR)
//    [self roundWithRadius:0.f width:.5f color:[UIColor blackColor]];
#endif
    
    self.decelerationRate = UIScrollViewDecelerationRateFast;
}
- (void)didLoad {
    
}
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    
    return [super hitTest:point withEvent:event];
}

- (BOOL)touchesShouldBegin:(NSSet *)touches withEvent:(UIEvent *)event inContentView:(UIView *)view{
    UITouch *touch = [touches anyObject];
    if (touch.phase == UITouchPhaseMoved) {
        return NO;
    }else {
        return [super touchesShouldBegin:touches withEvent:event inContentView:view];;
    }
}

- (BOOL)touchesShouldCancelInContentView:(UIView *)view
{
    if ([view isKindOfClass:[UIButton class]]){
        return NO;
    }
    return YES;
}

@end

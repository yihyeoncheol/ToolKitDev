//
//  SegmentedControl.h
//  LPoint
//
//  Created by MP02031 on 2020/11/03.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Component.h"

NS_ASSUME_NONNULL_BEGIN
@protocol SegmentedDelegate;

@interface SegmentedControl : Component
@property(nonatomic) UIEdgeInsets  contentEdgeInsets;
@property(nonatomic,strong)NSArray<NSString*> *items;
@property(nonatomic) NSInteger selectedIndex;
@property(nonatomic)IBInspectable CGFloat spacing;
@property(nonatomic,strong,readonly)NSMutableArray<Button*> *components;

@property(nonatomic,weak)id <SegmentedDelegate> delegate;
@end

@protocol SegmentedDelegate <NSObject>
- (void)segmentedContentView:(NSInteger) selectedIndex;
@end

NS_ASSUME_NONNULL_END

//
//  TextFieldView.h
//  LPoint
//
//  Created by MP02031 on 2020/10/20.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "View.h"

NS_ASSUME_NONNULL_BEGIN

@interface TextFieldView : View
@property (nonatomic,strong)IBOutletCollection(UIView) NSArray *textFields;
@property(nonatomic,strong)IBInspectable UIColor *lineColor;
@property(nonatomic,strong)IBInspectable UIColor *lineSelectedColor;
@property(nonatomic,readonly,getter=isEditing) BOOL editing;
- (void)channgeLineColor:(UIColor *)channgeLineColor;
@property(nullable,nonatomic,strong) void (^editChanged) (BOOL enabled);
@end

NS_ASSUME_NONNULL_END

//
//  PageControl.h
//  LPoint
//
//  Created by MP02031 on 2020/11/03.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Component.h"

NS_ASSUME_NONNULL_BEGIN

@interface PageControl : Component

@property(nonatomic)IBInspectable NSInteger numberOfPages;
@property(nonatomic)IBInspectable NSInteger currentPage;
@property(nonatomic)IBInspectable CGSize currentIndicatorSize;
@property(nonatomic)IBInspectable CGSize indicatorSize;

@property(nonatomic,strong)IBInspectable UIColor *indicatorTintColor;
@property(nonatomic,strong)IBInspectable UIColor *currentIndicatorTintColor;
@property(nonatomic)IBInspectable CGFloat spacing;
- (void)setSpecialIndicator:(ImageView*)indicator index:(NSInteger)index;
@end

NS_ASSUME_NONNULL_END

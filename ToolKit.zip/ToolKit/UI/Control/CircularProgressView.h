//
//  CircularProgressView.h
//  LPoint
//
//  Created by MP02006 on 2021/01/04.
//  Copyright © 2021 MP02031. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CircularProgressView : View
@property(nonatomic) CGFloat value;
@property(nonatomic) CGFloat maxValue;
@end

NS_ASSUME_NONNULL_END

//
//  CollectionViewFlowLayout.m
//  LPoint
//
//  Created by MP02031 on 2020/11/12.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "CollectionViewFlowLayout.h"

@implementation CollectionViewFlowLayout
- (CGPoint)targetContentOffsetForProposedContentOffset:(CGPoint)proposedContentOffset withScrollingVelocity:(CGPoint)velocity {

    if (CGPointEqualToPoint(velocity, CGPointZero)){
        _currentPage = roundf(proposedContentOffset.x / ((self.itemSize.width + self.minimumLineSpacing)));
    }
    
    NSInteger itemsCount = [self.collectionView.dataSource collectionView:self.collectionView numberOfItemsInSection:0];
    
    if  ((_previousOffset > self.collectionView.contentOffset.x) && (velocity.x < 0)) {
        _currentPage = MAX(_currentPage - 1, 0);
    }else if ((_previousOffset < self.collectionView.contentOffset.x) && (velocity.x > 0)) {
        _currentPage = MIN(_currentPage + 1, itemsCount - 1);
    }
    
    CGFloat updatedOffset = ((self.itemSize.width + self.minimumLineSpacing) * _currentPage);
    _previousOffset = updatedOffset;
    
    CGPoint updatedPoint = CGPointMake(updatedOffset, proposedContentOffset.y);
    
    if([self.delegate respondsToSelector:@selector(collectionViewLayout:currentPage:)]) {
        [self.delegate collectionViewLayout:self currentPage:_currentPage];
    }
    
    return updatedPoint;
}

- (void)setCurrentPage:(CGFloat)currentPage {
    _currentPage = currentPage;
    
    CGFloat updatedOffset = ((self.itemSize.width + self.minimumLineSpacing) * _currentPage);
    _previousOffset = updatedOffset;
}

@end

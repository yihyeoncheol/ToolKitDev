//
//  WhiteboardView.h
//  Tin-Can-Whiteboard
//
//  Created by Paula Jacobs on 6/1/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol WhiteboardViewDelegate <NSObject>
@optional
-(void)drawStart;
-(void)drawEnd;
@end

@interface WhiteboardView : UIView
{
    CGRect  rectView;
    CGRect  rRectView;
    NSInteger   objectID;
    
	CGPoint startOfStroke;
	CGPoint location;
	NSMutableArray *strokes;
	
	UIColor *currentStrokeColor;
	NSInteger currentStrokeWidth;
	CFMutableDictionaryRef activeStrokes;
    
    NSMutableArray* colorArray;
    
    UIImageView *backImg;

    BOOL _isTouch;
}

@property (nonatomic, retain) NSMutableArray *strokes;
@property (nonatomic, retain) UIColor *currentStrokeColor;
@property (nonatomic, assign) id <WhiteboardViewDelegate>delegate;

-(id)initWithFrame:(CGRect)frame delegate:(id<WhiteboardViewDelegate>)del;
-(void)changeColorWithColor:(UIColor *)color;
-(void)notErasingAnymore;
-(void)changeStrokeWidthWithDirection:(NSString *) direction;
-(void)changeButtonLocatorLocationWithFrame:(CGRect) frame;
-(void)eraseAll;

@end


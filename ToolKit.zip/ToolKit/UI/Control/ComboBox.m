//
//  ComboBox.m
//  LPoint
//
//  Created by MP02031 on 2020/11/11.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "ComboBox.h"
#import "ActionSheet.h"

@interface ComboBox ()<ActionSheetContentViewDelegate>

//open var cellRegister:Any?
@end

@implementation ComboBox

- (void)initial {
//    self.style = @"defaultComboBox";
    _selectedIndex = 0;
    _textLabel = [[Label alloc]init];
    _imageView = [[ImageView alloc]init];
    _imageView.contentMode = UIViewContentModeCenter;
    [self addSubview:_textLabel];
    [self addSubview:_imageView];
    [self addTarget:self action:@selector(touchUpInside) forControlEvents:UIControlEventTouchUpInside];
}

- (void)didLoad {
    [self setNeedsStyle];
}
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGRect contentRect = UIEdgeInsetsInsetRect(self.bounds, _contentEdgeInsets);
    if(_textLabel.textAlignment == NSTextAlignmentRight){
        _textLabel.frame = contentRect;
    } else {
        _textLabel.frame = [self textRect:contentRect];
    }

    _imageView.frame = [self imageRect:contentRect];
}
- (NSString*)text {
    return _textLabel.text;
}
- (void)setText:(NSString*)text{
    _textLabel.text = text;
   
}

- (void)setTextAlignment:(NSTextAlignment)textAlignment{
    _textLabel.textAlignment = textAlignment;
}

- (void)setAttributedTitle:(NSString*)text {
    NSMutableAttributedString *labelString = [[NSMutableAttributedString alloc] initWithString:text];
    [labelString addAttribute:NSUnderlineStyleAttributeName
                         value:[NSNumber numberWithInteger:NSUnderlineStyleSingle]
                         range:NSMakeRange(0, [text length])];
    
    [labelString addAttribute:NSForegroundColorAttributeName
                         value: [UIColor rgbColorWithRed:0 green:155 blue:250 alpha:1.0]
                         range:NSMakeRange(0, [text length])];
    
    _textLabel.attributedText = labelString;
   
}



- (void)setItems:(NSArray<NSString *> *)items {
    _items = items;
//    _textLabel.text = items.firstObject;
    [self setNeedsStyle];
    [self update];
}

- (void)paint {
    
}

- (void)update {
    
}


- (void)touchUpInside {
    
    ComboBoxContentView *contentView = [[ComboBoxContentView alloc]init];;
    contentView.title = self.text;
    contentView.delegate = self;
    contentView.items = _items;
    contentView.height = 49;
    
    contentView.frame = [UIScreen mainScreen].bounds;
    
    NSInteger icout = (([_items count] > 6) ? 6 : [_items count]);
    
    if([_items count] < 4){
        icout = [_items count];
    }
    
    [contentView registerClass:[ComboBoxCell class]];
    ActionSheet *actionSheet = [ActionSheet new];
    actionSheet.contentHeight = 49 * icout + 56 + 86;
    contentView.actionSheet = actionSheet;
//    actionSheet.actionSheet = actionSheet;
    actionSheet.contentView = contentView;
    [actionSheet show];
}

- (void)setSelectedIndex:(NSInteger)selectedIndex {
    _selectedIndex = selectedIndex;
    _textLabel.text = _items[selectedIndex];
    
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}

- (void)valueChange:(ActionSheet*) actionSheet {
//    let model = items?[actionSheet.selectedIndex] as? MBJO210_06I_02Model
//    self.textLabel.text = model?.pubCdNm
//    self.isSelected = false
//    selectedIndex = actionSheet.selectedIndex
}


- (CGRect)textRect:(CGRect)contentRect {
    CGRect slice;
    CGRect remainder;
    CGRectDivide(contentRect, &slice, &remainder, contentRect.size.height, CGRectMaxXEdge);
    return UIEdgeInsetsInsetRect(remainder, _textEdgeInsets);;
}

- (CGRect)imageRect:(CGRect)contentRect {
    CGRect slice;
    CGRect remainder;
    CGRectDivide(contentRect, &slice, &remainder, contentRect.size.height, CGRectMaxXEdge);
    return UIEdgeInsetsInsetRect(slice, _imageEdgeInsets);;
}


#pragma  mark - ActionSheetContentViewDelegate
- (void)extracted {
    [self.delegate comboContentView:self.selectedIndex];
}

- (void)actionSheetContentView:(ActionSheetContentView*)contentView message:(Message*) message {
    if ([message.name isEqualToString:@"selectRowAtIndex"]){
        NSIndexPath *indexPath = message.object;
        _textLabel.text = _items[indexPath.row];
        self.selectedIndex = indexPath.row;
        [self extracted];
    }
}
@end

@interface ComboBoxContentView()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong) TableView *tableView;
@property(nonatomic,strong) View *titleView;
@property(nonatomic,strong) Label *titleLabel;
@property(nonatomic,strong) Button *bottomButton;
@property(nonatomic,strong) ShadowView *bottomButtonShadowView;
@end

@implementation ComboBoxContentView

- (void)initial {
    
    _titleView = [[View alloc]init];
    _titleView.backgroundColor = [UIColor whiteColor];
    [self addSubview:_titleView];
    _titleLabel = [[Label alloc]init];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    _titleLabel.textColor = [UIColor rgbColorWithRed:34 green:34 blue:34 alpha:1];
    _titleLabel.fontStyle = @"NotoSansCJKkr";
    [_titleView addSubview:_titleLabel];
    
    _tableView = [[TableView alloc]init];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    _tableView.separatorColor = [UIColor rgbColorWithRed:238 green:238 blue:238 alpha:1];
    
    [_tableView setSeparatorInset:UIEdgeInsetsZero];
    
    
    [self addSubview:_tableView];
    
    _bottomButtonShadowView  = [[ShadowView alloc]init];
     [self addSubview:_bottomButtonShadowView];
    _bottomButton = [[Button alloc]init];
    _bottomButton.title = @"닫기";
    _bottomButton.style = @"whiteRoundButton";
//    _bottomButton.fontStyle = @"NotoSansCJKkr";
    [self addSubview:_bottomButton];
    
    [_bottomButton addTarget:self.actionSheet action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    
    _titleView.edgeLines = @[[[EdgeLine alloc] initWithEdge:UIRectEdgeBottom
                                                      color:[UIColor rgbColorWithRed:238 green:238 blue:238 alpha:1]
                                                      width:1
                                                    edgeInsets:UIEdgeInsetsZero]];
}

- (void)layoutSubviews {
    
    
    [super layoutSubviews];
    
    CGRect slice;
    CGRect remainder;
       
    CGRectDivide(self.bounds, &slice, &remainder, 56, CGRectMinYEdge);
    _titleView.frame = slice;
    _titleLabel.frame = UIEdgeInsetsInsetRect(_titleView.bounds, UIEdgeInsetsMake(0, 0, 30, 0));

    CGFloat height = _height * _items.count;
    
     CGRectDivide(remainder, &slice, &remainder, height, CGRectMinYEdge);
    
    
    _tableView.frame = slice;
    
    _bottomButton.frame =  UIEdgeInsetsInsetRect(remainder, UIEdgeInsetsMake(30, 16, 0, 16));
    _bottomButtonShadowView.frame = _bottomButton.frame;
}


- (void)setTitle:(NSString *)title {
    _title = title;
    _titleLabel.text = title;
}
- (void)setHeight:(CGFloat)height {
    _height = height;
    [_tableView setRowHeight:height];
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return _height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    [CATransaction begin];
    
    [tableView beginUpdates];
    [CATransaction setCompletionBlock:^{
        [self.delegate actionSheetContentView:self message:[Message messageWithName:@"selectRowAtIndex" object:indexPath]];
        [self.actionSheet dismiss];
    }];
                     
    [tableView endUpdates];
    [CATransaction commit];
    
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ComboBoxCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ComboBoxCell" forIndexPath:indexPath];
    
    cell.contentEdgeInsets = UIEdgeInsetsMake(0, 16, 0, 0);
    [cell setData:_items[indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)registerNib:(nullable UINib *)nib {
    [_tableView registerNib:nib forCellReuseIdentifier:@"ComboBoxCell"];
}

- (void)registerClass:(nullable Class)cellClass {
    [_tableView registerClass:cellClass forCellReuseIdentifier:@"ComboBoxCell"];
}

@end

@implementation ComboBoxCell

- (void)initial {
    self.textLabel.textColor = [UIColor rgbColorWithRed:34 green:34 blue:34 alpha:1];
    self.textLabel.font = [UIFont fontWithName:@"NotoSans-Regular" size:14];
}
- (void)layoutSubviews {
    [super layoutSubviews];
    self.textLabel.frame = UIEdgeInsetsInsetRect(self.contentView.bounds, _contentEdgeInsets);
}
- (void)setData:(id)data {
    self.textLabel.text = (NSString*)data;
}
@end

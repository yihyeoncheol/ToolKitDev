//
//  Alert.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "Alert.h"
//#import <objc/runtime.h>
#import "Label.h"
#import "Button.h"
#import "View.h"
#import "EdgeLine.h"

#import "UIColor+Extension.h"



typedef void (^AletCompletionHandler)(NSInteger buttonIndex);

@interface  Alert()

@property(nonatomic,strong) AletCompletionHandler completionHandler;

@property(nonatomic,strong) NSString *title;
@property(nonatomic,strong) NSString *message;
@property(nonatomic,strong) NSMutableArray *buttonTitles;

@property(nonatomic) NSInteger cancelButtonIndex;

@property(nonatomic,readonly) NSInteger numberOfButtons;
@property(nonatomic,readonly) NSInteger firstOtherButtonIndex;

@property(nonatomic,readonly) NSMutableAttributedString *attributedTitle;
@property(nonatomic,readonly) NSMutableAttributedString *attributedMessage;
//@property(nonatomic,strong) UIImage *titleBackgroundImage;


@property(nonatomic) UIEdgeInsets contentEdgeInsets;
@property(nonatomic) UIEdgeInsets titleEdgeInsets;
@property(nonatomic) UIEdgeInsets messageEdgeInsets;
@property(nonatomic) UIEdgeInsets buttonEdgeInsets;

- (NSInteger)addButtonWithTitle:(NSString *)title;
- (NSString*)buttonTitleAtIndex:(NSInteger)buttonIndex;
@property(nonatomic,strong) View *backgroundView;
@property(nonatomic) AlertType type;
//- (id)initWithTitle:(NSString *)title message:(NSString *)message handler:(void(^)(NSInteger buttonIndex))handler cancelButtonTitle:(NSString *)cancelButtonTitle otherButtonTitles:(NSString *)otherButtonTitle;

@end

@implementation Alert

+ (void)dismiss{
    UIView *alertLayer = [[UIApplication sharedApplication].keyWindow.rootViewController valueForKey:@"alertLayerView"];
    for ( UIView *view  in alertLayer.subviews) {
        if ([view isMemberOfClass:[Alert class]]) {
//            Alert *alert =(Alert*)view;
//            [alert dismissWithClickedButtonIndex:-1 animated:NO];
            [view removeFromSuperview];
        }
    }
}

+ (Alert*) alertWithTitle:(NSString *)title
                  message:(NSString *)message
                     type:(AlertType)type
        cancelButtonTitle:(nullable NSString *)cancelButtonTitle
         otherButtonTitle:(nullable NSString *)otherButtonTitle
                  handler:(nullable void(^)(NSInteger buttonIndex))handler;
{
    Alert *alert = [[Alert alloc] initWithTitle:title message:message handler:handler cancelButtonTitle:cancelButtonTitle otherButtonTitle:otherButtonTitle];
    alert.type = type;
    [alert show];
    return nil;
}

- (void)dealloc{
//    NSLog(@"%@ dealloc",NSStringFromClass([self class]));
    _backgroundView  = nil;
    _completionHandler = nil;
    _title = nil;
    _message = nil;
    _buttonTitles = nil;
    _attributedTitle = nil;
    _attributedMessage = nil;
    
}


- (id)initWithTitle:(NSString *)title message:(NSString *)message
            handler:(void(^)(NSInteger buttonIndex))handler
  cancelButtonTitle:(NSString *)cancelButtonTitle
  otherButtonTitle:(NSString *)otherButtonTitle{
    
//    CGRect frame = [UIScreen mainScreen].bounds;
//    CGFloat width =  MIN(frame.size.width, frame.size.height);
//    width = width * (294.f / 320.f);
    self = [super init];
    
    if (self){
        self.buttonTitles = [NSMutableArray arrayWithCapacity:1];
        
        self.completionHandler = handler;
        
        if (title == nil) {
//            NSString *appName = [[[NSBundle mainBundle] localizedInfoDictionary] objectForKey:@"CFBundleDisplayName"];
            //NSString *appName = [[[NSBundle mainBundle] infoDictionary] objectForKey:(id)kCFBundleNameKey];
            title = @"L.POINT";
        }
        
        self.title = title;
        self.message = message;
        _cancelButtonIndex = -1;
        if (cancelButtonTitle){
            _cancelButtonIndex = [self addButtonWithTitle:cancelButtonTitle];
        }
        _firstOtherButtonIndex = -1;
        if (otherButtonTitle){
            _firstOtherButtonIndex = 1;
            [self addButtonWithTitle:otherButtonTitle];
        }
    }
    [self initial];
    return self ;
}

- (void) initial {
    
    [self setBackgroundColor:[UIColor clearColor]];
    
    _backgroundView = [[View alloc]init];
    [self addSubview:_backgroundView];
    _contentEdgeInsets  = UIEdgeInsetsMake(0, 0, 0, 0);
    _titleEdgeInsets    = UIEdgeInsetsMake(40, 24, 0, 24);
    _messageEdgeInsets  = UIEdgeInsetsMake(16, 20, 16, 20);
    _buttonEdgeInsets   = UIEdgeInsetsMake(0, 0, 0, 0);
    
}

- (NSInteger)addButtonWithTitle:(NSString *)title{
    [_buttonTitles addObject:title];
    return ([_buttonTitles count] - 1);
}

- (NSString *)buttonTitleAtIndex:(NSInteger)buttonIndex{
    return [_buttonTitles objectAtIndex:buttonIndex];
}


- (CGFloat)titleHeight {
    return 66.0f;
}

- (CGFloat)messageHeight {
    return  76.0;
}

- (CGFloat)buttonHeight {
    return 59.0;
}

- (CGFloat)width {
    return 296 * (UIScreen.mainScreen.bounds.size.width / 360);
}

- (UIView*)titleView:(CGRect)frame {
    View *container = [[View alloc]initWithFrame:frame];
    container.backgroundColor = [UIColor clearColor];
    Label *label = [[Label alloc]initWithFrame:container.bounds];
    label.text = self.title;
    label.numberOfLines = 1;
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"NotoSans-Medium" size:16];

    label.textColor = [UIColor rgbColorWithRed:34 green:34 blue:34 alpha:1];
    [container addSubview:label];
    return container;
}

- (UIView*)messageView:(CGRect)frame {
    
    Label *label = [[Label alloc]initWithFrame:frame];
    label.text = self.message;
    label.numberOfLines = 0;
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont fontWithName:@"NotoSans-Light" size:14];
    label.textColor = [UIColor rgbColorWithRed:34 green:34 blue:34 alpha:1];
    [label sizeToFit];
    
    CGRect viewRect = frame;
    
    
    CGFloat height = MAX(label.bounds.size.height, [self messageHeight]);
    viewRect.size.height = height + (_messageEdgeInsets.top + _messageEdgeInsets.bottom);
    
    label.frame = CGRectMake(0, 0, frame.size.width, height);
    
    View *container = [[View alloc]initWithFrame:viewRect];
    container.backgroundColor = [UIColor clearColor];
    [container addSubview:label];
    
    return container;
}

- (UIView*)buttonView:(CGRect)frame {
    
    View *buttonView = [[View alloc]initWithFrame:frame];
    buttonView.backgroundColor = [UIColor clearColor];
    buttonView.edgeLines = @[[[EdgeLine alloc]initWithEdge:UIRectEdgeTop color:[UIColor rgbColorWithRed:238 green:238 blue:238 alpha:1] width:1 edgeInsets:UIEdgeInsetsZero]];
        
    [self addSubview:buttonView];
    CGFloat buttonWidth = buttonView.frame.size.width;
    CGFloat buttonHeight = buttonView.frame.size.height;
    
    NSInteger cnt = self.buttonTitles.count;
    
    for ( int i = 0; i < cnt ; i ++){
    
        NSString *title = self.buttonTitles[i];
    
        Button *button = [Button buttonWithType:UIButtonTypeCustom];
        button.tag = i;
        button.title = title;
        
        button.contentEdgeInsets = UIEdgeInsetsMake(0, 24, 0, 24);
        [button addTarget:self action:@selector(buttonEvent:) forControlEvents:UIControlEventTouchUpInside];
        
        button.titleFont = [UIFont fontWithName:@"NotoSans-Regular" size:13];
        
        if(cnt == 2) {
            buttonWidth = (buttonView.frame.size.width / 2.0f);
            CGRect frame = CGRectMake((buttonWidth * i) ,0 , buttonWidth , buttonHeight);
            [button setFrame:CGRectInset(frame, 0, 0)];
            button.contentHorizontalAlignment = (i == 0? UIControlContentHorizontalAlignmentLeft:UIControlContentHorizontalAlignmentRight);
        }else{
            CGRect frame = CGRectMake((buttonView.bounds.size.width - buttonWidth) / 2, buttonHeight * i, buttonWidth , buttonHeight);
            [button setFrame:CGRectInset(frame, 0, 0)];
            button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        }
        
        if (_cancelButtonIndex == i) {
             button.titleColor = [UIColor rgbColorWithRed:153 green:153 blue:153 alpha:1];

        }else{
             button.titleColor = [UIColor rgbColorWithRed:0 green:155 blue:250 alpha:1];

        }
        [buttonView addSubview:button];
    }
    
    return buttonView;
}
    
- (void)buttonEvent:(UIButton*)button {
    
    NSInteger buttonIndex = button.tag;
    if (_completionHandler) {
        self.completionHandler(buttonIndex);
    }
    
    [self dismissAnimation];
}

- (void)show {
    UIView *view = [[UIApplication sharedApplication].keyWindow.rootViewController valueForKey:@"alertLayerView"];
    [self showInView:view];
}

- (void)showInView:(UIView*)inView{
    
    
    /*
        +-----------------+
        | title           |
        +-----------------+
        |                 |
        | message         |
        |                 |
        +-----------------+
        | cancel |   ok   |
        +--------+--------+
    */
        
        
    
    CGFloat height = .0f;
        
    CGRect maxframe = CGRectMake(0,0,
                                 335 * (MIN(UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height) / 375),
                                 inView.bounds.size.height);
        

    NSInteger nCnt = _buttonTitles.count;
        
    CGFloat buttonViewHeight = nCnt > 1 ? ([self buttonHeight] * (nCnt-1)) : [self buttonHeight];
        
    
    
    
    height += buttonViewHeight;
    
    height += [self titleHeight];
    
    CGRect contentRect = UIEdgeInsetsInsetRect(maxframe, _contentEdgeInsets);
    
    CGRect slice;
    CGRect remainder;
    
    CGRectDivide(contentRect, &slice, &remainder, [self titleHeight], CGRectMinYEdge);
    
    UIView *titleView = [self titleView:UIEdgeInsetsInsetRect(slice, _titleEdgeInsets)];
    [self addSubview:titleView];
    
    
    
    
    UIView *messageView = [self messageView:UIEdgeInsetsInsetRect(remainder,_messageEdgeInsets)];
    
    height += messageView.frame.size.height ;
    
    [self addSubview:messageView];
    
    CGRectDivide(remainder, &slice, &remainder, messageView.frame.size.height, CGRectMinYEdge);
    
    
    CGRectDivide(remainder, &slice, &remainder, [self buttonHeight], CGRectMinYEdge);
    
    
    UIView *buttonView = [self buttonView:UIEdgeInsetsInsetRect(slice, _buttonEdgeInsets)];
    
    [self addSubview:buttonView];
    
    
//    [buttonView drawEdgeLines:@[[[EdgeLine alloc]initWithEdge:UIRectEdgeTop color:[UIColor redColor] width:1 edgeInsets:UIEdgeInsetsZero]]];
    
    
    
    self.frame = CenterInRect(CGRectMake(0, 0, 335 * (MIN(UIScreen.mainScreen.bounds.size.width,UIScreen.mainScreen.bounds.size.height) / 375), height), inView.bounds);
    
    ImageView *icoImageView = [[ImageView alloc]init];
    icoImageView.image = (_type == AlertTypeDefault) ? [UIImage imageNamed:@"icoAlert2"] : [UIImage imageNamed:@"icoAlert"];
    
    icoImageView.frame = CGRectMake(16, -24, 48, 48);
    [self addSubview:icoImageView];
    
    _backgroundView.backgroundColor = [UIColor whiteColor];
    _backgroundView.frame = self.bounds;
    [_backgroundView roundWithRadius:15 width:0 color:nil];
    
    self.alpha = 0.0;
    [inView addSubview:self];
    
    [self showAnimation];
}

- (void)closeBtnTouchUpInside:(UIButton*)button {
}

- (void)dismissWithClickedButtonIndex:(NSInteger)buttonIndex animated:(BOOL)animated {
//    BOOL cancelled = (buttonIndex == self.cancelButtonIndex);
   
    if (_completionHandler){
        _completionHandler(buttonIndex);
    }
}

- (void)viewWillRotate:(id<UIViewControllerTransitionCoordinatorContext>) context {
    NSTimeInterval animationDuration = [context transitionDuration];
    UIViewAnimationCurve animationCurve = [context completionCurve];
    //
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    [UIView setAnimationBeginsFromCurrentState:YES];
    // run
     self.frame = CenterInRect(self.bounds, self.superview.bounds);
    
    [UIView commitAnimations];
}


- (void)dismissAnimation {
    [UIView animateWithDuration:0.3f animations:^{
        self.alpha = 0.0;
        self.transform = CGAffineTransformMakeScale(0.05, 0.05);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];

}

- (void)showAnimation {
    self.alpha = 0.0;
    self.transform = CGAffineTransformMakeScale(0.05, 0.05);
    [UIView animateWithDuration:0.3f animations:^{
        self.alpha = 1.0f;
        self.transform = CGAffineTransformMakeScale(1.0f, 1.0f);
    } completion:^(BOOL finished) {
        
    }];
}


@end



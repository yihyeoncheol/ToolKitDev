
#import <QuartzCore/QuartzCore.h>
#import "Toast.h"

// Set visibility duration
static const CGFloat kDuration = 3.0f;

// Static toastview queue variable
static NSMutableArray *toasts;


@interface Toast ()
@property (nonatomic, readonly) UILabel *textLabel;

- (void)fadeToastOut;
+ (void)nextToastInView:(UIView *)parentView;

@end

@implementation Toast

#pragma mark - NSObject

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark - Public

+ (void)toastwithText:(NSString *)text {
    // Add new instance to queue
    Toast *view = [[Toast alloc] initWithText:text];
    
    
    UIApplication *application  = [UIApplication sharedApplication];
    UIView *topView = [[application keyWindow].rootViewController valueForKey:@"topLayerView"];;
    
    CGFloat lWidth  = view.textLabel.frame.size.width;
    CGFloat lHeight = view.textLabel.frame.size.height;
    
    CGFloat pWidth  = topView.frame.size.width;
    CGFloat pHeight = topView.frame.size.height;
    
    // Change toastview frame
    view.frame = CGRectMake((pWidth - lWidth - 20) / 2., pHeight - lHeight - 60, lWidth + 20, lHeight + 10);
    view.alpha = 0.0f;
    
    if (toasts == nil){
        toasts = [[NSMutableArray alloc] initWithCapacity:1];
        [toasts addObject:view];
        [Toast nextToastInView:topView];
    }else{
        [toasts addObject:view];
    }
}


+ (void)toastInView:(UIView *)parentView withText:(NSString *)text {
    // Add new instance to queue
    Toast *view = [[Toast alloc] initWithText:text];
    
    CGFloat lWidth = view.textLabel.frame.size.width;
    CGFloat lHeight = view.textLabel.frame.size.height;
    CGFloat pWidth = parentView.frame.size.width;
    CGFloat pHeight = parentView.frame.size.height;
    
    // Change toastview frame
    view.frame = CGRectMake((pWidth - lWidth - 20) / 2., pHeight - lHeight - 60, lWidth + 20, lHeight + 10);
    view.alpha = 0.0f;
    
    if (toasts == nil){
        toasts = [[NSMutableArray alloc] initWithCapacity:1];
        [toasts addObject:view];
        [Toast nextToastInView:parentView];
    }else{
        [toasts addObject:view];
    }
}


+ (void)nextToastInView:(UIView *)parentView {
    if ([toasts count] > 0){
        Toast *view = [toasts objectAtIndex:0];
        
        // Fade into parent view
        [parentView addSubview:view];
        [UIView animateWithDuration:0.3f
                              delay:0.f
                            options:UIViewAnimationOptionAllowUserInteraction
                         animations:^{
                             view.alpha = 1.0f;
                         } completion:^(BOOL finished){
                         }];
        
        // Start timer for fade out
        [view performSelector:@selector(fadeToastOut) withObject:nil afterDelay:kDuration];
    }
}

- (void)dealloc{
    _textLabel = nil;
    
}

- (id)initWithText:(NSString *)text {
    self = [self initWithFrame:CGRectZero];
	if (self){
        // Add corner radius
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:.6];
        self.layer.cornerRadius = 5;
        self.autoresizingMask = UIViewAutoresizingNone;
        self.autoresizesSubviews = NO;
        
        // Init and add label
        _textLabel = [[UILabel alloc] init];
        _textLabel.text = text;
        //        _textLabel.minimumScaleFactor = 14;
        _textLabel.font = [UIFont systemFontOfSize:14];
        _textLabel.textColor = [UIColor whiteColor];
        _textLabel.adjustsFontSizeToFitWidth = NO;
        _textLabel.backgroundColor = [UIColor clearColor];
        [_textLabel sizeToFit];
        
        [self addSubview:_textLabel];
        _textLabel.frame = CGRectOffset(_textLabel.frame, 10, 5);
	}
	return self;
}

- (void)initLayout
{
    
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark - Private

- (void)fadeToastOut
{
	// Fade in parent view
    [UIView animateWithDuration:0.3f
                          delay:0.f
                        options:UIViewAnimationOptionAllowUserInteraction
                     animations:^{
                         self.alpha = 0.f;
                     }completion:^(BOOL finished){
                         UIView *parentView = self.superview;
                         [self removeFromSuperview];
                     
                         // Remove current view from array
                         [toasts removeObject:self];
                       
                         if([toasts count] == 0){
                             toasts = nil;
                         }else{
                             [Toast nextToastInView:parentView];
                         }
                     }];
}

- (void)viewWillRotate:(id<UIViewControllerTransitionCoordinatorContext>)context
{
    
}
@end

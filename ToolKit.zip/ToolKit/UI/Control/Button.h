//
//  Button.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EdgeLine.h"
NS_ASSUME_NONNULL_BEGIN

//IB_DESIGNABLE

@interface Button : UIButton

@property(nullable,nonatomic,strong) void (^action) (void);
@property(nullable,nonatomic,strong) void (^layoutChanged) (id self);
@property(nullable,nonatomic,strong) void (^enabledChanged) (BOOL enabled);
@property(nullable,nonatomic,strong)IBInspectable NSString *name;
@property(nullable,nonatomic,strong)IBInspectable NSString *style;
@property(nullable,nonatomic,strong)IBInspectable NSString *fontStyle;

@property(nullable,nonatomic,strong)IBInspectable UIColor *titleColor;
@property(nullable,nonatomic,strong)IBInspectable NSString *title;
@property(nullable,nonatomic,strong)UIFont *titleFont;
@property(nonatomic)IBInspectable CGFloat cornerRadius;
@property(nonatomic)IBInspectable CGFloat borderWidth;
@property(nullable,nonatomic,strong)IBInspectable UIColor *borderColor;
//@property(nullable,nonatomic,strong) NSArray<EdgeLine*> *edgeLines;
- (void)initial;
- (void)setImage:(nullable UIImage *)image;
@end

NS_ASSUME_NONNULL_END

//
//  ViewLayoutProtocal.h
//  LPoint
//
//  Created by MP02031 on 2020/10/16.
//  Copyright © 2020 MP02031. All rights reserved.
//

@protocol ViewLayoutProtocal <NSObject>
- (void)willLayout;
- (void)didLayout;
@end

//
//  EdgeLine.m
//  LPoint
//
//  Created by MP02031 on 2020/10/16.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "EdgeLine.h"

@implementation EdgeLine

- (void)dealloc{
    _color = nil;
}

- (instancetype)initWithEdge:(UIRectEdge)edge
                       color:(UIColor*)color
                       width:(CGFloat)width
                  edgeInsets:(UIEdgeInsets)insets {
    self = [super init];
    if (self) {
        self.edge   = edge;
        self.insets = insets;
        self.width  = width;
        self.color  = color;
    }
    return self;
}


- (instancetype)init {
    self = [super init];
    if (self) {
        _edge = UIRectEdgeNone;
        _insets = UIEdgeInsetsZero;
        _width = 1.0f;
        _color = [UIColor blackColor];
    }
    return self;
}
@end

@implementation UIView (EdgeLine)

- (void)drawEdgeLines:(NSArray<EdgeLine*>*)lines rect:(CGRect)rect context:(CGContextRef)context{
     
    CGFloat y = rect.origin.y;
    CGFloat x = rect.origin.x;
    CGFloat height = rect.size.height;
    CGFloat width = rect.size.width;
    for (EdgeLine *line in lines) {
        CGColorRef borderColor = line.color.CGColor;
        CGFloat lineWidth = line.width;// * [UIScreen mainScreen].scale;

        CGContextSetStrokeColorWithColor(context, borderColor);
        CGContextSetLineWidth(context, lineWidth);
        
        
        if(line.edge & UIRectEdgeTop) {
            CGContextMoveToPoint(context, x+ line.insets.left , y + line.insets.top);
            CGContextAddLineToPoint(context, (width + x) - line.insets.right, y + line.insets.top);
        }

        if(line.edge & UIRectEdgeLeft) {
            CGContextMoveToPoint(context, x + line.insets.left, line.insets.top);
            CGContextAddLineToPoint(context, x + line.insets.left, (height + y) - line.insets.bottom);
        }
        
        if(line.edge & UIRectEdgeBottom) {
            CGContextMoveToPoint(context, x + line.insets.left, (height + y) - line.insets.bottom);
            CGContextAddLineToPoint(context, (width + x) - line.insets.right, (height + y) - line.insets.bottom);
        }
        
        if(line.edge & UIRectEdgeRight) {
            CGContextMoveToPoint(context, (width + x) - line.insets.right, line.insets.top);
            CGContextAddLineToPoint(context, (width + x) - line.insets.right, (height + y) - line.insets.bottom);
        }
        
    }
     CGContextStrokePath(context);
}

- (void)drawEdgeLines:(NSArray<EdgeLine*>*)lines {
    CGContextRef context = UIGraphicsGetCurrentContext();
//    CGContextSetFillColorWithColor(context, self.backgroundColor.CGColor);
//    CGContextFillRect(context, self.bounds);
    
    
    CGFloat y = self.bounds.origin.y;
    CGFloat x = self.bounds.origin.x;
    CGFloat height = self.bounds.size.height;
    CGFloat width = self.bounds.size.width;
    for (EdgeLine *line in lines) {
        CGColorRef borderColor = line.color.CGColor;
        CGFloat lineWidth = line.width;// * [UIScreen mainScreen].scale;

        CGContextSetStrokeColorWithColor(context, borderColor);
        CGContextSetLineWidth(context, lineWidth);
        
        
        if(line.edge & UIRectEdgeTop) {
            CGContextMoveToPoint(context, x + line.insets.left, y + line.insets.top);
            CGContextAddLineToPoint(context, (width + x) - line.insets.right, y + line.insets.top);
        }

        if(line.edge & UIRectEdgeLeft) {
            CGContextMoveToPoint(context, x + line.insets.left, line.insets.top);
            CGContextAddLineToPoint(context, x + line.insets.left, (height + y) - line.insets.bottom);
        }
        
        if(line.edge & UIRectEdgeBottom) {
            CGContextMoveToPoint(context, x + line.insets.left, (height + y) - line.insets.bottom);
            CGContextAddLineToPoint(context, (width + x) - line.insets.right, (height + y) - line.insets.bottom);
        }
        
        if(line.edge & UIRectEdgeRight) {
            CGContextMoveToPoint(context, (width + x) - line.insets.right, line.insets.top);
            CGContextAddLineToPoint(context, (width + x) - line.insets.right, (height + y) - line.insets.bottom);
        }
        
    }
     CGContextStrokePath(context);
}

//- (void)drawBorder:(CGRect)rect context:(CGContextRef)context {
//
//    CGFloat y = rect.origin.y;
//    CGFloat x = rect.origin.x;
//    CGFloat height = rect.size.height;
//    CGFloat width = rect.size.width;
//
//    CGColorRef borderColor = self.isEditing ? _underLineSelectedColor.CGColor : _underLineColor.CGColor;
//
//    CGContextSetStrokeColorWithColor(context, borderColor);
//    CGContextSetLineWidth(context, 1.0f);
//
//    CGContextMoveToPoint(context, x + _contentEdgeInsets.left, height + y);
//    CGContextAddLineToPoint(context, (width + x) - _contentEdgeInsets.right, height + y);
//    CGContextStrokePath(context);
//}


@end

#if 0



public struct Border {
    var edges:[UIRectEdge]
    var color: UIColor
    var width: CGFloat
    var insets: UIEdgeInsets
}

borders = [Border(edges: [.bottom], color: .hexString("c8c8c8"), width: 0.5,insets: .zero)]
override open func draw(_ rect: CGRect) {
       super.draw(rect)
       let context = UIGraphicsGetCurrentContext()
       drawBorder(context, rect: rect,borders: borders ?? [Border]())
   }

func drawBorder(_ context: CGContext?, rect: CGRect, borders:[Border]) {
    
    let y = rect.origin.y
    let x = rect.origin.x
    let height = rect.height
    let width = rect.width
    
    for border in borders {
        let borderColor = border.color.cgColor
        let lineWidth = border.width //* UIScreen.main.scale
        
        for edge in border.edges {
            
            context?.setStrokeColor(borderColor)
            context?.setLineWidth(lineWidth)
            
            switch edge {
            case .left:
                context?.move(to: CGPoint(x: x + border.insets.left, y: border.insets.top))
                context?.addLine(to: CGPoint(x: x + border.insets.left, y: (height + y) - border.insets.bottom ))
                 break
            case .bottom:
                context?.move(to: CGPoint(x: x + border.insets.left, y: (height + y) - border.insets.bottom))
                context?.addLine(to: CGPoint(x: (width + x) - border.insets.right, y: (height + y) - border.insets.bottom))
                 break
            case .right:
                context?.move(to: CGPoint(x: (width + x) - border.insets.right, y: border.insets.top))
                context?.addLine(to: CGPoint(x: (width + x) - border.insets.right , y: (height + y) - border.insets.bottom))
                 break
            case .top:
                context?.move(to: CGPoint(x: x + border.insets.left, y: y + border.insets.top))
                context?.addLine(to: CGPoint(x: (width + x) - border.insets.right, y: y + border.insets.top))
                 break
            default:
                break
            }
        }
    }
    context?.strokePath()
}

#endif

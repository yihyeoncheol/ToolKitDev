//
//  EdgeLine.h
//  LPoint
//
//  Created by MP02031 on 2020/10/16.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface EdgeLine : NSObject
@property(nonatomic)UIRectEdge edge;
@property(nonatomic, strong, nonnull)UIColor *color;
@property(nonatomic)CGFloat width;
@property(nonatomic)UIEdgeInsets insets;

- (instancetype)initWithEdge:(UIRectEdge)edge
                       color:(UIColor*)color
                       width:(CGFloat)width
                  edgeInsets:(UIEdgeInsets)insets;
@end

@interface UIView (EdgeLine)
- (void)drawEdgeLines:(NSArray<EdgeLine*>*)border;
- (void)drawEdgeLines:(NSArray<EdgeLine*>*)lines rect:(CGRect)rect context:(CGContextRef)context;
@end

NS_ASSUME_NONNULL_END

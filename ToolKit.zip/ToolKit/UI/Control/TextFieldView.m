//
//  TextFieldView.m
//  LPoint
//
//  Created by MP02031 on 2020/10/20.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "TextFieldView.h"
#import "SecurityTextField.h"

@interface TextFieldView()

@end

@implementation TextFieldView

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    _lineColor = nil;
    _lineSelectedColor = nil;
    _editChanged = nil;
}

- (void)initial {
    
     _editing = NO;
 
    
    self.lineSelectedColor = [UIColor rgbColorWithRed:216 green:216 blue:216 alpha:1.0]; //[UIColor hex:0x389cfd];
   // self.lineColor = [UIColor hex:0xdddddd];
    
    self.lineColor = [UIColor clearColor];
    
    [self roundWithRadius:10.0f width:1.0f color:[UIColor clearColor]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(didBeginEditing:)
                                                    name:UITextFieldTextDidBeginEditingNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    [NSNotificationCenter.defaultCenter addObserver:self
                                           selector:@selector(securityKeyboardWill:)
                                               name:SecurityKeyboardWillShowNotification
                                             object:nil];
    
    [NSNotificationCenter.defaultCenter addObserver:self
                                           selector:@selector(securityKeyboardHide:)
                                               name:SecurityKeyboardWillHideNotification
                                             object:nil];
    
    
    
}
- (void)channgeLineColor:(UIColor *)channgeLineColor {
   // if (_editing) {
        [self roundWithRadius:10.0f width:1.0f color:channgeLineColor];
     //   _editing = NO;
   // }
}
- (void)didBeginEditing:(NSNotification *)notification {
    if (_editing) {
        return;
    }
    
    id obj = notification.object;
    
    if ([_textFields containsObject:obj]){
        _editing = YES;
        [self roundWithRadius:10.0f width:1.0f color:_lineSelectedColor];
        
        if (_editChanged) {
            _editChanged(_editing);
        }
    }
}

- (void)keyboardWillHide:(NSNotification *)notification {
    if (_editing) {
        [self roundWithRadius:10.0f width:1.0f color:_lineColor];
        _editing = NO;
        if (_editChanged) {
            _editChanged(_editing);
        }
    }
}

- (void)securityKeyboardHide:(NSNotification *)notification {
    if (_editing) {
        [self roundWithRadius:10.0f width:1.0f color:_lineColor];
        _editing = NO;
        if (_editChanged) {
            _editChanged(_editing);
        }
    }
}

- (void)securityKeyboardWill:(NSNotification *)notification {
    if (_editing) {
        return;
    }
    
    id obj = notification.object;
    
    if ([_textFields containsObject:obj]){
        _editing = YES;
        if (_editChanged) {
            _editChanged(_editing);
        }
        [self roundWithRadius:10.0f width:1.0f color:_lineSelectedColor];
    }
}


@end

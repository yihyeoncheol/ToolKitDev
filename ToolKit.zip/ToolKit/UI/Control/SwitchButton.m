//
//  SwitchButton.m
//  LPoint
//
//  Created by MP02006 on 2020/10/14.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "SwitchButton.h"

@implementation SwitchButton


- (id)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder])
    {
        [self prepare];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame])
    {
        [self prepare];
    }
    return self;
}


- (void)prepare {
    [self addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    self.adjustsImageWhenHighlighted = NO;
}


- (void)buttonClicked:(id)sender {
    self.selected = !self.selected;
    [self.window endEditing:YES];
}

@end

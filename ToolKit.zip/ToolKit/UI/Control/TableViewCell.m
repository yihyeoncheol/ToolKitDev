//
//  TableViewCell.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)dealloc {
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self didLoad];
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self){
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self){
        [self initial];
    }
    return self;
}

- (void)initial {}

- (void)didLoad {}

- (void)setData:(id)data{}

- (IBAction)buttonTouchUpInside:(Button *)button{}
@end

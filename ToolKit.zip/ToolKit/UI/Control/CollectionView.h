//
//  CollectionView.h
//  LPoint
//
//  Created by MP02031 on 2020/10/21.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CollectionView : UICollectionView
@property(nullable,nonatomic,strong)IBInspectable NSString *name;
@property(nullable,nonatomic,strong)IBInspectable NSString *style;

- (void)initial;
- (void)didLoad;
@end

NS_ASSUME_NONNULL_END


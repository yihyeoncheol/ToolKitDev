//
//  Camera.h
//  LPoint
//
//  Created by MP02031 on 2020/10/14.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "Component.h"
#import <AVFoundation/AVFoundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol CameraDelegate;

@interface Camera : Component
@property(nonatomic)UIImagePickerControllerCameraFlashMode flashMode;
@property(nonatomic,weak)id<CameraDelegate> delegate;
@property(nonatomic)AVCaptureVideoOrientation videoOrientation;
@property(nonatomic)CGSize size;
- (void)on;
- (void)off;
- (void)shutter;
@end

@protocol CameraDelegate <NSObject>
@optional
- (void)camera:(Camera*)camera metatype:(AVMetadataObjectType)type data:(NSString*)data;
- (void)camera:(Camera*)camera didFinishProcessingPhoto:(UIImage*)photo;
- (void)camera:(Camera*)camera captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection;
@end



NS_ASSUME_NONNULL_END

//
//  CircularProgressView.m
//  LPoint
//
//  Created by MP02006 on 2021/01/04.
//  Copyright © 2021 MP02031. All rights reserved.
//

#import "CircularProgressView.h"


@interface CircularProgressView()
//@property(nonatomic,strong) CAShapeLayer *valueMaskLayer;
@property(nonatomic,strong) CAShapeLayer *valueLayer;
@property(nonatomic,strong) CAShapeLayer *bgLayer;
@property(nonatomic,strong) CAShapeLayer *circleLayer;

@property(nonatomic,strong) UIBezierPath *valuePath;
@property(nonatomic,strong) UIBezierPath *bgPath;

 
@end



@implementation CircularProgressView
- (void)dealloc {
     
}

- (void)initial {
    _maxValue = 30;
    self.transform = CGAffineTransformRotate(CGAffineTransformIdentity, [self degreesToRadians:270]);
    
    
    _bgLayer = [[CAShapeLayer alloc]init];
    [self.layer addSublayer:_bgLayer];
    
    
    _valueLayer = [[CAShapeLayer alloc]init];

    _valueLayer.strokeColor = [UIColor rgbColorWithRed:0 green:155 blue:250 alpha:1].CGColor;
    _valueLayer.fillColor = [UIColor clearColor].CGColor;
    _valueLayer.lineCap = kCALineCapRound;
    
    [self.layer addSublayer:_valueLayer];
    
    _bgLayer.strokeColor = [UIColor rgbColorWithRed:193 green:231 blue:255 alpha:1].CGColor;
    _bgLayer.fillColor = [UIColor clearColor].CGColor;
    
    _valuePath = [[UIBezierPath alloc]init];
    _bgPath = [[UIBezierPath alloc]init];
    
    
    
//        [self.layer setCornerRadius:60];
//        [self.layer setBorderWidth:_borderWidth];
//        [self.layer setMasksToBounds:YES];
//        if (_borderColor) {
//            [self.layer setBorderColor: _borderColor.CGColor];
//        }
//    }
}

- (void)didLoad {
    _valueLayer.frame = self.bounds;
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
}

- (void)layoutSubviews {
     _valueLayer.frame = self.bounds;
//
    _bgLayer.frame =   self.bounds;
    [_valuePath removeAllPoints];

    CGFloat lineWidth  = 10;
    CGFloat radius = (MIN(self.bounds.size.height, self.bounds.size.width) /2);// - (lineWidth / 2);

    CGFloat degrees = (360.f / _maxValue) * _maxValue;
    CGFloat dendAngle = [self degreesToRadians:degrees];
     
    
    [_bgPath addArcWithCenter:CGPointMake(55, 55)
                       radius:radius
                   startAngle:[self startAngle]
                     endAngle:dendAngle
                    clockwise:YES];
    [_bgPath closePath];
    
    _bgLayer.path = _bgPath.CGPath;
    _bgLayer.lineWidth = 5;
    
    
    
    [_valuePath addArcWithCenter:CGPointMake(55, 55)
                          radius:radius
                      startAngle:[self startAngle]
                        endAngle:[self endAngle]
                       clockwise:YES];

    _valueLayer.path = _valuePath.CGPath;
    _valueLayer.lineWidth = lineWidth;
    
    

    [_valuePath closePath];
    
    
}
- (void)setValue:(CGFloat)value {
    _value = value;
    [self setNeedsLayout];
}

- (CGFloat)degreesToRadians:(CGFloat)degrees {
    return degrees * (M_PI/180);
}

- (CGFloat)startAngle{
    return [self degreesToRadians:0];
}

- (CGFloat)endAngle{
    CGFloat degrees = (360.f / _maxValue) * _value;
    return [self degreesToRadians:degrees];
}


@end

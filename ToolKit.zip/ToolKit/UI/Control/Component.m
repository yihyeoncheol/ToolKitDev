//
//  Component.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "Component.h"



@implementation Component

- (void)dealloc {
    
//    NSArray *keys = @[@"style"];
//
//    for (NSString *key in keys) {
//        [self removeObserver:self forKeyPath:key];
//    }
    
    _style = nil;
    _name = nil;
    _layoutChanged = nil;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self didLoad];
}

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self){
        [self initial];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self){
        [self initial];
    }
    return self;
}

- (void)initial{
#if (TARGET_IPHONE_SIMULATOR)
//    [self roundWithRadius:0.f width:.5f color:[UIColor blackColor]];
#endif
    
//    NSArray *keys = @[@"style"];
//
//    for (NSString *key in keys) {
//        [self addObserver:self forKeyPath:key options:NSKeyValueObservingOptionNew context:nil];
//    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    
    if ([keyPath isEqualToString:@"style"]) {
        SEL selector = NSSelectorFromString(_style);
        if([self respondsToSelector:selector]){
            IMP imp = [self methodForSelector:selector];
            void (*func)(id, SEL) = (void *)imp;
            func(self, selector);
        }
    }
}

- (void)setNeedsStyle {
    if (_style) {
        SEL selector = NSSelectorFromString(_style);
        if([self respondsToSelector:selector]){
            IMP imp = [self methodForSelector:selector];
            void (*func)(id, SEL) = (void *)imp;
            func(self, selector);
        }
    }
    
    [self update];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (_layoutChanged) {
        _layoutChanged(self);
    }
}

- (void)viewWillRotate:(id<UIViewControllerTransitionCoordinatorContext>) context{
#if 0
    NSTimeInterval animationDuration = [context transitionDuration];
    UIViewAnimationCurve animationCurve = [context completionCurve];
    //
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    [UIView setAnimationBeginsFromCurrentState:YES];
     // run
    [UIView commitAnimations];
    
#endif
}

- (void)didLoad {
}
@end

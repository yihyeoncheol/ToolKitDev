//
//  ViewController.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "StoryboardSegue.h"
#import "ViewModel.h"
#import "NavigationBar.h"
NS_ASSUME_NONNULL_BEGIN
@class Button;
@class Component;
@class TabBarItem;
//https://developer.apple.com/swift/blog/?id=25

@class Message;
@class Cookie;
@class Session;                          
//@class TabBarItem;

@interface ViewController : UIViewController
//{
//    BOOL _present;
//}

@property (weak, nonatomic) IBOutlet NavigationBar *navigationBar;
@property (weak, nonatomic) IBOutlet UIView *accessoryView;


//@property (weak, nonatomic) IBOutlet UIScrollView *contentView;
@property(nonnull,nonatomic,strong)ViewModel *viewModel;
@property(nonnull,nonatomic,readonly)ViewController *parent;
//@property(nonatomic)BOOL isPresent;
@property(nonatomic)CGFloat offset;
@property(nonatomic,readonly)BOOL menuEnabled;
@property(nonatomic,strong)IBInspectable UIColor *statusViewColor;
- (void)enter:(nullable Message*)message;
- (void)exit;

- (void)refresh;
- (void)update:(nullable Message*)message;
- (void)pause;


- (CAAnimation*)disappearAnimation;
- (CAAnimation*)appearAnimation;

- (IBAction)buttonTouchUpInside:(nonnull Button*)button;
- (IBAction)componentValueChanged:(nonnull Component*)component;
- (IBAction)componentTouchUpInside:(nonnull Component*)component;

- (IBAction)unwindExit:(UIStoryboardSegue*)storyboardSegue;

- (void)performSegueWithIdentifier:(nonnull NSString *)identifier type:(SegueType)type message:(nullable Message*)message;
//- (void)toRevertWithIdentifier:(NSString*)identifier message:(nullable Message*)message;
@end


@interface ViewController (TabBarViewController)

- (TabBarItem*)item;

@end
NS_ASSUME_NONNULL_END

//
//  TabBarViewController.m
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/09.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "TabBarViewController.h"

#import "UIViewController+Extension.h"


@interface TabBarViewController ()

@property(nullable, strong, nonatomic)  UIView *contentView;

//@property(nonatomic) CGRect contentRect;
@end

@implementation TabBarViewController

- (void)dealloc {
    if(self.isViewLoaded){
        NSArray *keys = @[
            @"viewControllers"
        ];
        for (NSString *key in keys) {
            [self removeObserver:self forKeyPath:key];
        }
    }
    
    _tabBar = nil;
}

- (void)loadView  {
    [super loadView];
    _contentEdgeInsets = UIEdgeInsetsZero;
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _tabBarHeight = 44.0f;
    _tabBar = [self createTabBar];
    [self.view addSubview:_tabBar];
    UIEdgeInsets safeAreaInsets = [UIApplication sharedApplication].rootController.safeAreaInsets;
    _tabBar.contentEdgeInsets = UIEdgeInsetsMake(0, 0, safeAreaInsets.bottom, 0);
    [_tabBar addTarget:self action:@selector(valueChanged:) forControlEvents:UIControlEventValueChanged];
    
    NSArray *keys = @[
        @"viewControllers"
    ];

    for (NSString *key in keys) {
        [self addObserver:self forKeyPath:key options:NSKeyValueObservingOptionNew context:nil];
    }
    _tabBar.useAccessoryView = YES;
}

- (void)viewWillLayoutSubviews {
    
    [super viewWillLayoutSubviews];
 
    CGRect slice;
    CGRect remainder;
    
    UIEdgeInsets safeAreaInsets = [UIApplication sharedApplication].rootController.safeAreaInsets;
    CGRectDivide(self.view.bounds, &slice, &remainder, _tabBarHeight + safeAreaInsets.bottom, CGRectMaxYEdge);
        
    _tabBar.frame = slice;
    
    if (_selectedViewController){
        CGRect viewBounds = UIEdgeInsetsInsetRect(self.view.bounds, UIEdgeInsetsMake(0, 0, safeAreaInsets.bottom + _tabBarHeight, 0));
        _selectedViewController.view.frame = UIEdgeInsetsInsetRect(viewBounds, _contentEdgeInsets);
    }
}
- (TabBar *)createTabBar{
    return [[TabBar alloc] initWithFrame:CGRectZero];
}

- (void)setSelectedIndex:(NSInteger)selectedIndex {
    self.tabBar.selectedIndex = selectedIndex;
    _selectedIndex = selectedIndex;
}

- (void)enter:(Message *)message {
    if (_selectedViewController) {
        [_selectedViewController enter:message];
    }
}
- (void)refresh {
    if (_selectedViewController) {
        [_selectedViewController refresh];
    }
}
- (void)update:(Message *)message {
    if (_selectedViewController) {
        [_selectedViewController update:message];
    }
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object  change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"viewControllers"]) {
        [self print];
    }
}

- (ViewController*)loadViewControllerWithStoryboard:(UIStoryboard*)storyboard identifier:(NSString*)identifier {
    return [storyboard instantiateViewControllerWithIdentifier:identifier];
}

- (void)valueChanged:(TabBar*)tabBar {
    if (_selectedIndex == tabBar.selectedIndex){
    }else{
        _selectedIndex = tabBar.selectedIndex;
        [self update];
    }
}

- (void)print {
    NSMutableArray *items = [NSMutableArray array];
    
    for (ViewController *vc in _viewControllers) {
        [items addObject:[vc item]];
    }
    
    _tabBar.items = items;
    
    [self update];
}

- (void)update {
    
    if (_selectedViewController) {
        [_selectedViewController pause];
        [_selectedViewController willMoveToParentViewController:nil];
        [_selectedViewController removeFromParentViewController];
        [_selectedViewController.view removeFromSuperview];
        
        _selectedViewController = nil;
    }
    
    if (_viewControllers.count > 0) {
        ViewController *vc = _viewControllers[_selectedIndex];
        
        CGRect slice;
        CGRect remainder;
        UIEdgeInsets safeAreaInsets = [UIApplication sharedApplication].rootController.safeAreaInsets;
        CGRect viewBounds = UIEdgeInsetsInsetRect(self.view.bounds, UIEdgeInsetsMake(0, 0, safeAreaInsets.bottom + _tabBarHeight, 0));
        
        CGRectDivide(viewBounds, &slice, &remainder, 0, CGRectMaxYEdge);
        vc.view.frame = UIEdgeInsetsInsetRect(remainder, _contentEdgeInsets);
        
//        [self.view addSubview:vc.view];
        [self.view insertSubview:vc.view atIndex:0];
        
        [self addChildViewController:vc];
        [vc didMoveToParentViewController:self];
        [vc enter:nil];
        self.selectedViewController = vc;
        
        
    }
}

@end




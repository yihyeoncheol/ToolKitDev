//
//  ChildViewController.h
//  LPoint
//
//  Created by MP02031 on 2020/10/12.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN
@protocol ChildMessageDelegate;

@interface ChildViewController : ViewController

@property(nonatomic,weak) id<ChildMessageDelegate> delegate;

- (void)setData:(id)data;
@end

@protocol ChildMessageDelegate <NSObject>
- (void)child:(ChildViewController*)child message:(Message*)message;
@end


NS_ASSUME_NONNULL_END

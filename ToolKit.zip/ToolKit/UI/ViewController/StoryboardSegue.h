//
//  StoryboardSegue.h
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/03.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Message;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, SegueType) {
    SegueOpen        = 0,    // default
    SeguePush        = 1,    //
    SeguePresent     = 2,    //
    SeguePop         = 3,    //
    SeguePopToRoot   = 4,    //
    SegueDismiss     = 5,    //
    SegueNone        = 6     //
};

@interface SegueOption : NSObject
@property(nonatomic) SegueType type;
@property(nullable, nonatomic, strong) Message *message;
//@property(nonatomic) BOOL animated;

+ (instancetype)optionWithType:(SegueType)type message:(nullable Message *)message;
@end

@interface StoryboardSegue : UIStoryboardSegue
@property(nullable, nonatomic, strong) SegueOption *option;
@end

NS_ASSUME_NONNULL_END

//
//  StoryboardSegue.m
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/03.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "StoryboardSegue.h"
#import "RootController.h"

@implementation SegueOption
+ (instancetype)optionWithType:(SegueType)type message:(Message *)message {
    SegueOption *option = [SegueOption new];
    option.type = type;
    option.message = message;
    return option;
}
@end
    
//https://dolfalf.tistory.com/104
//https://yb-ios-dev.tistory.com/1
#if 0
UIView.transition(from: <출발 뷰>,
to : <목적지 뷰>,
,duration: <화면 전환 시 소요시간>,
options: <애니메이션 전환 옵션>,
completion: <화면 전환 후 실행할 구문>)
#endif

@implementation StoryboardSegue

- (void)dealloc {
    NSLog(@"dealloc");
}
- (void)perform {
    NSLog(@"%@",self.identifier);
    SegueType type = self.option.type;
    switch (type) {
        case SegueOpen:
            [self open];
            break;
        case SeguePush:
            [self push];
            break;
        case SeguePresent:
            [self present];
            break;
        case SeguePop:
            [self pop];
            break;
        case SeguePopToRoot:
            [self popToRoot];
            break;
        case SegueDismiss:
            [self dismiss];
            break;
        default:
            [super perform];
            break;
    }
}

- (void)push {
//    ViewController *sourceViewController = (ViewController*)self.sourceViewController;
    ViewController *destinationViewController = (ViewController*)self.destinationViewController;
    RootController *rvctl = (RootController*)UIApplication.sharedApplication.keyWindow.rootViewController;
    CAAnimation *animation = destinationViewController.appearAnimation;
    
    ViewController *topViewController = (ViewController*) [rvctl navigation].topViewController;
    [topViewController pause];
    
    BOOL ani = YES;
    if(animation){
        [[rvctl navigation].view.layer addAnimation:animation forKey:nil];
        ani = NO;
    }
    [[rvctl navigation] pushViewController:destinationViewController animated:ani completion:^{
        [destinationViewController enter:self.option.message];
    }];
}

- (void)open {
//    ViewController *sourceViewController = (ViewController*)self.sourceViewController;
    ViewController *destinationViewController = (ViewController*)self.destinationViewController;
    RootController *rvctl = (RootController*)UIApplication.sharedApplication.keyWindow.rootViewController;
    
    CAAnimation *animation = destinationViewController.appearAnimation;
    BOOL ani = YES;
    if(animation){
        [[rvctl navigation].view.layer addAnimation:animation forKey:nil];
        ani = NO;
    }
    
    [[rvctl navigation] setViewControllers:@[destinationViewController] animated:ani completion:^{
        [destinationViewController enter:self.option.message];
    }];
}

- (void)present {
    
    ViewController *destinationViewController = (ViewController*)self.destinationViewController;
    //    ViewController *sourceViewController = (ViewController*)self.sourceViewController;
    destinationViewController.providesPresentationContextTransitionStyle = YES;
    destinationViewController.definesPresentationContext = YES;
    destinationViewController.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    
    RootController *rtc = (RootController*)UIApplication.sharedApplication.keyWindow.rootViewController;
    
    CAAnimation *animation = destinationViewController.appearAnimation;
    BOOL ani = YES;
    if(animation){
        ani = NO;
    }
    
    ViewController *topViewController = (ViewController*) [rtc navigation].topViewController;
    [topViewController pause];
    
    [[rtc navigation] presentViewController:destinationViewController
                                   animated:ani
                                 completion:^{
        if(ani == NO){
            [destinationViewController.view.layer addAnimation:animation forKey:nil];
        }
        
        [destinationViewController enter:self.option.message];
    }];
}

- (void)dismiss {
    ViewController *sourceViewController = (ViewController*)self.sourceViewController;
//    ViewController *destinationViewController = (ViewController*)self.destinationViewController;
    RootController *rtc = (RootController*)UIApplication.sharedApplication.keyWindow.rootViewController;
    ViewController *topViewController = (ViewController*) [rtc navigation].topViewController;

    [sourceViewController dismissViewControllerAnimated:NO completion:^{
        
        if (topViewController.statusViewColor){
            [UIApplication sharedApplication].rootController.statusView.backgroundColor = topViewController.statusViewColor;
        }
        
        
        [sourceViewController exit];
        [topViewController update:self.option.message];
        
    }];
}

- (void)pop {
    RootController *rtc = (RootController*)UIApplication.sharedApplication.keyWindow.rootViewController;
    ViewController *sourceViewController = (ViewController*)self.sourceViewController;
//    ViewController *destinationViewController = (ViewController*)self.destinationViewController;
    
     
    
    BOOL ani = YES;
    CAAnimation *animation = sourceViewController.disappearAnimation;
    if(animation){
        [[rtc navigation].view.layer addAnimation:animation forKey:nil];
        ani = NO;
    }
    ViewController *vc = (ViewController*)[[rtc navigation] popViewControllerAnimated:ani completion:^{
        ViewController *topViewController = (ViewController*)[rtc navigation].topViewController;
        [topViewController update:self.option.message];
    }];
    
    [vc exit];
}

- (void)popToRoot {
    RootController *rtc = (RootController*)UIApplication.sharedApplication.keyWindow.rootViewController;
    NSArray *vcs = [[rtc navigation] popToRootViewControllerAnimated:NO];
    
    for (ViewController *vc in vcs) {
        [vc exit];
    }
    ViewController *vc = [rtc navigation].viewControllers.firstObject;
    [vc update:self.option.message];
}

@end

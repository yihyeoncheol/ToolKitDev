//
//  RootController.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "RootController.h"
#import "NavigationController.h"
#import "AlertLayerView.h"
#import "SecurityTextField.h"

#import "ComponentLayerView.h"
NSString *const RootControllerTouchEventNotification = @"RootControllerTouchEventNotification";
@interface RootController () <UIGestureRecognizerDelegate> {
    NavigationController *_navigationController;
}
    
@property(nonatomic,strong)UITouch *tapGestureShouldReceiveTouch;
@property(nonatomic)BOOL statusBarHidden;

@end

@implementation RootController

- (void)dealloc {
    _statusView = nil;
//    _modal = nil;
    _alertLayerView = nil;
    _topLayerView = nil;
    _componentLayerView = nil;
    _linkData = nil;
    _push = nil;
    _navigationController = nil;
    _tapGestureShouldReceiveTouch = nil;
    _cookie = nil;
//    _session = nil;
    _encryptCookie = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)loadView {
    [super loadView];

    _cookie = [[Cookie alloc]init];
//    _session = [[Session alloc]init];
    _encryptCookie = [[EncryptCookie alloc]init];
    
}

- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"LaunchScreen" bundle:nil];
    UIViewController *fakeController = [sb instantiateInitialViewController];
    
    NavigationController *navigationController = [[NavigationController alloc]initWithRootViewController:fakeController];
    navigationController.view.frame = UIEdgeInsetsInsetRect(self.view.bounds, UIEdgeInsetsMake(0, 0, 0, 0));
//        navigationController.view.frame = UIEdgeInsetsInsetRect(self.view.bounds, UIEdgeInsetsZero);
    [self.view addSubview:navigationController.view];
    [self addChildViewController:navigationController];
    [navigationController didMoveToParentViewController:self];
    _navigationController = navigationController;
    

    
    _statusView = [[UIView alloc]init];
    _statusView.backgroundColor = [UIColor whiteColor];
    _statusView.frame = CGRectMake(0, 0, self.view.bounds.size.width, self.safeAreaInsets.top);
    [self.view addSubview:_statusView];
    
    
    _componentLayerView = [[ComponentLayerView alloc] init];
    [self.view addSubview:_componentLayerView];
    
    _alertLayerView = [[AlertLayerView alloc] init];
    [self.view addSubview:_alertLayerView];
    
    _topLayerView = [[LayerView alloc] init];
    [self.view addSubview:_topLayerView];
    
    
    _statusBarHidden = NO;
    UITapGestureRecognizer *singleTapRecognizer = [UITapGestureRecognizer new];
    [singleTapRecognizer setDelegate:self];
    singleTapRecognizer.numberOfTapsRequired = 1;
    singleTapRecognizer.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:singleTapRecognizer];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didBecomeActive:)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(willResignActive:)
//                                                 name:UIApplicationWillResignActiveNotification
//                                               object:nil];

    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(willEnterForeground:)
                                                 name: UIApplicationWillEnterForegroundNotification
                                               object: nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(didEnterBackground:)
                                                 name: UIApplicationDidEnterBackgroundNotification
                                               object: nil];
    
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(didEnterTerminate:)
                                                 name: UIApplicationWillTerminateNotification
                                               object: nil];
    
    //applicationWillTerminate
    
    
    
}


- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    _statusView.frame                   = CGRectMake(0, 0, self.view.bounds.size.width, self.safeAreaInsets.top);
    _navigationController.view.frame    = UIEdgeInsetsInsetRect(self.view.bounds, UIEdgeInsetsMake(0, 0, 0, 0));
    _alertLayerView.frame               = self.view.bounds;
    _topLayerView.frame                 = self.view.bounds;
    _componentLayerView.frame           = self.view.bounds;
}

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event{
    UIViewController *vc = [self navigation].viewControllers.firstObject;
    if (vc) {
        [vc motionEnded:motion withEvent:event];
    }
}

- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    return UIStatusBarAnimationFade;
}

- (void)setStatusBarHidden:(BOOL)hidden animated:(BOOL)animated {
    _statusBarHidden = hidden;
#if 0
    if (animated){
           [UIView beginAnimations:@"statusBarHiddenAnimation" context:nil];
    }
    [self setNeedsStatusBarAppearanceUpdate];
               
    if (animated) {
        [UIView commitAnimations];
       }
#endif
    [UIView animateWithDuration:.3f animations:^{
        [self setNeedsStatusBarAppearanceUpdate];
    }];
}

- (BOOL)prefersStatusBarHidden {
    return _statusBarHidden;
}

- (NavigationController*)navigation {
    return _navigationController;
}

- (void)setInitalViewController:(ViewController*) viewController {
    [_navigationController setViewController:viewController message:nil];
}


#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if (gestureRecognizer.state == UIGestureRecognizerStatePossible) {
        [[NSNotificationCenter defaultCenter] postNotificationName:RootControllerTouchEventNotification object:touch];
    }
    return YES;
}

#pragma mark - UIApplicationNotification

-(void) didEnterTerminate:(NSNotification *)notification {
    [UIApplication.sharedApplication updateAllMissionNotification];
}
- (void)willEnterForeground:(NSNotification *)notification {
    
}

- (void)didBecomeActive:(NSNotification *)notification {
    if (_screenSaver) {
        if(self.screenSaver.superview){

            [UIView animateWithDuration:.3f animations:^{
                self.screenSaver.alpha = 0;
            } completion:^(BOOL finished) {
                [self.screenSaver removeFromSuperview];
//                self.screenSaver.alpha = 1;
            }];
        }
    }
}


- (void)didEnterBackground:(NSNotification *)notification {
    if (_screenSaver) {
        _screenSaver.alpha = 1;
        _screenSaver.frame = self.view.bounds;
        [self.view addSubview:_screenSaver];
        
        [self.view endEditing:YES];
        [UIApplication.sharedApplication updateAllMissionNotification];

//        [UIView animateWithDuration:.3f animations:^{
//            self.screenSaver.alpha = 1;
//        } completion:^(BOOL finished) {
//        }];
    }
}

- (void)willResignActive:(NSNotification *)notification {
    
    if (_screenSaver) {
        _screenSaver.alpha = 0;
        _screenSaver.frame = self.view.bounds;
        [self.view addSubview:_screenSaver];
        
        [self.view endEditing:YES];

        [UIView animateWithDuration:.3f animations:^{
            self.screenSaver.alpha = 1;
        } completion:^(BOOL finished) {
        }];
    }
}
@end

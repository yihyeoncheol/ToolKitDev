//
//  ChildViewController.m
//  LPoint
//
//  Created by MP02031 on 2020/10/12.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "ChildViewController.h"

@interface ChildViewController ()

@end

@implementation ChildViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}


- (void)setData:(id)data {
    
}


@end

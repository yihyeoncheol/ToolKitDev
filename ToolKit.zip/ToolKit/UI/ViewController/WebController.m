//
//  WebController.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "WebController.h"
#import "ActivityIndicator.h"



@implementation ProcessPool

+ (ProcessPool *)singletone {
    static ProcessPool * obj = nil;
    if (obj == nil) {
        @synchronized(self) {
            if (obj == nil) {
                obj = [[self alloc] init];
            }
        }
    }
    return obj;
}

@end


@interface WebController() <WKNavigationDelegate,WKUIDelegate,WKScriptMessageHandler>

@end

@implementation WebController


- (void)viewDidLoad {
    
    [super viewDidLoad];
    _contentEdgeInsets = UIEdgeInsetsZero;
    WKUserContentController *userContentController = [WKUserContentController new];
    if (@available(iOS 11.0, *)) {
    }else{
        NSArray *cookies = NSHTTPCookieStorage.sharedHTTPCookieStorage.cookies;
        NSString *source = [self getJSCookiesString:cookies];
        WKUserScript *userScript = [[WKUserScript alloc]initWithSource:source injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:NO];
        [userContentController addUserScript:userScript];
    }
    
    WKWebViewConfiguration *webConfiguration = [WKWebViewConfiguration new];
    webConfiguration.userContentController = userContentController;
    webConfiguration.processPool = [ProcessPool singletone];
    
//    CGRect viewBounds = UIEdgeInsetsInsetRect(self.view.bounds, self.safeAreaInsets);
    
    _webView = [[WKWebView alloc]initWithFrame:UIEdgeInsetsInsetRect(self.view.bounds, _contentEdgeInsets) configuration:webConfiguration];
    _webView.scrollView.bounces = NO;
    _webView.allowsLinkPreview = NO;
    _webView.UIDelegate = self;
    _webView.navigationDelegate = self;
//    self.view = webView;
    
    [self.view addSubview:_webView];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
//    CGRect viewBounds = UIEdgeInsetsInsetRect(self.view.bounds, self.safeAreaInsets);
    _webView.frame = UIEdgeInsetsInsetRect(self.view.bounds, _contentEdgeInsets);
}

- (NSString*)getJSCookiesString:(NSArray<NSHTTPCookie*>*)cookies {
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    dateFormatter.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    dateFormatter.dateFormat = @"EEE, d MMM yyyy HH:mm:ss zzz";
    
    NSMutableString *result = [NSMutableString string];
    
    for( NSHTTPCookie *cookie in cookies) {
        [result appendFormat:@"document.cookie='%@=%@; domain=%@; path=%@; ",cookie.name,cookie.value,cookie.domain,cookie.path];
        NSDate *expiresDate = cookie.expiresDate;
        if (expiresDate) {
            NSString *sDate = [dateFormatter stringFromDate:expiresDate];
            [result appendFormat:@"expires=%@; ",sDate];
        }
        if (cookie.isSecure) {
            [result appendString:@"secure; "];
        }
        [result appendString:@"'; "];
    }
    
    return result;
}


- (void)setUserAgent {
    [_webView evaluateJavaScript:@"navigator.userAgent" completionHandler:^(id __nullable appName, NSError * __nullable error) {
            NSLog(@"%@", appName);
            // Netscape
        
        self.webView.customUserAgent = @"LTAPPWEB";
    }];
   

   // NSLog(@"userAgent: %@", userAgent);

}

- (void)addScriptNames:(NSArray<NSString*>*)names {
    WKUserContentController *userContentController = _webView.configuration.userContentController;
    for (NSString *name in  names) {
        [userContentController addScriptMessageHandler:self name:name];
    }
}
    
- (void)loadRequest:(NSMutableURLRequest *)request{
        
    NSString *jsString = [NSString stringWithFormat:@"document.querySelector('meta[name=viewport]').setAttribute('content', 'viewport-fit=cover, width=%d;', false); ", (int)_webView.frame.size.width];
    
    [self evaluateJavaScript:jsString completionHandler:^(id data, NSError * _Nonnull error) {
        
    }];

    // 웹뷰에서 셀릭션 막기
    [self evaluateJavaScript:@"document.documentElement.style.webkitUserSelect='none'" completionHandler:^(id data, NSError * _Nonnull error) {
        
    }];
    
    // 웹뷰에서 셀력션 콜 막기
    [self evaluateJavaScript:@"document.documentElement.style.webkitTouchCallout='none'" completionHandler:^(id data, NSError * _Nonnull error) {
        
    }];
    
    NSHTTPCookieStorage *cookieStorage =  [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSDictionary *headers = [NSHTTPCookie requestHeaderFieldsWithCookies:cookieStorage.cookies];
    for (NSString *key in headers.allKeys){
        [request addValue:headers[key] forHTTPHeaderField:key];
    }
    
    [_webView loadRequest:request];
}

- (void)loadHTMLString:(NSString *)string baseURL:(NSURL*)baseURL {
    [_webView loadHTMLString:string baseURL:baseURL];
}

- (void)loadData:(NSData *)data MIMEType:(NSString *)MIMEType textEncodingName:(NSString *)textEncodingName baseURL:(NSURL *)baseURL {
    [_webView loadData:data MIMEType:MIMEType characterEncodingName:textEncodingName baseURL:baseURL];
}

- (void)goBack {
    [_webView goBack];
}

- (void)goForward {
    [_webView goForward];
}

- (void)stopLoading {
    [_webView stopLoading];
}

- (void)reload {
    [_webView reload];
}

- (void)callBack:(NSString*)name value:(NSString*)value {
//    let javaScript = funcName + "('" + value + "')"
//    self.webView.evaluateJavaScript(javaScript) { (result, error) in
//    }
}

- (void)evaluateJavaScript:(NSString *)javaScriptString completionHandler:(void (^ )( id, NSError *  error))completionHandler {
    [_webView evaluateJavaScript:javaScriptString completionHandler:completionHandler];
}

- (BOOL)commend:(id)message {
#if 0
    NSString *cmd = @"sampleCommend";
    NSString *param = @"sampleParam";
    NSString *callback = @"sampleCallback";
    NSString *sel = [NSString stringWithFormat:@"%@:callback:",cmd];
    SEL selector = NSSelectorFromString(sel);
    if([self respondsToSelector:selector]){
        IMP imp = [self methodForSelector:selector];
        BOOL (*func)(id, SEL, NSString *,NSString *) = (void*)imp;
        return func(self, selector,param,callback);
    }
#endif
    return NO;
}

- (void)parser {
}

#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    [self commend:message];
}

#pragma mark - WKWebView WKNavigationDelegate
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    [ActivityIndicator start];
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    [ActivityIndicator stop];
    
    
    
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    [ActivityIndicator stop];
}


- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(nonnull NSError *)error {
    [ActivityIndicator stop];
}


- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    BOOL result = YES;
    WKNavigationActionPolicy actionPolicy = result ? WKNavigationActionPolicyAllow : WKNavigationActionPolicyCancel;
   
    NSHTTPCookieStorage *cookieSto = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    [cookieSto setCookieAcceptPolicy:NSHTTPCookieAcceptPolicyAlways];
    NSString *URLString =  navigationAction.request.URL.absoluteString;
    
    NSLog("decidePolicyForNavigationAction URLString %@", URLString);
    if (@available(iOS 11.0, *)) {
        NSHTTPCookieStorage *cookieStorage =  [NSHTTPCookieStorage sharedHTTPCookieStorage];
        for (id cookie in cookieStorage.cookies){
            [webView.configuration.websiteDataStore.httpCookieStore setCookie:cookie completionHandler:nil];
        }
    }
    
    
    
    //NSLog(@"userAgent : %@", [webView stringByEvaluatingJavaScriptFromString:@"navigator.userAgent"]);
#ifndef DEV
//    if (![SsoAppLibrary url:[navigationAction.request URL] webView:webView window:self]){
//        
//        NSLog("NOOOO %@", URLString);
//        decisionHandler(WKNavigationActionPolicyCancel);
//        return;
//    }
#endif
    decisionHandler(actionPolicy);
}




@end

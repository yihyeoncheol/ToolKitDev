//
//  RootViewController.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "Session.h"
#import "Cookie.h"
#import "NavigationController.h"
#import "EncryptCookie.h"

@class LinkData;
@class AlertLayerView;
@class Push;
@class LayerView;
@class ComponentLayerView;
NS_ASSUME_NONNULL_BEGIN

UIKIT_EXTERN NSString *const RootControllerTouchEventNotification;

@interface RootController : ViewController
//@property(nonatomic,readonly)LayerView *popupLayer;
@property(nonatomic,strong)AlertLayerView *alertLayerView;
@property(nonatomic,strong)LayerView *topLayerView;
@property(nonatomic,strong)ComponentLayerView *componentLayerView;
//@property(nonatomic,strong)UIViewController *modal;

//@property(nonatomic,strong)Session *session;
@property(nonatomic,strong)Cookie *cookie;
@property(nonatomic,strong)EncryptCookie *encryptCookie;
@property(nonatomic,strong)UIView *statusView;

@property(nullable, nonatomic, strong) LinkData *linkData;
@property(nullable, nonatomic, strong) Push *push;

@property(nullable, nonatomic, strong)UIView *screenSaver;

//@property(nonatomic,readonly)Panel *topView;
- (NavigationController*)navigation;
- (void)setInitalViewController:(ViewController*) viewController;
- (void)setStatusBarHidden:(BOOL)hidden animated:(BOOL)animated;
@end

NS_ASSUME_NONNULL_END

//
//  ViewController.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "ViewController.h"
#import "NavigationBar.h"


@interface ViewController ()<UIGestureRecognizerDelegate>
@property(nonatomic,strong)SegueOption *option;
@end
//@synthesize isPresent = _present;
@implementation ViewController

- (void)dealloc {
    _option = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.interactivePopGestureRecognizer.delegate = self;
    
    if (_navigationBar) {
        _navigationBar.title = self.title;
        _navigationBar.backgroundColor = self.view.backgroundColor;
    }
}

- (void)setTitle:(NSString *)title {
    [super setTitle:title];
    
    if (_navigationBar) {
        _navigationBar.title = title;
    }
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if (_navigationBar) {
        _navigationBar.backgroundColor = self.view.backgroundColor;
    }
    
    if (_statusViewColor){
        [UIApplication sharedApplication].rootController.statusView.backgroundColor = _statusViewColor;
    }
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
}

- (void)setStatusViewColor:(UIColor *)statusViewColor {
    if (statusViewColor){
        [UIApplication sharedApplication].rootController.statusView.backgroundColor = statusViewColor;
    }
    _statusViewColor = statusViewColor;
}

- (BOOL)menuEnabled{
    return NO;
}


- (void)enter:(Message*)message {}
- (void)exit {}
- (void)refresh {}
- (void)update:(Message *)message {}
- (void)pause {}


- (IBAction)buttonTouchUpInside:(Button*)button {}
- (IBAction)componentValueChanged:(Component*)component {}
- (IBAction)componentTouchUpInside:(Component*)component {}
- (IBAction)unwindExit:(UIStoryboardSegue*)storyboardSegue {
//    NSLog(@"unwindExit");
}

- (TabBarItem*)item {
    return nil;
}

- (CAAnimation *)disappearAnimation {
        return nil;
    #if 0
        CATransition* transition = [CATransition animation];
        transition.duration = .3f;
        transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionFade;//kCATransitionFromTop;//kCATransitionFade; //kCATransitionMoveIn; //, kCATransitionPush, kCATransitionReveal, kCATransitionFade
        //transition.subtype = kCATransitionFromTop; //kCATransitionFromLeft, kCATransitionFromRight, kCATransitionFromTop, kCATransitionFromBottom
        return transition;
    #endif

}

- (CAAnimation *)appearAnimation{
        return nil;
    #if 0
        CATransition* transition = [CATransition animation];
        transition.duration = .3f;
        transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        transition.type = kCATransitionFade;//kCATransitionFromTop;//kCATransitionFade; //kCATransitionMoveIn; //, kCATransitionPush, kCATransitionReveal, kCATransitionFade
        //transition.subtype = kCATransitionFromTop; //kCATransitionFromLeft, kCATransitionFromRight, kCATransitionFromTop, kCATransitionFromBottom
        return transition;
    #endif
}

- (ViewController*)parent {
    return (ViewController*)self.parentViewController;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue isKindOfClass:[StoryboardSegue class]]) {
        StoryboardSegue *s = (StoryboardSegue*)segue;
        s.option = self.option;
    }
    [super prepareForSegue:segue sender:sender];
}

//- (void)toRevertWithIdentifier:(NSString*)identifier message:(Message*)message {
//    SegueType t = self.isPresent ? SeguePresent : SeguePop;
//    [self performSegueWithIdentifier:identifier type:t message:message];
//}

- (void)unwindForSegue:(UIStoryboardSegue *)unwindSegue towardsViewController:(UIViewController *)subsequentVC {
    [super unwindForSegue:unwindSegue towardsViewController:subsequentVC];
}

- (void)performSegueWithIdentifier:(NSString *)identifier type:(SegueType)type message:(Message*)message {
    self.option = [SegueOption optionWithType:type message:message];
    [super performSegueWithIdentifier:identifier sender:self];
}

#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return NO;
}
@end


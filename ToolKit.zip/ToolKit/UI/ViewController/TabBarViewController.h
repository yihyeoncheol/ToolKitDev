//
//  TabBarViewController.h
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/09.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "ViewController.h"
#import "TabBar.h"
NS_ASSUME_NONNULL_BEGIN



@interface TabBarViewController : ViewController
@property(strong, nonatomic) TabBar *tabBar;
@property(nonatomic)IBInspectable CGFloat tabBarHeight;
@property(nonatomic,strong)ViewController *selectedViewController;

@property(nonatomic,strong) NSArray<TabBarItem*> *items;
@property(nonatomic)IBInspectable NSInteger selectedIndex;
@property(nonatomic,strong)NSArray<ViewController*> *viewControllers;
@property(nonatomic)UIEdgeInsets contentEdgeInsets;

- (TabBar *)createTabBar;

- (ViewController*)loadViewControllerWithStoryboard:(UIStoryboard*)storyboard identifier:(NSString*)identifier;
@end




NS_ASSUME_NONNULL_END

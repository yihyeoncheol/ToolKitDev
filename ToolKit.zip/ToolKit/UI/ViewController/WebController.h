//
//  WebController.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/08/29.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProcessPool : WKProcessPool

@end

@interface WebController : ViewController
@property(nonatomic,strong)WKWebView *webView;

@property(nonatomic)UIEdgeInsets contentEdgeInsets;

- (void)loadRequest:(NSMutableURLRequest *)request;
- (void)loadHTMLString:(NSString *)string baseURL:(NSURL*)baseURL;
- (void)loadData:(NSData *)data MIMEType:(NSString *)MIMEType textEncodingName:(NSString *)textEncodingName baseURL:(NSURL *)baseURL;
- (void)goBack;
- (void)goForward;
- (void)stopLoading;
- (void)reload;
- (void)evaluateJavaScript:(NSString *)javaScriptString completionHandler:(void (^ )( id, NSError *  error))completionHandler;
- (void)addScriptNames:(NSArray<NSString*>*)names;
- (BOOL)commend:(WKScriptMessage*)message;
@end

NS_ASSUME_NONNULL_END

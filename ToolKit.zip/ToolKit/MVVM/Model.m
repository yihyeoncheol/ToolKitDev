//
//  Model.m
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/04.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "Model.h"
#import <objc/runtime.h>
@implementation Model

+ (id)parser:(id)data{
    return nil;
}

- (instancetype)initWithData:(id)data {
    self = [super init];
    if (self) {
        NSMutableArray *propertyKeys = [NSMutableArray array];
        Class currentClass = self.class;

        while ([currentClass superclass]) { // avoid printing NSObject's attributes
            unsigned int outCount, i;
            objc_property_t *properties = class_copyPropertyList(currentClass, &outCount);
            for (i = 0; i < outCount; i++) {
                objc_property_t property = properties[i];
                const char *propName = property_getName(property);
                if (propName) {
                    NSString *propertyName = [NSString stringWithUTF8String:propName];
                    [propertyKeys addObject:propertyName];
                }
            }
            free(properties);
            currentClass = [currentClass superclass];
        }
        
        NSDictionary *jsonData = (NSDictionary*)data;
        for (NSString *key in propertyKeys) {
            if  ([[jsonData allKeys] containsObject:key]) {
                
                id value = [jsonData valueForKey:key];
                if([value isKindOfClass:[NSArray class]]||
                   [value isKindOfClass:[NSDictionary class]]){
                    
                }else{
                    [self setValue:value forKey:key];
                }
            }
        }
    }
    return self;
}
@end

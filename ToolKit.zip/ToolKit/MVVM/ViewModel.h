//
//  ViewModel.h
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/04.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "APIManager.h"

NS_ASSUME_NONNULL_BEGIN
@protocol ViewModelDelegate;

@interface ViewModel : NSObject
@property(nonatomic)BOOL indicator;
@property(nonatomic,weak)id<ViewModelDelegate> delegate;
@property(nullable, nonatomic,strong)Message *command;
@property(nullable, nonatomic,strong)Message *message;
@property(nullable, nonatomic,strong)Message *error;

- (void)initial ;
- (void)exceute:(Message*)message;
- (void)requestCompleted:(NSHTTPURLResponse*)response data:(NSData*)data;
- (void)requestFailWithError:(NSError*)error;
- (void)receiveWithResponse:(NSHTTPURLResponse*)response data:(id)data;
- (void)failWithError:(NSHTTPURLResponse *)response errorMessage:(NSString*) errorMessage;
- (void)requestWithURL:(NSString*)url method:(HTTPMethod)httpMethod query:(nullable NSDictionary<NSString *, NSString *>*)query  header:(NSDictionary<NSString *, NSString *>*)header ;
- (void)requestWithURL:(NSString*)url method:(HTTPMethod)httpMethod body:(NSData*)body header:(NSDictionary<NSString *, NSString *>*)header ;

@end

@protocol ViewModelDelegate <NSObject>
- (void)valueDidChanged:(Message*)message;
- (void)viewModelError:(Message*)message;
@end

NS_ASSUME_NONNULL_END

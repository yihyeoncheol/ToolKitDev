//
//  ViewModel.m
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/04.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "ViewModel.h"
#import "Alert.h"
#import "ErrorModel.h"

@interface ViewModel()

@end

@implementation ViewModel

- (void)dealloc {
    NSArray *keys = @[
        @"command",
        @"message",
        @"error"
    ];
    
    for (NSString *key in keys) {
        [self removeObserver:self forKeyPath:key];
    }
    _command = nil;
    _message = nil;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        NSArray *keys = @[
            @"command",
            @"message",
            @"error"
        ];
        
        self.indicator = YES;
        for (NSString *key in keys) {
            [self addObserver:self forKeyPath:key options:NSKeyValueObservingOptionNew context:nil];
        }
        [self initial];
    }
    return self;
}
- (void)initial {
}
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object  change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"command"]) {
        Message *command = change[NSKeyValueChangeNewKey];
        if (command){
            [self exceute:command];
        }
    }else if ([keyPath isEqualToString:@"message"]) {
        if ([_delegate respondsToSelector:@selector(valueDidChanged:)]) {
            [_delegate valueDidChanged:_message];
        }
    }else if ([keyPath isEqualToString:@"error"]) {
        if ([_delegate respondsToSelector:@selector(viewModelError:)]) {
            [_delegate viewModelError:_error];
        }
    }
}

- (void)exceute:(Message*)message {}

- (void)requestCompleted:(NSHTTPURLResponse*)response data:(NSData*)data {
}


- (void)receiveWithResponse:(NSHTTPURLResponse*)response data:(id)data {
    
}

- (void)requestFailWithError:(NSError*)error {
    [Alert alertWithTitle:nil
                  message:error.localizedDescription
                     type:AlertTypeDefault
        cancelButtonTitle:nil
         otherButtonTitle:@"확인"
                  handler:nil];
}

- (void)requestWithURL:(NSString*)url method:(HTTPMethod)httpMethod query:(nullable NSDictionary<NSString *, NSString *>*)query  header:(NSDictionary<NSString *, NSString *>*)header {
    if (self.indicator) {
        [ActivityIndicator start];
    }
//    DECLARE_WEAK_SELF(weakself);
    [APIManager url:url method:httpMethod headerFields:header query:query completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if (self.indicator) {
                [ActivityIndicator stop];
            }
            
            NSHTTPURLResponse *urlResponse = (NSHTTPURLResponse*)response;
            NSInteger statusCode = urlResponse.statusCode;
            
            if (error){
                [self failWithError:urlResponse errorMessage:error.localizedDescription];
                return;
            }
            
            //#if (TARGET_IPHONE_SIMULATOR)
            NSString *sData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"%@",sData);
            //#endif

            switch (statusCode) {
                case 200: {
                    [self requestCompleted:urlResponse data:data];
                }
                break;
                default: {
                    NSString *message = [NSHTTPURLResponse localizedStringForStatusCode:statusCode];
                    message = [message stringByAppendingFormat:@"[%ld]",(long)statusCode];
                    [self failWithError:urlResponse errorMessage:error.localizedDescription];
                }
                break;
            }
            
        });
    }];
}

- (void)requestWithURL:(NSString*)url method:(HTTPMethod)httpMethod body:(NSData*)body header:(NSDictionary<NSString *, NSString *>*)header {
    
    if (self.indicator) {
        [ActivityIndicator start];
    }
    
//    DECLARE_WEAK_SELF(weakself);
    [APIManager url:url method:httpMethod headerFields:header body:body completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (self.indicator) {
                [ActivityIndicator stop];
            }
            NSHTTPURLResponse *urlResponse = (NSHTTPURLResponse*)response;
            NSInteger statusCode = urlResponse.statusCode;
            if (error){
                [self failWithError:urlResponse errorMessage:error.localizedDescription];
                return;
            }
            #if (TARGET_IPHONE_SIMULATOR)
            NSString *sData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSLog(@"%@",sData);
            #endif
            switch (statusCode) {
                case 200: {
                    [self receiveWithResponse:urlResponse data:data];
                }
                break;
                default: {
                    NSString *message = [NSHTTPURLResponse localizedStringForStatusCode:statusCode];
                    message = [message stringByAppendingFormat:@"[%ld]",(long)statusCode];
                  
                    [self failWithError:urlResponse errorMessage:message];
                }
                break;
            }
        });
    }];
}

- (void)failWithError:(NSHTTPURLResponse *)response errorMessage:(NSString*) errorMessage {
     
    if([response.URL.path isEqualToString:@"/app/login/LALA100301.do"] || [response.URL.path isEqualToString:@"/app/login/LALA100302.do"]){ // 동적 바코드 오류 인 경우
           
            NSDictionary *Status = @{
                @"code" : @(-1),
                @"msgCode" : @"500",
                @"message" : @"통신 오류로 고정바코드로 표출 됩니다."
            };
        
            NSDictionary *jsonData = @{
                @"Status" : Status
            };
        
            NSError *error;
        
            NSData *dataFromDict = [NSJSONSerialization dataWithJSONObject:jsonData
                                                                   options:NSJSONWritingPrettyPrinted
                                                                     error:&error];
        
            [self requestCompleted:response data:dataFromDict];
            
    } else {
        [Alert alertWithTitle:nil
                      message:errorMessage
                         type:AlertTypeDefault
            cancelButtonTitle:nil
             otherButtonTitle:@"확인"
                      handler:nil];
    }
    

    
   
}




@end

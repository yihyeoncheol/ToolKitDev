//
//  Model.h
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/04.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface Model : NSObject

+ (id)parser:(id)data;

- (instancetype)initWithData:(id)data;


@end

NS_ASSUME_NONNULL_END

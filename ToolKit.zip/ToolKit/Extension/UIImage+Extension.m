//
//  UIImage+Extension.m
//  MMCamScanner
//
//  Created by mukesh mandora on 09/06/15.
//  Copyright (c) 2015. All rights reserved.
//

#import "UIImage+Extension.h"


typedef struct _RGBAPixel {
    UInt8 red;
    UInt8 green;
    UInt8 blue;
    UInt8 alpha;
} RGBAPixel;


#define RGBAPixelIsBlack(pixel) (pixel.red == 0 && pixel.green == 0 && pixel.blue == 0 && pixel.alpha == 255 ? YES : NO)
#define PRINT_RGBAPixel(pixel)  // TRACE(@"%d %d %d %d", pixel.red, pixel.green, pixel.blue, pixel.alpha)

@implementation UIImage (Extension)

- (UIImage *)fixOrientation {
    return [UIImage imageWithCGImage:self.CGImage scale: 1.0f orientation: UIImageOrientationRight];
}

+ (UIImage*)renderImage:(NSString *)imagName {
    return [[UIImage imageNamed:imagName] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
}

+ (UIImage*)createImageFromUIColor:(UIColor*)color {
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(contextRef, [color CGColor]);
    CGContextFillRect(contextRef, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return  img;
}

#if 0
UIImageView 를 사용하기 위해서는 UIImage 를 이용하여 ImageView를 생성해야 합니다. 우리는 일반적으로 이미지를 불러오기 위해 [UIImage ImageNamed:@""] 함수를 사용하게 됩니다.

위의 ImageNamed 함수는 Image를 메모리에 Cache합니다. 미리 캐시된 이미지를 사용하기 때문에 동일한 이미지를 불러오는 시간이 매우 단축됩니다. 하지만 한번 캐시된 이미지는 이미지뷰를 Release 한다고 해도 메모리에서 해제되지 않습니다. 때문에 서로 다른 여러개의 이미지를 읽어올 경우 많은 메모리가 사용되는 것을 볼 수 있습니다.


이 문제(?)는 ImageNamed함수가 아닌 다른 함수를 사용하여 해결할 수 있습니다.

NSString *path = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"main_000"] ofType:@"png"];
UIImage *image = [[UIImage alloc] initWithContentsOfFile:path];
UIImageView *img_Chapter = [[UIImageView alloc] initWithImage:image];

[image release];
image = nil;

#endif
/*
+ (UIImage*)imageFileNamed:(NSString *)name
{
    return [[ResourceManager sharedManager] getUIImage:name imageOfSize:CGSizeZero];;
}

+ (UIImage*)ninePatchedImage:(NSString *)name size:(CGSize)size
{
    return [[ResourceManager sharedManager] getUIImage:name imageOfSize:size];;
}
*/
/*
+(UIImage*)ninePatchedImage:(UIImage*)kOriginalImg Offset:(float)kOffset{
    CGSize kSize = kOriginalImg.size;
    return  [kOriginalImg resizableImageWithCapInsets:UIEdgeInsetsMake(aOffset, aOffset, kSize.height-aOffset, kSize.width-aOffset)];
}
*/

- (UIImage *)crop:(CGRect)rect {
    
    rect = CGRectMake(rect.origin.x * self.scale,
                      rect.origin.y * self.scale,
                      rect.size.width * self.scale,
                      rect.size.height * self.scale);
    
    CGImageRef imageRef = CGImageCreateWithImageInRect([self CGImage], rect);
    UIImage *result = [UIImage imageWithCGImage:imageRef
                                          scale:self.scale
                                    orientation:self.imageOrientation];
    CGImageRelease(imageRef);
    return result;
}

@end


@implementation UIImage (UIImageExtension)

static NSMutableDictionary *__imageSessions;

+ (NSMutableDictionary *)_imageSessions {
    if (__imageSessions == nil) {
        __imageSessions = [[NSMutableDictionary alloc] init];
    }
    return __imageSessions;
}

+ (NSMutableDictionary *)_sessionForKey:(NSString *)key {
    NSMutableDictionary *data = [self _imageSessions];
    
    NSMutableDictionary *session = [data objectForKey:key];
    if (session == nil){
        session = [NSMutableDictionary dictionary];
        [data setObject:session forKey:key];
    }
    return session;
}

+ (UIImage*)_findImageWithName:(NSString *)name {
    NSArray *sessionKeys = [__imageSessions allKeys];
    UIImage *image = nil;
    
    for (int i = 0; i < [sessionKeys count] && image == nil; i++){
        NSMutableDictionary *session = [__imageSessions objectForKey:[sessionKeys objectAtIndex:i]];
        image = [session objectForKey:name];
    }
    
    return image;
}

+ (UIImage *)imageNamed:(NSString *)name forSession:(id)session {
    NSString *key = [NSString stringWithFormat:@"%p",session];
    
    NSMutableDictionary *sessionContainer = [self _sessionForKey:key];
    UIImage *image = [sessionContainer objectForKey:name];
    
    if (image != nil){
        return image;
    }else{
        image = [self _findImageWithName:name]; //다른곳에 등록된 이미지를 찾는다
        
        if (image == nil){
            NSString *path = [[NSBundle mainBundle] pathForResource:name ofType:nil];
            if (path != nil){
                image = [UIImage imageWithContentsOfFile:path];
            }
        }
        
        if (image != nil){
            [sessionContainer setObject:image forKey:name];
        }
    }
    return image;
}

+ (void)clearSession:(id)session {
    if (session == nil){
        return;
    }
    NSString *key = [NSString stringWithFormat:@"%p",session];
    [__imageSessions removeObjectForKey:key];
}

@end


@implementation UIImage (Resize)

+ (UIImage *)imageWithImage:(UIImage *)image scaledToMaxWidth:(CGFloat)width maxHeight:(CGFloat)height {
    CGFloat oldWidth = image.size.width;
    CGFloat oldHeight = image.size.height;
    
    CGFloat scaleFactor = (oldWidth > oldHeight) ? width / oldWidth : height / oldHeight;
    
    CGFloat newHeight = oldHeight * scaleFactor;
    CGFloat newWidth = oldWidth * scaleFactor;
    CGSize newSize = CGSizeMake(newWidth, newHeight);
    
    return [image scaleToSize:newSize];// [self imageWithImage:image scaledToSize:newSize];
}

- (UIImage *)scaleToSize:(CGSize)size {
    UIGraphicsBeginImageContext(size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    CGContextDrawImage(context, CGRectMake(0.0f, 0.0f, size.width, size.height), self.CGImage);
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return scaledImage;
}

- (UIImage *)cropToRect:(CGRect)rect {
    rect = CGRectMake(rect.origin.x*self.scale,
                      rect.origin.y*self.scale,
                      rect.size.width*self.scale,
                      rect.size.height*self.scale);
    
    CGImageRef imageRef = CGImageCreateWithImageInRect([self CGImage], rect);
    UIImage *result = [UIImage imageWithCGImage:imageRef
                                          scale:self.scale
                                    orientation:self.imageOrientation];
    CGImageRelease(imageRef);
    
    return result;
}

- (UIImage *)resizeWithCapInsets {
    CGSize size = self.size;
    int top = size.height/2-2;
    int left = size.width/2-2;
    UIEdgeInsets insets = UIEdgeInsetsMake(top, left, top, left);
    return [self resizeWithCapInsets:insets];
}

- (UIImage *)resizeWithCapInsets:(UIEdgeInsets)insets {
    CGSize size = self.size;
    NSLog(@" image size = %@", NSStringFromCGSize(size));
    UIImage *result = [self resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeTile];
    return result;
}




- (UIImage*)imageWithColorOverlay:(UIColor*)colorOverlay {
    // create drawing context
    UIGraphicsBeginImageContextWithOptions(self.size, NO, self.scale);
    
    // draw current image
    [self drawAtPoint:CGPointZero];
    
    // determine bounding box of current image
    CGRect rect = CGRectMake(0, 0, self.size.width, self.size.height);
    
    // get drawing context
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // flip orientation
    CGContextTranslateCTM(context, 0.0, self.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    // set overlay
    CGContextSetBlendMode(context, kCGBlendModeOverlay);
    CGContextClipToMask(context, rect, self.CGImage);
    CGContextSetFillColorWithColor(context, colorOverlay.CGColor);
    CGContextFillRect(context, rect);
    
    // save drawing-buffer
    UIImage *returnImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // end drawing context
    UIGraphicsEndImageContext();
    
    return returnImage;
}

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size {
    UIGraphicsBeginImageContext(size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextFillRect(context, (CGRect){.size = size});
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

+ (UIImage *)imageWithColor:(UIColor *)color {
    return [UIImage imageWithColor:color size:CGSizeMake(1, 1)];
}
@end

#if 0
//http://theeye.pe.kr/archives/2278
@implementation UIImage (Bundle)


+ (NSBundle *)frameworkBundle {
    static NSBundle* frameworkBundle = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        NSString* mainBundlePath = [[NSBundle mainBundle] resourcePath];
        NSString* frameworkBundlePath = [mainBundlePath stringByAppendingPathComponent:@"Resource.bundle"];
        frameworkBundle = [NSBundle bundleWithPath:frameworkBundlePath];
    });
    return frameworkBundle;
}

+ (UIImage*)imageNamed:(NSString*)imageName bundle:(NSBundle*)bundle {
    
    // Extract base name and extension
    NSString* imageBaseName = [imageName stringByDeletingPathExtension];
    NSString* imageExt = [imageName pathExtension];
    if (!imageExt.length) imageExt = @"png";
    
    NSString* imagePath = nil;
    
    // Try retina version if available
    BOOL isRetina = ([[UIScreen mainScreen] scale] == 2.0);
    if (isRetina)
    {
        NSString* retinaImageBaseName = [NSString stringWithFormat:@"%@@2x", imageBaseName];
        imagePath = [bundle pathForResource:retinaImageBaseName ofType:imageExt];
    }
    
    // If not a Retina screen or retina image not found, try regular image
    if (!imagePath)
    {
        imagePath = [bundle pathForResource:imageBaseName ofType:imageExt];
        isRetina = NO;
    }
    
    // Build the image
    UIImage* image = [UIImage imageWithContentsOfFile:imagePath];
    // If retina version, set the scale appropriately
    if (isRetina)
    {
        image = [UIImage imageWithCGImage:image.CGImage scale:2.0 orientation:UIImageOrientationUp];
    }
    
    return image;
    /* ios 8
     NSBundle *frameworkBundle = [NSBundle bundleForClass:[self class]];
     return [UIImage imageNamed:@"golf" inBundle:frameworkBundle compatibleWithTraitCollection:nil];
     */

//    return image;
}

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size {
    UIGraphicsBeginImageContext(size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextFillRect(context, (CGRect){.size = size});
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

+ (UIImage *)imageWithColor:(UIColor *)color {
    return [UIImage imageWithColor:color size:CGSizeMake(1, 1)];
}

@end
#endif







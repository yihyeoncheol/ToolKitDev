//
//  NSString+Extension.m
//  LPoint
//
//  Created by MP02031 on 2020/09/18.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "NSString+Extension.h"
#import <CommonCrypto/CommonDigest.h>

@implementation NSString (Extension)

+ (NSString*)readfile:(NSString*)fileName {
    NSArray *separated =  [fileName componentsSeparatedByString:@"."];
    NSString *fn = separated[0];
    NSString *fe = separated[1];
    NSError *error;
    NSURL *documentDirURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory
                                                                   inDomain:NSUserDomainMask
                                                          appropriateForURL:nil
                                                                     create:NO
                                                                      error:&error];
    if (error){
        return nil;
    }
    
    NSURL *fileURL = [[documentDirURL URLByAppendingPathComponent:fn] URLByAppendingPathExtension:fe];
 
    NSString *data = [NSString stringWithContentsOfURL:fileURL encoding:NSUTF8StringEncoding error:&error];
    
    return data;
}

//static func fromFile( _ fileName: String) -> String? {
//    let separated = fileName.components(separatedBy:".")
//    let fn = separated[0]
//    let fe = separated[1]
//
//    let documentDirURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
//    let fileURL = documentDirURL.appendingPathComponent(fn).appendingPathExtension(fe)
//    do {
//        let data = try String(contentsOf: fileURL, encoding: .utf8)
//        return data
//    }
//    catch {
//        print("failed with error: \(error)")
//    }
//    return nil
//}



- (NSDate*)stringToDateWithFormat:(NSString*)format {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:format];
    NSDate *ret  = [dateFormatter dateFromString:self];
    return ret;
}

- (NSString*)stringToDateWithDateFormat:(NSString*)format{
//    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//    [dateFormatter setDateFormat:format];
//
//    NSDate *date  = [dateFormatter dateFromString:self];
//
//    NSString *string = [dateFormatter stringFromDate:date];
//
//    return string;
    
    NSDate *dateTemp = [[NSDate alloc] init];

    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];

    [dateFormat setDateStyle: NSDateFormatterShortStyle];

    dateTemp = [dateFormat dateFromString: self];

    [dateFormat setDateFormat:format];

    NSString *date = [dateFormat stringFromDate:dateTemp];
    
    return date;
    
}

- (NSDictionary <NSString*,NSString*> *)fromQuery {
    NSMutableDictionary *pDic = [NSMutableDictionary dictionary];
    
    NSString *query = [self stringByRemovingPercentEncoding];
    NSArray *pairs = [query componentsSeparatedByString:@"&"];
    
    for (NSString* sObj in pairs) {
        NSArray* elements = [sObj componentsSeparatedByString:@"="];
        if (elements.count > 1) {
            NSString* key   = [elements objectAtIndex:0];
            NSString* value = [sObj stringByReplacingOccurrencesOfString:[key stringByAppendingString:@"="] withString:@""];
            [pDic setObject:value forKey:key];
        }
    }
    return pDic;
}


- (NSString*)phoneNumbertoAsteriskPhoneNumber {
    
    NSString *asteriskTel = @"";
    
    if(self.length == 11) {
        NSString *tel1 = [self substringToIndex:3];   // 010
    
        NSString *tel2 = [self substringFromIndex:3]; // 중간 자리
        NSString *tel3 = [tel2 substringFromIndex:4];        // 마지막 자리
    
        tel2 = [tel2 substringToIndex:2];
        tel2 = [NSString stringWithFormat:@"%@**",tel2];
    
        tel3 = [tel3 substringToIndex:2];        // 마지막 자리
        tel3 = [NSString stringWithFormat:@"%@**",tel3];
    
        asteriskTel = [NSString stringWithFormat:@"%@-%@-%@", tel1, tel2, tel3];
    }
    else {
        NSString *tel1 = [self substringToIndex:3];   // 010
    
        NSString *tel2 = [self substringFromIndex:3]; // 중간 자리
        NSString *tel3 = [tel2 substringFromIndex:3];        // 마지막 자리
    
        tel2 = [tel2 substringToIndex:1];
        tel2 = [NSString stringWithFormat:@"%@**",tel2];
    
        tel3 = [tel3 substringToIndex:2];        // 마지막 자리
        tel3 = [NSString stringWithFormat:@"%@**",tel3];
    
        asteriskTel = [NSString stringWithFormat:@"%@-%@-%@", tel1, tel2, tel3];
    }
    
    return asteriskTel;
}

- (BOOL)specialCharactersCehck {
    if([self length] == 0){
        return YES;
    }
    
    NSString * regex = nil;
    regex = @"^[ㄱ-힣0-9a-zA-Z]*$";
    NSRange r = [self rangeOfString:regex options:NSRegularExpressionSearch];

    if(r.length == 0) {
        return NO;
    }
    return YES;
}
-(NSString *)decimalStyle {
    NSNumber *decimal = [NSNumber numberWithInteger:[self integerValue]];
    NSString *decimalStr = [NSNumberFormatter localizedStringFromNumber:decimal numberStyle:NSNumberFormatterDecimalStyle];
    
    return decimalStr;
}


- (NSString*) decimal {
    return [self decimal:-1];
}

-(NSString*) decimal:(int)minimum {
    NSNumberFormatter *fmt = [[NSNumberFormatter alloc] init];
    [fmt setNumberStyle:NSNumberFormatterDecimalStyle];
    [fmt setRoundingMode:NSNumberFormatterRoundDown];
    
    
    
    [fmt setGroupingSeparator:@","];
    [fmt setGroupingSize:3];
    
    [fmt setDecimalSeparator:@"."];
    
    

//    if(minimum > 0)
    {
        [fmt setMinimumFractionDigits:minimum];
        [fmt setMaximumFractionDigits:minimum];
    }
    
    NSString *textData = [fmt stringFromNumber:[NSNumber numberWithDouble:[self doubleValue]]];
    
    return textData;
}

- (NSString *)trim {
    return [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (BOOL)isNullOrEmpty {
    return (self == nil || [self trim].length < 1);
}
- (NSString *)NVL2 {
    if( self == nil || [self trim].length < 1 ) {
        return @"";
    }
    
    return self;
}


/*
 * Contains : 문자열에 비교할 문자열이 포함되있는지 반환.
 */
- (BOOL)contains:(NSString *)str {
    return [self rangeOfString:str].location != NSNotFound;
}


- (NSString*) decodeUTF8 {
    if (self != nil && [self isKindOfClass:[NSString class]]) {
        NSString *encodeStr = [self stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        if (encodeStr) {
            return encodeStr;
        } else {
            return self;
        }
    }
    
    return @"";
}


- (NSString *)encodeToPercentEscapeString {
    return (NSString *)
    CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,
                                                              (CFStringRef) self,
                                                              NULL,
                                                              (CFStringRef) @"!*'();:@&=+$,/?%#[]",
                                                              kCFStringEncodingUTF8));
}


/**
 * method decodeFromPercentEscapeString
 * brief Decode a percent escape encoded string.
 * param src URL
 * return URL Encoding된 값
 */
+ (NSString *)decodeFromPercentEscapeString:(NSString *)string
{
    return (NSString *)
    CFBridgingRelease(CFURLCreateStringByReplacingPercentEscapesUsingEncoding(NULL,
                                                                              (CFStringRef) string,
                                                                              CFSTR(""),
                                                                              kCFStringEncodingUTF8));
}

#pragma mark -
#pragma mark 컴마처리 및 수숫점 처리 Remove '-'
-(NSString *) decimalRemoveSubtraction {
    return [self decimalRemoveSubtraction:-1];
}

-(NSString *) decimalRemoveSubtraction:(int)minimum {
    NSNumberFormatter *fmt = [[NSNumberFormatter alloc] init];
    [fmt setNumberStyle:NSNumberFormatterDecimalStyle];
    if(minimum>=0){
        [fmt setMinimumFractionDigits:minimum];
        [fmt setMaximumFractionDigits:minimum];
    }
    double dValue = [self doubleValue] < 0 ?  [self doubleValue] * -1 : [self doubleValue];
    NSString *textData = [fmt stringFromNumber:[NSNumber numberWithDouble:dValue]];
    
    return textData;
}

#pragma mark -
#pragma mark "0" => Space
- (NSString *) zeroToSpace {
    if ([self isEqualToString:@"0"] || [self isEqualToString:@"0.00"]) return @"";
    return self;
}

- (NSString *)removeMinus {
    return [self stringByReplacingOccurrencesOfString:@"-" withString:@""];
}

- (NSString *) removeComma {
    return [self stringByReplacingOccurrencesOfString:@"," withString:@""];
}

- (CGFloat)heightForString:(NSString *)fontName fontsize:(CGFloat) fontsize maxWidth:(CGFloat)maxWidth {
    if (![self isKindOfClass:[NSString class]] || !self.length) {
        // no text means no height
        return 0;
    }
    
    UIFont *font = [UIFont fontWithName:fontName size: fontsize];
    
    NSStringDrawingOptions options = NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading;
    NSDictionary *attributes = @{ NSFontAttributeName : font };
    CGSize size = [self boundingRectWithSize:CGSizeMake(maxWidth, CGFLOAT_MAX) options:options attributes:attributes context:nil].size;
    CGFloat height = ceilf(size.height) + 1; // add 1 point as padding
    
    return height;
}

- (NSString*) sha512HashFor {
    NSData* dataInput = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSData* dataHash = [dataInput SHA512Hash];
    
    NSMutableString* output = [[NSMutableString alloc] init];
    
    char *cstr = (char *)[dataHash bytes];
    
    for(int i = 0; i < CC_SHA512_DIGEST_LENGTH; i++){
        [output appendString:[[NSString stringWithFormat:@"%x", (cstr[i] & 0xff) + 0x100] substringFromIndex:1]];
    }
    
    return output;
}

- (NSString *)make22String:(int)count hipenGapSpace:(BOOL)gapSpace whiteSpace:(BOOL)whiteSpace {
    NSString *hipenStr;
    
    NSMutableString *muStr = [[NSMutableString alloc] init];
    
    for (int i = 0; i < [self length]; i++) {
        
        NSRange aRange = NSMakeRange(i,1);
        
        if( (i > 0) && (i % count) == 0 && i < 17)
        {
            if (gapSpace && !whiteSpace) [muStr appendString:@" "];
            [muStr appendString:@" "];
            if (gapSpace || whiteSpace) [muStr appendString:@" "];
            [muStr appendString:[self substringWithRange:aRange]];
            if (whiteSpace) [muStr appendString:@" "];
        }
        else if( i < [self length] - 1)
        {
            [muStr appendString:[self substringWithRange:aRange]];
            if (whiteSpace) [muStr appendString:@" "];
        }
        else
        {
            [muStr appendString:[self substringWithRange:aRange]];
        }
        
    }
    
    hipenStr = [NSString stringWithFormat:@"%@", muStr];
    
    return hipenStr;
}
- (NSString *) exceptFamilyName{
    if(self.length < 3) {
        // 외자
        return [self substringFromIndex:self.length - 1];
        
    } else {
        NSArray *twoCharacterFamilyNames = @[@"남궁", @"황보", @"선우", @"독고", @"제갈", @"동방", @"사공", @"서문", @"어금", @"소봉", @"망절", @"장곡", @"강전", @"고전", @"길강", @"길성", @"흑치"];
        
        NSString *twoString = [self substringWithRange:NSMakeRange(0, 2)];
        for(NSString *twoFamilyName in twoCharacterFamilyNames) {
            if([twoString isEqualToString:twoFamilyName]) {
                NSString *exceptFamilyName = [self substringWithRange:NSMakeRange(twoString.length, self.length - twoString.length)];
                return exceptFamilyName;
            }
        }
        
        // 복성 해당사항 아닌 경우
        return [self substringWithRange:NSMakeRange(1, self.length - 1)];
    }
    return self;
}
@end

//
//  UIImageView+Extension.m
//  LPoint
//
//  Created by MP02031 on 2020/10/14.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "UIImageView+Extension.h"

@implementation UIImageView (Extension)

- (void)qr:(NSData*)data {
    
    CIFilter *qrFilter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    [qrFilter setValue:data forKey:@"inputMessage"];
    [qrFilter setValue:@"H" forKey:@"inputCorrectionLevel"];
              
    CIImage *ciImage = qrFilter.outputImage;
    
    if (ciImage) {
        CGFloat scaleX = self.bounds.size.width  / ciImage.extent.size.width;
//        CGFloat scaleY = self.bounds.size.height  / ciImage.extent.size.height;
        
        CGAffineTransform qrTransform = CGAffineTransformMakeScale(scaleX, scaleX);
        CIImage *outputImage = [qrFilter.outputImage imageByApplyingTransform:qrTransform];
        CIContext *context = [CIContext contextWithOptions:nil];
        
        CGImageRef cgImage = [context createCGImage:outputImage fromRect:outputImage.extent];
        if (cgImage) {
            self.image = [UIImage imageWithCGImage:cgImage];
        }
    }
}

- (void)barcode:(NSData*)data {
    
    CIFilter *qrFilter = [CIFilter filterWithName:@"CICode128BarcodeGenerator"];
    [qrFilter setValue:data forKey:@"inputMessage"];
//    [qrFilter setValue:@"H" forKey:@"inputCorrectionLevel"];
              
    CIImage *ciImage = qrFilter.outputImage;
    
    if (ciImage) {
        CGFloat scaleX = self.bounds.size.width  / ciImage.extent.size.width;
        CGFloat scaleY = self.bounds.size.height  / ciImage.extent.size.height;
        
        CGAffineTransform qrTransform = CGAffineTransformMakeScale(scaleX, scaleY);
        CIImage *outputImage = [qrFilter.outputImage imageByApplyingTransform:qrTransform];
        CIContext *context = [CIContext contextWithOptions:nil];
        
        CGImageRef cgImage = [context createCGImage:outputImage fromRect:outputImage.extent];
        if (cgImage) {
            self.image = [UIImage imageWithCGImage:cgImage];
        }
    }
}
- (void)fromUrl:(NSString*) sUrl rotateAngle:(CGFloat)angle{
    NSURL *url = [NSURL URLWithString:sUrl];
    if (url) {
        NSURLCache *cache = NSURLCache.sharedURLCache;
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSData *data = [cache cachedResponseForRequest:request].data;
            UIImage *image = [UIImage imageWithData:data];
            if (image) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    if([image size].width > [image size].height){
                        // 이미지 회전
                        CGAffineTransform t = CGAffineTransformMakeRotation(angle);
                        CGRect sizeRect = (CGRect){.size = image.size};
                        CGRect destRect = CGRectApplyAffineTransform(sizeRect, t);
                        CGSize destSize = destRect.size;
                        
                        UIGraphicsBeginImageContext(destSize);
                        CGContextRef context = UIGraphicsGetCurrentContext();
                        CGContextTranslateCTM(context, destSize.width/2., destSize.height/2.);
                        CGContextRotateCTM(context, angle);
                        [image drawInRect:CGRectMake(- image.size.width/2., - image.size.height/2., image.size.width, image.size.height)];
                        
                        UIImage *rotationImage = UIGraphicsGetImageFromCurrentImageContext();
                        
                        self.image = rotationImage;
                    } else {
                        self.image = image;
                    }
                });
            }else {
                [[[NSURLSession sharedSession] dataTaskWithRequest:request
                                                 completionHandler:^(NSData * _Nullable data,
                                                                     NSURLResponse * _Nullable response,
                                                                     NSError * _Nullable error) {
                    
                    if(data){
                        NSCachedURLResponse *cachedData = [[NSCachedURLResponse alloc]initWithResponse:response data:data];
                        [cache storeCachedResponse:cachedData forRequest:request];
                        UIImage *image = [UIImage imageWithData:data];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            
                            if([image size].width > [image size].height){
                                // 이미지 회전
                                CGAffineTransform t = CGAffineTransformMakeRotation(angle);
                                CGRect sizeRect = (CGRect){.size = image.size};
                                CGRect destRect = CGRectApplyAffineTransform(sizeRect, t);
                                CGSize destSize = destRect.size;
                                
                                UIGraphicsBeginImageContext(destSize);
                                CGContextRef context = UIGraphicsGetCurrentContext();
                                CGContextTranslateCTM(context, destSize.width/2., destSize.height/2.);
                                CGContextRotateCTM(context, angle);
                                [image drawInRect:CGRectMake(- image.size.width/2., - image.size.height/2., image.size.width, image.size.height)];
                                
                                UIImage *rotationImage = UIGraphicsGetImageFromCurrentImageContext();
                                
                                self.image = rotationImage;
                            } else {
                                self.image = image;
                            }
                        });
                    }
                    
                }] resume];
            }
        });
    }
}

//- (void) fromUrl:(NSString*) sUrl rotateAngle:(CGFloat)angle{
//
//    NSURL *url = [NSURL URLWithString:sUrl];
//    if (url) {
//        NSURLCache *cache = NSURLCache.sharedURLCache;
//        NSURLRequest *request = [NSURLRequest requestWithURL:url];
//
//        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//            NSData *data = [cache cachedResponseForRequest:request].data;
//            UIImage *image = [UIImage imageWithData:data];
//            if (image) {
//                dispatch_async(dispatch_get_main_queue(), ^{
//
//                    CGAffineTransform t = CGAffineTransformMakeRotation(angle);
//
//
//                    self.image = image;
//                });
//            }else {
//                [[[NSURLSession sharedSession] dataTaskWithRequest:request
//                                                 completionHandler:^(NSData * _Nullable data,
//                                                                     NSURLResponse * _Nullable response,
//                                                                     NSError * _Nullable error) {
//
//                    if(data){
//                        NSCachedURLResponse *cachedData = [[NSCachedURLResponse alloc]initWithResponse:response data:data];
//                        [cache storeCachedResponse:cachedData forRequest:request];
//                        UIImage *image = [UIImage imageWithData:data];
//                        dispatch_async(dispatch_get_main_queue(), ^{
//                            self.image = image;
//                        });
//                    }
//
//                }] resume];
//            }
//        });
//    }
//
//    //            // 이미지 회전
//    //            CGAffineTransform t = CGAffineTransformMakeRotation(M_PI_2);
//    //            CGRect sizeRect = (CGRect){.size = _cardImageView.image.size};
//    //            CGRect destRect = CGRectApplyAffineTransform(sizeRect, t);
//    //            CGSize destSize = destRect.size;
//    //
//    //            UIGraphicsBeginImageContext(destSize);
//    //            CGContextRef context = UIGraphicsGetCurrentContext();
//    //            CGContextTranslateCTM(context, destSize.width/2., destSize.height/2.);
//    //            CGContextRotateCTM(context, M_PI_2);
//    //            _cardImageView.image = UIGraphicsGetImageFromCurrentImageContext();
//}


- (void) fromUrl:(NSString*) sUrl defaultImage:(UIImage*)defaultImage {
    
    self.image = defaultImage;
    
    NSURL *url = [NSURL URLWithString:sUrl];
    if (url) {
        NSURLCache *cache = NSURLCache.sharedURLCache;
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSData *data = [cache cachedResponseForRequest:request].data;
            UIImage *image = [UIImage imageWithData:data];
            if (image) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.image = image;
                });
            }else {
                [[[NSURLSession sharedSession] dataTaskWithRequest:request
                                                 completionHandler:^(NSData * _Nullable data,
                                                                     NSURLResponse * _Nullable response,
                                                                     NSError * _Nullable error) {
                    
                    if(data){
                        UIImage *image = [UIImage imageWithData:data];
                        if (image){
                            NSCachedURLResponse *cachedData = [[NSCachedURLResponse alloc]initWithResponse:response data:data];
                            [cache storeCachedResponse:cachedData forRequest:request];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                self.image = image;
                            });
                        }
                    }
                }] resume];
            }
        });
    }
}
    
- (void) fromUrl:(NSString*) sUrl {
    [self fromUrl:sUrl defaultImage:nil];
    
}


//func loadImage(fromURL url: String) {
//        guard let imageURL = URL(string: url) else {
//            return
//        }
//
//        let cache =  URLCache.shared
//        let request = URLRequest(url: imageURL)
//        DispatchQueue.global(qos: .userInitiated).async {
//            if let data = cache.cachedResponse(for: request)?.data, let image = UIImage(data: data) {
//                DispatchQueue.main.async {
//                    self.transition(toImage: image)
//                }
//            } else {
//                URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
//                    if let data = data, let response = response, ((response as? HTTPURLResponse)?.statusCode ?? 500) < 300, let image = UIImage(data: data) {
//                        let cachedData = CachedURLResponse(response: response, data: data)
//                        cache.storeCachedResponse(cachedData, for: request)
//                        DispatchQueue.main.async {
//                            self.transition(toImage: image)
//                        }
//                    }
//                }).resume()
//            }
//        }
//    }
//
//    func transition(toImage image: UIImage?) {
////        UIView.transition(with: self, duration: 0.3,
////                          options: [.transitionCrossDissolve],
////                          animations: {
//                            self.image = image
////        },
////                          completion: nil)
//    }

@end

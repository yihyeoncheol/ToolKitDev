//
//  UIView+Extension.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/09/01.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "UIView+Extension.h"


//aButton.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMaxYCorner]

CGRect CenterInRect( CGRect rect1, CGRect rect2 ){
    CGRect rect = rect1;
    rect.origin.x = rect2.origin.x + ( rect2.size.width - rect1.size.width ) / 2.0f;
    rect.origin.y = rect2.origin.y + ( rect2.size.height - rect1.size.height ) / 2.0f;
    
    return rect;
}

@implementation UIView (Extension)
- (void)setBackgroundPatternImage:(UIImage*)image {
    UIColor * tiledColor = [UIColor colorWithPatternImage:image];
    self.backgroundColor = tiledColor;
}


+ (id)xibLoadView {
    NSString *className = NSStringFromClass([self class]);
    NSArray *xibViews = [[NSBundle mainBundle] loadNibNamed:className owner:self options:nil];
    id ret = [xibViews firstObject];
    return ret;
}

- (void)roundWithRadius:(float)radius width:(float)width color:(UIColor*)color {
    if (radius > 0) {
        [self.layer setCornerRadius:radius];
        [self.layer setBorderWidth:width];
        [self.layer setMasksToBounds:YES];
        if (color) {
            [self.layer setBorderColor: color.CGColor];
        }
    }
}

//extension UIView{
//    func setGradient(color1:UIColor,color2:UIColor){
//        let gradient: CAGradientLayer = CAGradientLayer()
//        gradient.colors = [color1.cgColor,color2.cgColor]
//        gradient.locations = [0.0 , 1.0]
//        gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
//        gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
//        gradient.frame = bounds
//        layer.addSublayer(gradient)
//    }
//}

- (void)setGradientColor:(UIColor*)sColor endColor:(UIColor*)eColor {
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", @"CAGradientLayer"];
    NSArray *sublayers = [self.layer.sublayers filteredArrayUsingPredicate:predicate];
    CAGradientLayer *layer = sublayers.firstObject;
    if (layer) {
    }else{
        layer = [CAGradientLayer new];
        layer.name = @"CAGradientLayer";
        [self.layer addSublayer:layer];
    }
    
    
//    CAGradientLayer *layer = [CAGradientLayer new];
    layer.colors = [NSArray arrayWithObjects:(id)sColor.CGColor,eColor.CGColor,nil];
//    layer.locations = [NSArray arrayWithObjects:[NSNumber numberWithFloat:0.0],[NSNumber numberWithFloat:1.0],nil];
//    layer.startPoint = CGPointMake(0, 1);
//    layer.endPoint = CGPointMake(1, 1);
    layer.frame = self.bounds;
    
    
}
- (void)shadowRemove {
    
    self.layer.shadowPath = nil;
    self.layer.shadowColor = nil;
    
    self.layer.shadowOffset = CGSizeZero;
    self.layer.shadowOpacity = 0;
    self.layer.shadowRadius = 0;
    
}
- (void)shadowWithColor:(UIColor*)color offset:(CGSize)offset opacity:(CGFloat)opacity radius:(CGFloat)radius {
    UIBezierPath *path =  [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:0];
    
    self.layer.shadowColor = color.CGColor;
    self.layer.shadowPath = path.CGPath;
    self.layer.shadowOffset = offset;
    self.layer.shadowOpacity = opacity;
    self.layer.shadowRadius = radius;
}

- (void)roundingCorners:(UIRectCorner)corner radius:(CGSize)radius {
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", @"roundingCorners"];
    NSArray *sublayers = [self.layer.sublayers filteredArrayUsingPredicate:predicate];
    CAShapeLayer *maskLayer = sublayers.firstObject;
    if (maskLayer) {
    }else{
        maskLayer = [CAShapeLayer new];
        maskLayer.name = @"roundingCorners";
    }
    
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners:corner cornerRadii:radius];
    
    maskLayer.frame = self.bounds;
    maskLayer.path = path.CGPath;
    self.layer.mask = maskLayer;
    self.layer.mask.masksToBounds = YES;
//    self.layer.masksToBounds = YES;
//    [self.layer setMasksToBounds:YES];
}


- (void)subViewWillRotate:(id<UIViewControllerTransitionCoordinatorContext>) context {
    
//    if([self isKindOfClass:[View class]]){
//        [(View*)self viewWillRotate:context];
//    }
//
//    for (UIView *subview in [self subviews]) {
//        if([subview isKindOfClass:[View class]]){
//            [(View*)subview viewWillRotate:context];
//        }
//    }
}

- (UIView *)findFirstResponder {
    
    if ([self isFirstResponder]) {
        return self;
    }
    for (UIView *subview in [self subviews]) {
        UIView *firstResponder = [subview findFirstResponder];
        if (nil != firstResponder) {
            return firstResponder;
        }
    }
    return nil;
}

    
- (void)clearRect:(CGRect)rect radius:(CGSize)radius outlineColor:(nullable UIColor*) color {
        
    CAShapeLayer *scanLayer = [CAShapeLayer layer];
    UIBezierPath *outerPath = [UIBezierPath bezierPathWithRoundedRect:rect byRoundingCorners:UIRectCornerAllCorners cornerRadii:radius];
    
    UIBezierPath *superlayerPath = [UIBezierPath bezierPathWithRect:self.bounds];
    outerPath.usesEvenOddFillRule = YES;
    [outerPath appendPath:superlayerPath];
    
    scanLayer.path = outerPath.CGPath;
    scanLayer.fillRule = kCAFillRuleEvenOdd;
    scanLayer.fillColor = [UIColor blackColor].CGColor;
    self.layer.mask = scanLayer;
    
    if (color) {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", @"outlineLayer"];
        NSArray *sublayers = [self.layer.sublayers filteredArrayUsingPredicate:predicate];
        CAShapeLayer *outlineLayer = sublayers.firstObject;
        if (outlineLayer) {
        }else{
            outlineLayer = [CAShapeLayer layer];
            outlineLayer.name = @"outlineLayer";
        }
        
        UIBezierPath *outlinePath = [UIBezierPath bezierPathWithRoundedRect:rect byRoundingCorners:UIRectCornerAllCorners cornerRadii:radius];
        CGFloat outlineWidth = 1.0f * [[UIScreen mainScreen] scale];
        
        
        outlineLayer.frame = self.bounds;
        outlineLayer.fillColor = color.CGColor;
        outlineLayer.strokeColor = color.CGColor;
        outlineLayer.lineWidth = outlineWidth;
        
        //  Set the path to the layer
        outlineLayer.path = outlinePath.CGPath;
        
        
        [self.layer addSublayer:outlineLayer];
    }
}


- (NSArray<UIView*>*)subAllViewsOfClass:(Class)c {
    NSMutableArray *subviews = [NSMutableArray array];
    
     if([self isKindOfClass:c]) {
         [subviews addObject:self];
     }
    
    for(UIView *view in self.subviews) {
        for(UIView *v in view.subviews) {
            NSArray *svs = [v subAllViewsOfClass:c];
            if(svs.count > 0){
                [subviews arrayByAddingObjectsFromArray:svs];
            }
            
        }
    }
    return [NSArray arrayWithArray:subviews];;
}




- (NSArray<UIView*>*)subViewsOfClass:(Class)c {
    NSMutableArray *subviews = [NSMutableArray array];
    for(UIView *view in self.subviews) {
        if([view isKindOfClass:c]) {
            [subviews addObject:view];
        }
    }
    return [NSArray arrayWithArray:subviews];;
}

@end


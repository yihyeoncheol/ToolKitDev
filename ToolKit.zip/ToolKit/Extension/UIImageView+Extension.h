//
//  UIImageView+Extension.h
//  LPoint
//
//  Created by MP02031 on 2020/10/14.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImageView (Extension)
- (void)qr:(NSData*)data ;
- (void)barcode:(NSData*)data;
- (void)fromUrl:(NSString*) sUrl;
- (void)fromUrl:(NSString*) sUrl rotateAngle:(CGFloat)angle;
- (void) fromUrl:(NSString*) sUrl defaultImage:(UIImage*)defaultImage;
@end

NS_ASSUME_NONNULL_END

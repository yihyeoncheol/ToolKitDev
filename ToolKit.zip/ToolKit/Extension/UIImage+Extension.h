//

//  UIImage+Extension.h
//  MMCamScanner
//
//  Created by mukesh mandora on 09/06/15.
//  Copyright (c) 2015. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Extension)

- (UIImage*)fixOrientation;

+ (UIImage*)renderImage:(NSString *)name;
+ (UIImage*)createImageFromUIColor:(UIColor*)color;
- (UIImage *)crop:(CGRect)rect;
//- (UIImage*)imageWithColorOverlay:(UIColor*)colorOverlay;
+ (UIImage*)imageWithColor:(UIColor *)color size:(CGSize)size;
+ (UIImage*)imageWithColor:(UIColor *)color;
@end


//UIImageExtension.h
@interface UIImage (UIImageExtension)
+ (UIImage *)imageNamed:(NSString *)name forSession:(id)session;
+ (void)clearSession:(id)session;
@end


@interface UIImage (Resize)

+ (UIImage*)imageWithImage:(UIImage *)image scaledToMaxWidth:(CGFloat)width maxHeight:(CGFloat)height;
+ (UIImage*)imageWithColor:(UIColor *)color size:(CGSize)size;
+ (UIImage*)imageWithColor:(UIColor *)color;
- (UIImage*)scaleToSize:(CGSize)size;
- (UIImage*)cropToRect:(CGRect)rect;
- (UIImage*)resizeWithCapInsets;
- (UIImage*)resizeWithCapInsets:(UIEdgeInsets)insets;

@end

#if 0
@interface UIImage (Bundle)
+ (UIImage*)imageNamed:(NSString*)imageName bundle:(NSBundle*)bundle;
@end

#endif


//
//  UIView+Extension.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/09/01.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

CGRect CenterInRect( CGRect rect1, CGRect rect2 );
@interface UIView (Extension)
+ (id)xibLoadView;
- (void)setBackgroundPatternImage:(UIImage*)image ;
- (void)roundWithRadius:(float)radius width:(float)width color:(nullable UIColor*)color;
- (void)subViewWillRotate:(id<UIViewControllerTransitionCoordinatorContext>) context;
- (UIView *)findFirstResponder;
- (void)clearRect:(CGRect)rect radius:(CGSize)radius outlineColor:(nullable UIColor*) color;
- (void)roundingCorners:(UIRectCorner)corner radius:(CGSize)radius;
- (void)shadowWithColor:(UIColor*)color offset:(CGSize)offset opacity:(CGFloat)opacity radius:(CGFloat)radius;
//- (void)shadowWithColor:(UIColor*)color offset:(CGSize)offset opacity:(CGFloat)opacity radius:(CGFloat)radius cornerRadius:(CGFloat)cornerRadius;
- (void)shadowRemove;
- (NSArray<UIView*>*)subAllViewsOfClass:(Class)c ;
- (NSArray<UIView*>*)subViewsOfClass:(Class)c;
- (void)setGradientColor:(UIColor*)sColor endColor:(UIColor*)eColor;
@end

NS_ASSUME_NONNULL_END

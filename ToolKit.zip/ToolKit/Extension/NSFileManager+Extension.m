//
//  NSFileManager+Extension.m
//  LPoint
//
//  Created by MP02031 on 2020/09/18.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "NSFileManager+Extension.h"

@implementation NSFileManager (Extension)

+ (NSString *)documentPathWithFileName:(NSString *)fileName {
    NSArray *paths = NSSearchPathForDirectoriesInDomains( NSDocumentDirectory , NSAllDomainsMask , YES );
    NSString *documentPath = [paths objectAtIndex:0];
    
    if( fileName ){
        return [documentPath stringByAppendingString:fileName];
    }else{
        return documentPath;
    }
}

@end

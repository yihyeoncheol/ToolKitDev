//
//  LAContext+Extension.m
//  LPoint
//
//  Created by MP02031 on 2020/11/16.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "LAContext+Extension.h"


@implementation LAContext (Extension)


+ (BiometricType) biometricType {
    
    LAContext *laContext = [LAContext new];
    NSError *error;
    BOOL ret = [laContext canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
    if (ret) {
        if (@available(iOS 11.0, *)) {
            switch (laContext.biometryType) {
                case LABiometryTypeNone:
                    return BiometricNone;
                case LABiometryTypeTouchID:
                    return BiometricTouchID;
                case LABiometryTypeFaceID:
                    return BiometricFaceID;
                default:
                    return BiometricNone;
            }
        }
        return BiometricTouchID;
    }else{
        if (@available(iOS 11.0, *)) {
            switch (laContext.biometryType) {
                case LABiometryTypeNone:
                    return BiometricNone;
                case LABiometryTypeTouchID:
                    return BiometricTouchID;
                case LABiometryTypeFaceID:
                    return BiometricFaceID;
                default:
                    return BiometricNone;
            }
        }
        return (error.code == LAErrorTouchIDNotAvailable) ? BiometricNone : BiometricTouchID;
    }
    return BiometricNone;
}
- (BOOL)isAvailable {
    LAContext *laContext = [LAContext new];
    NSError *error;
    BOOL available = [laContext canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
    return available;
}

- (BOOL)isLock {
    LAContext *laContext = [LAContext new];
    NSError *error;
    BOOL available = [laContext canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
    if (error.code == -8) {
        return true;
    }
    return available;
}
    
@end

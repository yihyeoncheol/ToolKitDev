//
//  NSString+Extension.h
//  LPoint
//
//  Created by MP02031 on 2020/09/18.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Extension)
+ (NSString*)readfile:(NSString*)fileName;
- (NSDate*)stringToDateWithFormat:(NSString*)format;

- (NSString*)stringToDateWithDateFormat:(NSString*)format;

- (NSDictionary <NSString*,NSString*> *)fromQuery;
- (NSString*)phoneNumbertoAsteriskPhoneNumber;
- (BOOL)specialCharactersCehck;
- (BOOL)isNullOrEmpty;
- (NSString *)trim;
- (NSString *)NVL2;
- (BOOL)contains:(NSString *)string;
- (NSString*)decimalStyle;
- (NSString*)decimal;
- (NSString*)decimal:(int)minimum;

- (NSString*)decodeUTF8;

- (NSString *)encodeToPercentEscapeString;
- (NSString *)decodeFromPercentEscapeString;
#pragma mark -
#pragma mark 컴마처리 및 수숫점 처리 Remove '-'
-(NSString *)decimalRemoveSubtraction ;

-(NSString *)decimalRemoveSubtraction:(int)minimum ;

#pragma mark -
#pragma mark "0" => Space
- (NSString *)zeroToSpace;
- (NSString *)removeMinus;
- (NSString *)removeComma;

- (CGFloat)heightForString:(NSString *)fontName fontsize:(CGFloat) fontsize maxWidth:(CGFloat)maxWidth;
- (NSString*)sha512HashFor;
- (NSString *)make22String:(int)count hipenGapSpace:(BOOL)gapSpace whiteSpace:(BOOL)whiteSpace;
- (NSString *) exceptFamilyName;
@end

NS_ASSUME_NONNULL_END

//
//  UIViewController+Extension.m
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/10.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "UIViewController+Extension.h"

@implementation UIViewController (Extension)

- (UIEdgeInsets)safeAreaInsets {
    CGFloat top     = 0;
    CGFloat bottom  = 0;
    CGFloat right   = 0;
    CGFloat left    = 0;
    
    if (@available(iOS 11.0, *)) {
        top     = self.view.safeAreaInsets.top;
        bottom  = self.view.safeAreaInsets.bottom;
        left    = self.view.safeAreaInsets.left;
        right   = self.view.safeAreaInsets.right;
    }else{
        top     = self.topLayoutGuide.length;
        bottom  = self.bottomLayoutGuide.length;
    }
    
    
    return UIEdgeInsetsMake(top, left, bottom, right);
    
}

+ (ViewController*)loadViewControllerWithStoryboardName:(NSString*)storyboardName identifier:(NSString*)identifier {
    UIStoryboard *sb = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
    return [sb instantiateViewControllerWithIdentifier:identifier];
}
//func safeAreaInsets() -> UIEdgeInsets {
//    var top: CGFloat = 0
//    var bottom: CGFloat = 0
//    var right: CGFloat = 0
//    var left: CGFloat = 0
//
//    if #available(iOS 11.0, *) {
//        top = view.safeAreaInsets.top
//        bottom = view.safeAreaInsets.bottom
//        left = view.safeAreaInsets.left
//        right = view.safeAreaInsets.right
//    } else {
//        top = topLayoutGuide.length
//        bottom = bottomLayoutGuide.length
//    }
//
//    return UIEdgeInsets(top: top, left: left, bottom: bottom, right: right)
//}

@end

//
//  UIViewController+Extension.h
//  ObjcToolKit
//
//  Created by MP02031 on 2020/09/10.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (Extension)
- (UIEdgeInsets)safeAreaInsets ;
+ (ViewController*)loadViewControllerWithStoryboardName:(NSString*)storyboardName identifier:(NSString*)identifier;
@end

NS_ASSUME_NONNULL_END

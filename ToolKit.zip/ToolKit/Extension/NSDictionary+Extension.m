//
//  NSDictionary+Extension.m
//  LPoint
//
//  Created by MP02031 on 2020/09/18.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "NSDictionary+Extension.h"

@implementation NSDictionary (Extension)

//var queryString : String? {
//    var query = String()
//    if let self = self as? [String:String] {
//        for (key,value) in self {
//            let value = value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
//            query += key + "=" + value + "&"
//        }
//    }
//    query = query.substring(with: NSRange(location: 0, length: query.count - 1))
//    return query
//}


//- (NSString*)urlEncodedString
//{
//    NSMutableArray *parts = [NSMutableArray array];
//    for (id key in self)
//    {
//        id value = [self objectForKey: key];
//        NSString *part = [NSString stringWithFormat: @"%@=%@", key, value];
//        [parts addObject: part];
//    }
//    return [parts componentsJoinedByString: @"&"];
//}



- (NSString*)queryString {
    
    NSMutableString *query = [NSMutableString string];
    for (id key in self){
        id value = [self objectForKey: key];
        NSString *sValue = [value stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        NSString *parm = [NSString stringWithFormat: @"%@=%@&", key, sValue];
        [query appendString: parm];
    }
    
    return [query substringWithRange:NSMakeRange(0, query.length - 1)];
}
@end

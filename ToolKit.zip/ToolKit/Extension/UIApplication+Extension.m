//
//  UIApplication+Extension.m
//  LPoint
//
//  Created by MP02031 on 2020/09/11.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "UIApplication+Extension.h"
#import "Session.h"
#import "Cookie.h"


@implementation UIApplication (Extension)

+ (NavigationController*)navigation {
    return UIApplication.sharedApplication.rootController.navigation;
}

- (RootController*)rootController {
    return (RootController*)[UIApplication sharedApplication].keyWindow.rootViewController;
}

//- (Session*)session {
//    return self.rootController.session;
//}

- (Cookie*)cookie {
    return self.rootController.cookie;;
}

- (EncryptCookie*)encryptCookie {
    return self.rootController.encryptCookie;
}



@end

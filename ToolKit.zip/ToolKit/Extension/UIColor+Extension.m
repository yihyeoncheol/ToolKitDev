//
//  UIColor+Extension.m
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/09/02.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import "UIColor+Extension.h"

@implementation UIColor (Extension)

+ (UIColor *)hex:(UInt32)col
{
    unsigned char r, g, b;
    b = col & 0xFF;
    g = (col >> 8) & 0xFF;
    r = (col >> 16) & 0xFF;
    return [UIColor colorWithRed:(float)r/255.0f green:(float)g/255.0f blue:(float)b/255.0f alpha:1];
}

+ (UIColor*)rgbColorWithRed:(float)r green:(float)g blue:(float)b alpha:(float)alpha
{
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:alpha];

}
@end

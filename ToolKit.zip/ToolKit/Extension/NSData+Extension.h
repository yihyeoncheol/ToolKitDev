//
//  NSData+Extension.h
//  LPoint
//
//  Created by MP02031 on 2020/11/09.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSData (Extension)
- (NSString *)base64Encode;
- (NSData *) SHA512Hash;
@end

NS_ASSUME_NONNULL_END

//
//  UIColor+Extension.h
//  ObjcToolKit
//
//  Created by yihyeoncheol on 2020/09/02.
//  Copyright © 2020 yihyeoncheol. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (Extension)
+ (UIColor *)hex:(UInt32)col;
+ (UIColor*)rgbColorWithRed:(float)r green:(float)g blue:(float)b alpha:(float)alpha;
@end

NS_ASSUME_NONNULL_END

//
//  NSFileManager+Extension.h
//  LPoint
//
//  Created by MP02031 on 2020/09/18.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSFileManager (Extension)
+ (NSString *)documentPathWithFileName:(NSString *)fileName ;
@end

NS_ASSUME_NONNULL_END

//
//  LAContext+Extension.h
//  LPoint
//
//  Created by MP02031 on 2020/11/16.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import <LocalAuthentication/LocalAuthentication.h>

typedef NS_ENUM(NSInteger, BiometricType) {
    BiometricNone    = 0,    // default
    BiometricTouchID  = 1,    //
    BiometricFaceID  = 2    //
};


NS_ASSUME_NONNULL_BEGIN

@interface LAContext (Extension)

+ (BiometricType) biometricType;
+ (BOOL)isAvailable;
+ (BOOL)isLock ;

@end

NS_ASSUME_NONNULL_END

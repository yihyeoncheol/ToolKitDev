//
//  NSDate+Extension.m
//  LPoint
//
//  Created by MP02031 on 2020/09/18.
//  Copyright © 2020 MP02031. All rights reserved.
//

#import "NSDate+Extension.h"

@implementation NSDate (Extension)

- (NSString*)dateFormat:(NSString*)format {
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    [dateFormatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"ko_KR"]];
    [dateFormatter setDateFormat:format];
    NSString *result  = [dateFormatter stringFromDate:self];
    return result;
}

- (NSInteger)difference:(NSDate *)date {
    NSTimeInterval secs = [self timeIntervalSinceDate:date];
    //return secs = secs / (60);
    
    return secs; // 초단위
}

+ (NSDate *)getNow {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *comp = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond fromDate:[NSDate date]];
    return [calendar dateFromComponents:comp];
}


+ (NSDate *)today {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *comp = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:[NSDate date]];
    return [calendar dateFromComponents:comp];
}

+ (NSDate *)getMonth {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *comp = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth fromDate:[NSDate date]];
    return [calendar dateFromComponents:comp];
}

- (NSDate *)toLocalTime {
    NSTimeZone *tz = [NSTimeZone defaultTimeZone];
    NSInteger seconds = [tz secondsFromGMTForDate: self];
    return [NSDate dateWithTimeInterval: seconds sinceDate: self];
}

+ (NSInteger)getAge:(NSString*) birthDate{
    NSDateFormatter *yyyyMMdd = [[NSDateFormatter alloc] init];
    [yyyyMMdd setDateFormat:@"yyyyMMdd"];
    NSDateFormatter *yyyy = [[NSDateFormatter alloc] init];
    [yyyy setDateFormat:@"yyyy"];
    
    NSDate *now = [[NSDate date] toLocalTime];
    
    // 나이 계산 (한국 나이)
    NSDate *birthYear = [[yyyy dateFromString:[birthDate substringToIndex:4]] toLocalTime];
    NSDateComponents *ageComponents = [[NSCalendar currentCalendar]
                                       components:NSCalendarUnitYear
                                       fromDate:birthYear
                                       toDate:now
                                       options:0];
    NSInteger age = [ageComponents year] + 1;
    
    return age;
}


@end
